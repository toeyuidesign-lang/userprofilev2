/* ============================================================
   Request detail / workflow — role-aware action surface.
   The SAME page is reached by every role (HR, IT, PO, SO) from
   their email link / to-do; what they can DO depends on the
   request's current workflow step and the role they're viewing as.
   ============================================================ */
function ReviewSummary({ app }) {
  const poTitle = app.ownerTitle || jobTitleFor(app.ownerEmail);
  const leadTitle = app.leadTitle || jobTitleFor(app.leadEmail);
  const rows = [
    ['Application', app.name], ['Client ID', app.id],
    ['Requested by', app.requester],
    ['Product Owner', `${app.owner} · ${app.ownerEmail}${poTitle && poTitle !== '—' ? ' · ' + poTitle : ''}`],
    ['Tech Lead', app.lead ? `${app.lead} · ${app.leadEmail}${leadTitle && leadTitle !== '—' ? ' · ' + leadTitle : ''}` : 'Not specified'],
  ];
  return (
    <div>
      {rows.map(([l, r]) => (
        <div className="summary-row" key={l}><span className="l">{l}</span><span className="r">{r}</span></div>
      ))}
      <div className="summary-row"><span className="l">Access models</span><span className="r"><AccessTags access={app.access} /></span></div>
      {(app.key || app.clientCode) && (
        <div className="summary-row"><span className="l">Credentials</span><span className="r" style={{ fontFamily:'var(--font-mono, monospace)', fontSize:12.5 }}>
          {app.key ? <span className="chip chip-info" style={{ padding:'2px 9px', fontSize:11.5 }}>Key · {app.key}</span> : null}
          {app.clientCode ? <span className="chip chip-info" style={{ padding:'2px 9px', fontSize:11.5, marginLeft:6 }}>Client Code · {app.clientCode}</span> : null}
        </span></div>
      )}
    </div>
  );
}

function ScopeCard({ icon, title, count, label, children }) {
  return (
    <div style={{ border:'1px solid var(--border)', borderRadius:'var(--radius-md)', padding:'16px 18px' }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:10 }}>
        <span style={{ width:34, height:34, borderRadius:'var(--radius-sm)', background:'var(--purple-50)', color:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}><Icon name={icon} size={18} /></span>
        <div style={{ flex:1 }}>
          <div style={{ fontWeight:600, color:'var(--fg)', fontSize:14 }}>{title}</div>
          <div className="muted" style={{ fontSize:12 }}>{count} {label}</div>
        </div>
      </div>
      {children}
    </div>
  );
}

function ScopeGrid({ app, cols }) {
  const apiOnly = app.access.length === 1 && app.access[0] === 'API';
  return (
    <div style={{ display:'grid', gridTemplateColumns: cols || '1fr 1fr', gap:14 }}>
      <ScopeCard icon="filter" title="Row Selection" count={app.rules} label="validation rules">
        <div className="preview-box" style={{ fontSize:12, padding:'10px 12px' }}>(Company_Code == "BPP") <span className="o">AND</span> (Country <span className="o">IN</span> [TH, ID])</div>
      </ScopeCard>
      <ScopeCard icon="grid" title="Column Selection" count={app.columns} label="fields shared">
        <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>
          {['UserID','Country','JobTitle','BusinessUnit'].map(c => <span key={c} className="chip chip-active" style={{ padding:'2px 9px', fontSize:11.5 }}>{c}</span>)}
          <span className="chip chip-rejected" style={{ padding:'2px 9px', fontSize:11.5 }}><Icon name="shield" size={11} /> 2 PII</span>
        </div>
      </ScopeCard>
      <ScopeCard icon="settings" title="Master Data" count={apiOnly ? 0 : app.sources} label={apiOnly ? 'not used (API only)' : 'CIF tables'}>
        {apiOnly
          ? <span className="muted" style={{ fontSize:12.5 }}>API-only request — master data selection is not applicable.</span>
          : <div style={{ display:'flex', flexWrap:'wrap', gap:6 }}>{['Company','Business Unit','Function'].map(c => <span key={c} className="chip chip-info" style={{ padding:'2px 9px', fontSize:11.5 }}>{c}</span>)}</div>}
      </ScopeCard>
      <ScopeCard icon="link" title="Connection" count={app.access.length} label="access models">
        <AccessTags access={app.access} />
      </ScopeCard>
    </div>
  );
}

/* ---------------- 7-step horizontal tracker ---------------- */
function StepTracker({ app }) {
  const cur = STEP_OF(app);
  const ended = app.status === 'Terminated' || app.status === 'Cancelled';
  const endAt = ended ? cur : null;
  return (
    <div className="card card-pad" style={{ marginBottom:18 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:16 }}>
        <span style={{ fontWeight:700, fontFamily:'var(--font-display)', fontSize:15 }}>Approval workflow</span>
        <span className="muted" style={{ fontSize:13 }}>· {stageLabel(app)}</span>
      </div>
      <div className="wf-track">
        {workflowFor(app).map((w, i) => {
          let state = 'idle';
          if (app.status === 'Active') state = 'done';
          else if (ended && w.n < endAt) state = 'done';
          else if (ended && w.n === endAt) state = 'stop';
          else if (w.n < cur) state = 'done';
          else if (w.n === cur && app.status === 'In Progress') state = 'cur';
          else if (app.status === 'Draft' && w.n === 1) state = 'cur';
          return (
            <div className={`wf-node ${state}`} key={w.n}>
              {i > 0 && <span className={`wf-line ${(state === 'done' || (w.n <= cur && !ended)) ? 'on' : ''}`}></span>}
              <div className="wf-dot">
                {state === 'done' ? <Icon name="check" size={13} />
                  : state === 'stop' ? <Icon name="close" size={13} />
                  : <span>{w.n}</span>}
              </div>
              <div className="wf-meta">
                <div className="wf-label">{w.label}</div>
                <div className="wf-role">{w.role === 'System' ? 'Auto' : w.role}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Role-aware action panel ---------------- */
const ROLE_KEY = { HR:'hr', IT:'it', PO:'po', SO:'so' };
function roleInfo(role, app) {
  if (role === 'PO') return { name: app.owner, role: 'Product Owner' };
  const r = ROLES[ROLE_KEY[role]];
  return r || { name: role, role };
}

function WorkflowPanel({ app, role, onAction, onDuplicate, onEditContacts, sticky = true }) {
  const pending = pendingRole(app);          // role string whose turn it is, or null
  const step = STEP_OF(app);
  const meta = STEP_META(app, step);
  const myTurn = pending === role;
  const me = roleInfo(role, app);
  const canTerminate = role === 'IT' || role === 'HR';
  const canAuthor = role === 'HR' || role === 'IT' || role === 'PO';  // who may create/submit a request

  // ---- assemble the body for the current situation ----
  let body;

  if (app.status === 'Draft') {
    body = canAuthor
      ? <>
          <Btn variant="accent" icon="send" onClick={() => onAction('submit_draft')}>Submit for processing</Btn>
          <Btn variant="outline" icon="edit" onClick={() => onAction('edit')}>Edit request</Btn>
          <Btn variant="danger" icon="trash" onClick={() => onAction('delete_draft')}>Delete draft</Btn>
          <p className="wf-hint">Drafts aren't saved into the workflow yet — you can delete them anytime.</p>
        </>
      : <Waiting who="PO / IT" name={ROLES.po.name} label="completing the request" />;
  }
  else if (app.status === 'Active') {
    body = <>
      <div className="wf-ok"><Icon name="shield" size={18} /><span>This integration is <b>Active</b>. Credentials have been issued to {app.owner}.</span></div>
      <Btn variant="outline" icon="edit" onClick={() => onEditContacts && onEditContacts(app)}>Edit PO &amp; Tech Lead</Btn>
      <p className="wf-hint">Change the assigned Product Owner or Tech Lead (e.g. handover or resignation) without altering the integration. All other fields are locked — use <b>New version</b> to change scope.</p>
      {canTerminate
        ? <Btn variant="danger" icon="x2" onClick={() => onAction('terminate')}>Terminate request</Btn>
        : <p className="wf-hint">Only IT or HR can terminate an active integration.</p>}
    </>;
  }
  else if (app.status === 'Terminated' || app.status === 'Cancelled') {
    body = <div className="wf-stopbox">
      <div style={{ display:'flex', alignItems:'center', gap:8, fontWeight:700, color:'var(--danger)' }}>
        <Icon name="x2" size={18} /> {app.status}
      </div>
      <p style={{ margin:'8px 0 0', fontSize:13, color:'var(--fg-secondary)', lineHeight:1.55 }}>
        {app.termReason || app.cancelReason || 'This request was closed.'}
        {app.termBy ? <span className="muted"> — {app.termBy}</span> : null}
      </p>
    </div>;
  }
  else if (!myTurn) {
    body = <Waiting who={pending} name={pending ? roleInfo(pending, app).name : 'System'} label={meta.label} />;
  }
  else {
    // It IS this role's turn — render the step-specific action (keyed by step, not number)
    if (meta.key === 'hr_review') {  // HR — review & approve (STD workflow only)
      body = <>
        <p className="wf-task">Review the request details and access scope, then approve it to route to IT for provisioning.</p>
        <Btn variant="success" icon="check" onClick={() => onAction('hr_approve')}>Approve request</Btn>
      </>;
    } else if (meta.key === 'it_submit') {  // IT — submit to PO
      body = <>
        <p className="wf-task">Review the request, then enter the integration <b>Key</b> &amp; <b>Client Code</b> and forward it to the Product Owner for testing.</p>
        <Btn variant="accent" icon="send" onClick={() => onAction('submit_po')}>Submit to PO</Btn>
        <p className="wf-hint">Opens the credential window. The <b>Confirm</b> step comes after the PO has tested.</p>
      </>;
    } else if (meta.key === 'po_test') {  // PO — offline test
      body = <>
        <div className="wf-offline"><Icon name="mail" size={18} /><span>This step is handled <b>offline by email</b>. Test the integration in your environment, then reply to the notification with the result.</span></div>
        <Btn variant="success" icon="check" onClick={() => onAction('po_tested')}>Record test result: Pass</Btn>
        <Btn variant="outline" icon="rotate" onClick={() => onAction('po_failed')}>Report a problem</Btn>
      </>;
    } else if (meta.key === 'it_confirm') {  // IT — confirm INLINE (no modal)
      body = <>
        <div className="wf-ok"><Icon name="check" size={18} /><span>The Product Owner tested this integration — result <b>Pass</b>.</span></div>
        <p className="wf-task">Review the credentials below and <b>confirm</b> the request form to send it to the System Owner.</p>
        <div className="wf-credbox">
          <div className="wf-credrow"><span>Key</span><b>{app.key || '—'}</b></div>
          <div className="wf-credrow"><span>Client Code</span><b>{app.clientCode || '—'}</b></div>
        </div>
        <Btn variant="success" icon="filecheck" onClick={() => onAction('it_confirm_inline')}>Confirm request</Btn>
      </>;
    } else if (meta.key === 'so_submit') {  // SO — submit
      body = <>
        <p className="wf-task">Enter the integration <b>Key</b> &amp; <b>Client Code</b> to provision and activate the integration.</p>
        <Btn variant="accent" icon="send" onClick={() => onAction('so_submit')}>Open &amp; Submit</Btn>
      </>;
    }
  }

  return (
    <div className="card card-pad" style={sticky ? { position:'sticky', top:88 } : {}}>
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:6 }}>
        <span style={{ fontWeight:700, fontFamily:'var(--font-display)', fontSize:17 }}>Your action</span>
        <StatusChip status={app.status} />
      </div>
      <div className="wf-asrow">
        <span className="wf-asavatar">{me.name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase()}</span>
        <div>
          <div style={{ fontSize:12.5, color:'var(--fg-secondary)' }}>Viewing as <b style={{ color:'var(--fg)' }}>{me.name}</b></div>
          <div className="muted" style={{ fontSize:12 }}>{me.role}</div>
        </div>
        {myTurn && <span className="chip chip-progress" style={{ marginLeft:'auto', padding:'3px 10px' }}><span className="dot"></span>Your turn</span>}
      </div>
      <div className="divider" style={{ margin:'14px 0' }}></div>
      <div className="wf-actions">{body}</div>
      {/* Whoever's turn it is can cancel the request at any pending step */}
      {myTurn && app.status === 'In Progress' && (
        <>
          <div className="divider" style={{ margin:'16px 0 14px' }}></div>
          <Btn variant="outline" size="sm" icon="x2" onClick={() => onAction('cancel_request')}>Cancel request</Btn>
          <p className="wf-hint" style={{ marginTop:8 }}>You can cancel while this request is awaiting your review. A reason is required.</p>
        </>
      )}
      {/* HR may also cancel even when it isn't their turn — they're usually the original requester */}
      {!myTurn && role === 'HR' && app.status === 'In Progress' && pending !== 'HR' && (
        <>
          <div className="divider" style={{ margin:'16px 0 14px' }}></div>
          <Btn variant="outline" size="sm" icon="x2" onClick={() => onAction('cancel_request')}>Cancel request</Btn>
          <p className="wf-hint" style={{ marginTop:8 }}>As HR, you can cancel while the request is in progress. A reason is required.</p>
        </>
      )}
      {/* Duplicate — HR only, and only once the request is Active */}
      {role === 'HR' && app.status === 'Active' && <>
        <div className="divider" style={{ margin:'16px 0 14px' }}></div>
        <Btn variant="ghost" size="sm" icon="copy" onClick={() => onDuplicate(app)}>Duplicate this request</Btn>
      </>}
    </div>
  );
}

function Waiting({ who, name, label }) {
  return (
    <div className="wf-waiting">
      <span className="wf-spinner"><Icon name="clock" size={20} /></span>
      <div>
        <div style={{ fontWeight:600, color:'var(--fg)', fontSize:14 }}>Waiting on {who || 'System'}</div>
        <div className="muted" style={{ fontSize:13, lineHeight:1.5 }}>{label}{name ? ` · ${name}` : ''}</div>
      </div>
    </div>
  );
}

function Review({ app, role, onExit, onAction, onDuplicate, onEditContacts, openHistory, layout, setLayout }) {
  return (
    <div className="content-narrow fade-in">
      <div className="crumbs">
        <button className="backlink" onClick={onExit}><Icon name="chevL" size={18} /> Back</button>
        <span className="crumb-path">Registration Listing&nbsp;/&nbsp;<span className="cur">{app.name}</span></span>
      </div>

      <div className="page-head" style={{ marginBottom:18 }}>
        <div>
          <div className="page-title">{app.name}</div>
          <div className="page-sub"><span className="cell-id">{app.id}</span> · Requested by {app.requester} · submitted {app.submitted}</div>
        </div>
        <div style={{ display:'flex', gap:12, alignItems:'center' }}>
          <span className="muted" style={{ fontSize:13, fontWeight:600 }}>Layout</span>
          <div className="seg">
            {[['split','Split'],['focus','Focus']].map(([k, l]) => (
              <button key={k} className={layout === k ? 'on' : ''} onClick={() => setLayout(k)}>{l}</button>
            ))}
          </div>
          {role === 'HR' && app.status === 'Active' && <Btn variant="ghost" icon="copy" onClick={() => onDuplicate(app)}>Duplicate</Btn>}
          {app.status !== 'Draft' && <Btn variant="ghost" icon="history" onClick={() => openHistory(app)}>History</Btn>}
        </div>
      </div>

      <StepTracker app={app} />

      {layout === 'split'
        ? (
          <div className="review-grid">
            <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
              <div className="card card-pad">
                <div className="section-title"><Icon name="user" size={20} style={{ color:'var(--brand)' }} /> Request details</div>
                <div style={{ marginTop:8 }}><ReviewSummary app={app} /></div>
              </div>
              <div className="card card-pad">
                <div className="section-title"><Icon name="shield" size={20} style={{ color:'var(--brand)' }} /> Access scope</div>
                <div className="section-desc">What this application will be able to read once provisioned.</div>
                <ScopeGrid app={app} />
              </div>
            </div>
            <WorkflowPanel app={app} role={role} onAction={onAction} onDuplicate={onDuplicate} onEditContacts={onEditContacts} />
          </div>
        )
        : (
          <div style={{ maxWidth:'none' }}>
            <div style={{ marginBottom:18 }}><WorkflowPanel app={app} role={role} onAction={onAction} onDuplicate={onDuplicate} onEditContacts={onEditContacts} sticky={false} /></div>
            <div className="card card-pad" style={{ marginBottom:18 }}>
              <div className="section-title"><Icon name="user" size={20} style={{ color:'var(--brand)' }} /> Request details</div>
              <div style={{ marginTop:8 }}><ReviewSummary app={app} /></div>
            </div>
            <div className="card card-pad">
              <div className="section-title"><Icon name="shield" size={20} style={{ color:'var(--brand)' }} /> Access scope</div>
              <div className="section-desc">What this application will be able to read once provisioned.</div>
              <ScopeGrid app={app} cols="1fr 1fr 1fr 1fr" />
            </div>
          </div>
        )}
    </div>
  );
}

Object.assign(window, { Review, StepTracker, WorkflowPanel });

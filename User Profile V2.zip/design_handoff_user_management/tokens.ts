/**
 * Banpu Design System — Design Tokens
 * Source: banpu/colors_and_type.css
 * Ready for use in React Native StyleSheet or web CSS-in-JS.
 *
 * Usage (RN):  import { tokens } from './tokens';
 *              StyleSheet.create({ container: { backgroundColor: tokens.color.surface } })
 *
 * Usage (web): var(--brand) etc from colors_and_type.css directly.
 *
 * Updated for the current round: Azure AD picker / autocomplete tokens added;
 * no token values were removed (the 'Listener' access type and endpoint field
 * removals only affect types.ts / component usage, not these tokens).
 */

export const tokens = {
  // ─────────────────────────────────────────
  // BRAND PALETTE (verbatim from brand PDF)
  // ─────────────────────────────────────────
  color: {
    // Core brand
    brand:          '#482F92',   // Banpu Purple-Blue — primary CTA, active nav, links
    brandStrong:    '#3c277c',   // darker brand, gradient start
    brandHover:     '#5c41ab',   // hover state
    accentBlue:     '#00AEEF',   // Banpu Blue — gradient end, info
    accentGreen:    '#00B49C',   // Banpu Green — success, flame mark
    banpuPink:      '#DA1C5C',   // danger, badges
    banpuPlum:      '#9005C6',   // OR logic, highlight
    banpuBlack:     '#232127',   // deepest text, toast bg

    // Purple ramp
    purple900:      '#241749',
    purple800:      '#311f63',
    purple700:      '#3c277c',
    purple600:      '#482f92',
    purple500:      '#5c41ab',
    purple400:      '#7a63c0',
    purple300:      '#a392d4',
    purple200:      '#ccc1e8',
    purple100:      '#e7e1f5',
    purple50:       '#f4f1fb',

    // Blue ramp
    blue700:        '#0079a6',
    blue600:        '#0091c9',
    blue500:        '#00aeef',
    blue300:        '#6fd0f6',
    blue100:        '#cdeefc',
    blue50:         '#e9f8fe',

    // Green ramp
    green700:       '#007e6d',
    green600:       '#00997f',
    green500:       '#00b49c',
    green300:       '#66d2c4',
    green100:       '#cceee9',
    green50:        '#e8f8f5',

    // Neutrals
    ink900:         '#232127',
    ink800:         '#35333b',
    ink700:         '#4c4a52',
    ink600:         '#6a6870',
    ink500:         '#8a8990',
    ink400:         '#a9a8ad',
    grey300:        '#c0bfbf',
    grey200:        '#d2d4d3',
    grey100:        '#e7e8e7',
    grey50:         '#f3f3f3',
    white:          '#ffffff',

    // Semantic
    fg:             '#232127',
    fgSecondary:    '#4c4a52',
    fgMuted:        '#8a8990',
    surface:        '#ffffff',
    bgSubtle:       '#f3f3f3',
    border:         '#d2d4d3',
    borderStrong:   '#c0bfbf',
    borderSubtle:   '#e7e8e7',

    // Status
    success:        '#00997f',
    successBg:      '#e8f8f5',
    info:           '#00aeef',
    infoBg:         '#e9f8fe',
    warning:        '#E8A100',
    warningBg:      '#FCF3DC',
    danger:         '#DA1C5C',
    dangerBg:       '#FCE4EC',
  },

  // ─────────────────────────────────────────
  // GRADIENT HELPERS (expo-linear-gradient)
  // ─────────────────────────────────────────
  gradient: {
    brand:  { colors: ['#3c277c', '#00AEEF'], start: { x: 0, y: 0 }, end: { x: 1, y: 0 } },
    flame:  { colors: ['#00AEEF', '#00B49C'], start: { x: 0, y: 0 }, end: { x: 1, y: 1 } },
  },

  // ─────────────────────────────────────────
  // TYPOGRAPHY
  // ─────────────────────────────────────────
  font: {
    display: 'Kanit',   // headings, titles, KPI numbers
    body:    'Prompt',  // all other UI text
    mono:    'SpaceMono', // code / generated expressions
  },
  fontSize: {
    display: 64,
    h1:      48,
    h2:      36,
    h3:      28,
    h4:      22,
    bodyLg:  20,
    body:    16,
    bodySm:  14,
    caption: 12.5,
    overline: 13,
    label:   13,
    small:   11,
  },
  fontWeight: {
    light:    '300',
    regular:  '400',
    medium:   '500',
    semibold: '600',
    bold:     '700',
  },
  lineHeight: {
    display: 66,
    h1:      52,
    h2:      41,
    h3:      34,
    h4:      29,
    bodyLg:  32,
    body:    26,
    bodySm:  22,
    caption: 18,
  },

  // ─────────────────────────────────────────
  // SPACING (4pt base grid)
  // ─────────────────────────────────────────
  space: {
    1:  4,
    2:  8,
    3:  12,
    4:  16,
    5:  20,
    6:  24,
    8:  32,
    10: 40,
    12: 48,
    16: 64,
    20: 80,
    24: 96,
  },

  // ─────────────────────────────────────────
  // BORDER RADIUS
  // ─────────────────────────────────────────
  radius: {
    xs:   4,
    sm:   8,
    md:   12,
    lg:   16,
    xl:   24,
    pill: 999,
  },

  // ─────────────────────────────────────────
  // SHADOWS (RN format)
  // ─────────────────────────────────────────
  shadow: {
    xs: {
      shadowColor: '#232127', shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.06, shadowRadius: 2, elevation: 1,
    },
    sm: {
      shadowColor: '#232127', shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.08, shadowRadius: 4, elevation: 2,
    },
    md: {
      shadowColor: '#232127', shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.08, shadowRadius: 12, elevation: 4,
    },
    lg: {
      shadowColor: '#232127', shadowOffset: { width: 0, height: 12 },
      shadowOpacity: 0.12, shadowRadius: 32, elevation: 8,
    },
    brand: {
      shadowColor: '#482F92', shadowOffset: { width: 0, height: 12 },
      shadowOpacity: 0.22, shadowRadius: 28, elevation: 6,
    },
  },

  // ─────────────────────────────────────────
  // MOTION
  // ─────────────────────────────────────────
  duration: {
    fast:  120,
    base:  200,
    slow:  320,
  },

  // ─────────────────────────────────────────
  // COMPONENT-LEVEL SPECS
  // ─────────────────────────────────────────
  component: {
    topbarHeight:       68,
    sidebarExpanded:   264,
    sidebarCollapsed:   78,
    inputHeight:        44,   // 11px padding top+bottom + 14px font + 2px border×2
    buttonHeightMd:     44,
    buttonHeightSm:     36,
    avatarSize:         40,
    iconSizeDefault:    20,
    iconSizeSm:         16,
    rowActionSize:      34,
    checkboxSize:       20,
    radioDotSize:       10,   // inner dot of radio button
    radioOuterSize:     20,
    badgeHeight:        20,
    chipPaddingH:       11,
    chipPaddingV:        4,
  },
  // ─────────────────────────────────────────
  // AUTOCOMPLETE / AZURE AD PICKER (new components)
  // ─────────────────────────────────────────
  autocomplete: {
    menuMaxHeight: 280,
    menuShadow: 'lg',
    itemPaddingV: 9,
    itemPaddingH: 11,
  },
  azurePicker: {
    cardBg: '#f4f1fb',      // purple-50
    cardBorder: '#ccc1e8',  // purple-200
    avatarSize: 38,
    avatarSizeSm: 30,
  },

  // ─────────────────────────────────────────
  // STATUS → CHIP COLOURS
  // ─────────────────────────────────────────
  status: {
    Draft:        { bg: '#e7e8e7', fg: '#8a8990' },
    'In Progress':{ bg: '#e9f8fe', fg: '#0079a6' },
    Active:       { bg: '#e8f8f5', fg: '#00997f' },
    Archived:     { bg: '#f4f1fb', fg: '#3c277c' },
    Terminated:   { bg: '#FCE4EC', fg: '#DA1C5C' },
    Cancelled:    { bg: '#e7e8e7', fg: '#8a8990' },
  },

  // ─────────────────────────────────────────
  // ROLE COLOURS (swimlane / role-aware UI)
  // ─────────────────────────────────────────
  role: {
    HR:     { fg: '#482F92', bg: '#f4f1fb' },
    IT:     { fg: '#0091c9', bg: '#e9f8fe' },
    PO:     { fg: '#00997f', bg: '#e8f8f5' },
    SO:     { fg: '#9005C6', bg: '#f6e9fb' },
    System: { fg: '#6a6870', bg: '#f3f3f3' },
  },
} as const;
export default tokens;

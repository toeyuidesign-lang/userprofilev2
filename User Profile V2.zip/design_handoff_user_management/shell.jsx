/* ============================================================
   App shell: sidebar + topbar
   ============================================================ */
function Sidebar({ view, go, collapsed, role = 'HR', pendingCount, taskCount }) {
  const nav = [
    { key:'dashboard', label:'Dashboard', icon:'gauge' },
    { key:'listing', label:'Registration', icon:'inbox', badge: pendingCount },
    { key:'tasks', label:'My Tasks', icon:'filecheck', badge: taskCount },
    { key:'emails', label:'Email Templates', icon:'mail' },
  ];
  const master = [
    { key:'um', label:'User Management', icon:'users' },
    { key:'country', label:'Country', icon:'flag' },
    { key:'company', label:'Company', icon:'building' },
    { key:'joblevel', label:'Job Level', icon:'briefcase' },
    { key:'mapping', label:'Job Level Mapping', icon:'gitbranch' },
    { key:'function', label:'Function', icon:'function' },
    { key:'jobstatus', label:'Job Status', icon:'activity' },
  ];
  const canSeeMaster = ['HR','IT','Super Admin'].includes(role);
  return (
    <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="brand">
        <img src={(window.__resources && window.__resources.banpuLogo) || "banpu/assets/main-logo.png"} alt="Banpu" />
      </div>
      <div className="nav-group">
        <div className="nav-label">Workspace</div>
        {nav.map(n => (
          <button key={n.key} className={`nav-item ${view === n.key ? 'active' : ''}`} onClick={() => go(n.key)}>
            <Icon name={n.icon} />
            <span>{n.label}</span>
            {n.badge ? <span className="nav-badge">{n.badge}</span> : null}
          </button>
        ))}
      </div>
      {canSeeMaster && (
        <div className="nav-group">
          <div className="nav-label">Master Data</div>
          {master.map(n => (
            <button key={n.key} className={`nav-item ${view === n.key ? 'active' : ''}`} onClick={() => go(n.key)}>
              <Icon name={n.icon} />
              <span>{n.label}</span>
            </button>
          ))}
        </div>
      )}
    </aside>
  );
}

const VIEW_ROLES = [
  { key:'HR', name:'Moni Roy',     role:'HR Administrator' },
  { key:'IT', name:'Krit Wattana', role:'IT Administrator' },
  { key:'PO', name:'Product Owner',role:'Product Owner' },
  { key:'SO', name:'Suda Niran',   role:'System Owner' },
];

function Topbar({ onToggle, role = 'HR', setRole }) {
  const [open, setOpen] = useState(false);
  const me = VIEW_ROLES.find(r => r.key === role) || VIEW_ROLES[0];
  const initials = me.name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();
  return (
    <header className="topbar">
      <button className="hamburger" onClick={onToggle}><Icon name="menu" size={22} /></button>
      <div className="spacer"></div>
      <button className="lang"><span style={{fontSize:16}}>🇬🇧</span> EN <Icon name="chevD" size={16} /></button>
      <button className="iconbtn" title="Notifications" style={{position:'relative'}}>
        <Icon name="bell" size={19} />
        <span style={{position:'absolute',top:6,right:7,width:8,height:8,borderRadius:'50%',background:'var(--banpu-pink)',border:'1.5px solid #fff'}}></span>
      </button>
      <div style={{ position:'relative' }}>
        <button className="userbox" onClick={() => setOpen(o => !o)} style={{ cursor:'pointer' }}>
          <div className="avatar">{initials}</div>
          <div className="meta"><div className="nm">{me.name}</div><div className="rl">Viewing as {me.key}</div></div>
          <Icon name="chevD" size={16} style={{color:'var(--fg-muted)'}} />
        </button>
        {open && (
          <>
            <div onClick={() => setOpen(false)} style={{ position:'fixed', inset:0, zIndex:40 }}></div>
            <div className="rolemenu">
              <div className="rolemenu-head">Switch role · demo</div>
              {VIEW_ROLES.map(r => (
                <button key={r.key} className={`rolemenu-item ${r.key === role ? 'on' : ''}`} onClick={() => { setRole && setRole(r.key); setOpen(false); }}>
                  <span className="rolemenu-av">{r.name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase()}</span>
                  <span className="rolemenu-tt"><b>{r.name}</b><span>{r.role}</span></span>
                  {r.key === role && <Icon name="check" size={16} style={{ marginLeft:'auto', color:'var(--brand)' }} />}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
      <button className="iconbtn" title="Sign out"><Icon name="logout" size={19} /></button>
    </header>
  );
}

Object.assign(window, { Sidebar, Topbar });

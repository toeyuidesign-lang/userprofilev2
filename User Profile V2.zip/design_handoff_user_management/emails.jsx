/* ============================================================
   Email templates — the 4 workflow notifications (IT / PO / HR / SO).
   Rendered in an email-client frame; each CTA opens the matching
   in-app page for the right role (PO's step is offline by email).
   ============================================================ */
const MAIL_LIST = [
  { kind:'hr', step:2, role:'HR', label:'Review & Approve',    icon:'user' },
  { kind:'it', step:3, role:'IT', label:'Submit to PO',        icon:'settings' },
  { kind:'po', step:4, role:'PO', label:'Test request',        icon:'briefcase' },
  { kind:'so', step:6, role:'SO', label:'Provision & activate',icon:'shield' },
  { kind:'active', step:7, role:'ALL', label:'Activated notice',icon:'check' },
  { kind:'contacts', step:7, role:'ALL', label:'PO / Tech Lead changed', icon:'edit' },
];

function pickRep(apps, step) {
  if (step === 7) return apps.find(a => a.status === 'Active') || apps[0];
  return apps.find(a => a.status === 'In Progress' && STEP_OF(a) === step)
    || apps.find(a => a.status === 'In Progress')
    || apps[0];
}

function EmailFrame({ mail, app, onCta }) {
  // post-activation broadcast: let the viewer preview each recipient's copy
  const [recip, setRecip] = useState('HR');
  const isActive = mail.kind === 'active';
  const isContacts = mail.kind === 'contacts';
  const keyVisible = isActive ? (recip === 'PO') : !!mail.showKey;

  const detailRows = [
    ['Application', app.name],
    ['Client ID', app.id],
    ['Requested by', app.requester],
    ['Product Owner', `${app.owner}${jobTitleFor(app.ownerEmail) !== '—' ? ' · ' + jobTitleFor(app.ownerEmail) : ''}`],
    ['Access models', app.access.join(' · ')],
  ];
  if (mail.showKey || isActive) detailRows.push(['Client Code', app.clientCode || 'CLT-—']);

  return (
    <div className="mailwrap">
      <div className="mail-meta">
        <div className="mail-meta-row"><span>From</span><b>{mail.from}</b></div>
        <div className="mail-meta-row"><span>To</span><b>{mail.to}</b></div>
        <div className="mail-meta-row"><span>Subject</span><b>{mail.subject}</b></div>
      </div>

      {isActive && (
        <div className="mail-recip">
          <span className="muted" style={{ fontSize:12, fontWeight:600 }}>Preview recipient's copy:</span>
          <div className="seg">
            {['HR','IT','PO'].map(r => (
              <button key={r} className={recip === r ? 'on' : ''} onClick={() => setRecip(r)}>{r}</button>
            ))}
          </div>
          <span className="chip chip-info" style={{ padding:'2px 9px', fontSize:11 }}>Key shown to PO only</span>
        </div>
      )}

      <div className="mail-doc">
        <div className="mail-band">
          <img src={(window.__resources && window.__resources.banpuLogo) || 'banpu/assets/main-logo.png'} alt="Banpu" className="mail-logo" />
          <span>User Management</span>
        </div>
        <div className="mail-body">
          <div className="mail-tag"><span className="dot"></span>{isActive ? `Notification · ${recip}` : isContacts ? 'Notification · update' : `Action required · ${mail.role}`}</div>
          <h1 className="mail-h1">{isActive ? 'Your integration is now Active' : isContacts ? 'Product Owner / Tech Lead updated' : mail.kind === 'hr' ? 'New request — review & approval' : mail.kind === 'so' ? 'Ready to provision' : mail.kind === 'po' ? 'Integration ready for your testing' : 'Access request to process'}</h1>
          <p className="mail-p">Hi {isContacts ? 'team' : isActive ? (recip === 'PO' ? app.owner.split(' ')[0] : recip === 'IT' ? ROLES.it.name.split(' ')[0] : app.requester) : mail.role === 'PO' ? app.owner.split(' ')[0] : mail.role === 'IT' ? ROLES.it.name.split(' ')[0] : mail.role === 'SO' ? ROLES.so.name.split(' ')[0] : app.requester},</p>
          <p className="mail-p">{mail.intro}</p>

          {isContacts ? (
            <div className="mail-card">
              <div className="mail-card-row"><span>Application</span><b>{app.name}</b></div>
              <div className="mail-card-row"><span>Client ID</span><b>{app.id}</b></div>
              <div className="mail-card-row"><span>Client Code</span><b style={{ fontFamily:'monospace' }}>{app.clientCode || 'CLT-—'}</b></div>
              {(mail.changes || []).map(c => (
                <div className="mail-card-row" key={c.label} style={{ background:'var(--purple-50)' }}>
                  <span style={{ color:'var(--brand)', fontWeight:600 }}>{c.label}</span>
                  <b style={{ display:'flex', alignItems:'center', gap:7, flexWrap:'wrap', justifyContent:'flex-end' }}>
                    <span style={{ color:'var(--fg-muted)', textDecoration:'line-through', fontWeight:400 }}>{c.from}</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6"></path></svg>
                    <span style={{ color:'var(--brand)' }}>{c.to}</span>
                  </b>
                </div>
              ))}
            </div>
          ) : (
          <div className="mail-card">
            {detailRows.map(([l, r]) => (
              <div className="mail-card-row" key={l}><span>{l}</span><b>{r}</b></div>
            ))}
            {/* Key row — gated */}
            {keyVisible
              ? <div className="mail-card-row" style={{ background:'var(--purple-50)' }}><span style={{ color:'var(--brand)', fontWeight:600 }}>Integration Key</span><b style={{ fontFamily:'monospace', color:'var(--brand)' }}>{app.key || 'tlm_—'}</b></div>
              : (isActive && <div className="mail-card-row"><span>Integration Key</span><b style={{ color:'var(--fg-muted)', fontFamily:'monospace' }}>•••••••• <span style={{ fontFamily:'var(--font-body)', fontWeight:400, fontSize:11 }}>(visible to Product Owner only)</span></b></div>)}
          </div>
          )}

          {mail.offline && (
            <div className="mail-note"><Icon name="mail" size={16} /><span>This step is handled <b>offline</b> — please reply to this email with your test result (pass / fail and any notes).</span></div>
          )}

          <a className="mail-cta" onClick={onCta}>{mail.cta}<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6"></path></svg></a>
          <p className="mail-sub">Or copy this link: https://usermgmt.banpu.io/requests/{app.id}{mail.kind === 'po' ? '' : `?role=${isActive ? recip : mail.role}`}</p>

          <div className="mail-hr"></div>
          <p className="mail-foot">This is an automated message from Banpu User Management. Please do not reply directly unless this step is handled offline. © Banpu Public Company Limited.</p>
        </div>
      </div>
    </div>
  );
}

function Emails({ apps, openTask, toast }) {
  const [sel, setSel] = useState('it');
  const item = MAIL_LIST.find(m => m.kind === sel);
  const app = pickRep(apps, item.step);
  const mail = emailFor(sel, app);

  const onCta = () => {
    if (item.kind === 'po') { toast('Opening the request as Product Owner (offline step)'); }
    if (item.kind === 'active' || item.kind === 'contacts') { openTask(app, 'HR'); return; }
    openTask(app, item.role);
  };
  return (
    <div className="content-narrow fade-in">
      <div className="page-head">
        <div>
          <div className="page-title">Email templates</div>
          <div className="page-sub">The four notifications sent through the approval workflow. Each button opens the matching in-app task.</div>
        </div>
      </div>

      <div className="mail-grid">
        <div className="card" style={{ overflow:'hidden', alignSelf:'flex-start' }}>
          <div className="toolbar" style={{ borderBottom:'1px solid var(--border-subtle)' }}>
            <div className="section-title" style={{ margin:0, fontSize:15 }}><Icon name="mail" size={18} style={{ color:'var(--brand)' }} /> Workflow emails</div>
          </div>
          <div className="maillist">
            {MAIL_LIST.map(m => {
              const a = pickRep(apps, m.step);
              const mm = emailFor(m.kind, a);
              return (
                <button key={m.kind} className={`mailrow ${sel === m.kind ? 'on' : ''}`} onClick={() => setSel(m.kind)}>
                  <span className="mailrow-ic"><Icon name={m.icon} size={18} /></span>
                  <span className="mailrow-tt">
                    <span className="mailrow-top"><b>{m.kind === 'active' ? 'Step 7' : `Step ${m.step}`}</b> · to {m.role === 'ALL' ? 'HR · IT · PO' : m.role}{m.kind === 'po' && <span className="chip chip-info" style={{ padding:'1px 7px', fontSize:10, marginLeft:6 }}>offline</span>}{m.kind === 'active' && <span className="chip chip-active" style={{ padding:'1px 7px', fontSize:10, marginLeft:6 }}>broadcast</span>}</span>
                    <span className="mailrow-sub">{mm.subject}</span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        <EmailFrame mail={mail} app={app} onCta={onCta} />
      </div>
    </div>
  );
}

Object.assign(window, { Emails });

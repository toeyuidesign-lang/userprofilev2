# Handoff: User Management — Project Access Approval

> **This package replaces all earlier handoffs for this feature.** It reflects the current
> prototype after the latest round of stakeholder feedback: Azure AD–driven contacts, an
> autocomplete application name, PO-initiated requests with a shorter workflow variant,
> Azure AD–backed user management, and — new this round — a **unified request-detail view**
> that shows per-version approval workflow/details as switchable chips, a **base-version picker**
> when starting a new version of a multi-version app, an **in-draft badge** for a version already
> saved as a draft, and cleaned-up row-action icons for Draft/In Progress/Cancelled/Terminated
> requests. Implement this as the target spec — do not reference older handoff bundles.

---

## Overview

A back-office application for **Banpu** to manage project access requests — teams or external
parties that want to connect an application to the organisation's central User Management system.
A request can be created by **Product Owner (PO)** or **IT**, or by **HR** on someone's behalf.
It is then routed through a role-based approval chain (HR, IT, PO, SO) before going live. The
system also maintains **Master Data** (CIF tables, Country, Company, Job Level, Function, etc.)
and a **User Management** console backed by the company's **Azure AD** directory.

---

## About the Design Files

The HTML/JSX files in this bundle are **high-fidelity interactive prototypes** — design
references showing intended look, behaviour and interactions. They are **not** production code to
copy directly. The task is to **recreate these designs in the target React (or React Native)
codebase** using its established patterns and libraries — or, if no environment exists yet, choose
the most appropriate framework and implement there.

Open `User Management - Access Approval.html` in a browser to explore the full interactive flow.
Open `Approval Workflow - UX Spec.html` for the original swimlane specification (workflow step
numbering there is superseded by the tables below — see "What changed" and "The Workflow").
Open `Workflow Diagram.html` for a one-page visual overview of the full lifecycle, including the
Draft/Cancel/Terminate/Revision loop.

## Fidelity

**High-fidelity.** Production-intent Banpu colours, typography, spacing and component states.
- Brand colour `#482F92` (Banpu Purple-Blue); blue→green flame accents.
- **Kanit** (display/headings) + **Prompt** (body/UI) — both self-hosted / Google Fonts.
- All interaction states: hover, focus ring, active press, disabled.
- Animated sidebar collapse, modal enter/exit, toast, autocomplete dropdown.

---

## What changed in this round (latest)

1. **One detail page for every status — no separate "version workflow" screen.** Viewing an
   `Active` request with more than one version now opens the **same** `Review` page as any other
   request, with a **version-chip switcher** (`vswitch`) inserted between the header and the step
   tracker. Clicking a chip re-renders the step tracker, request-details card and scope grid for
   that version's snapshot (via `versionAsApp`); the action panel only appears for the **live**
   version — older/archived or terminated version chips show a read-only `ReadOnlyVersionPanel`
   ("This is a read-only snapshot. Switch to the live version to take action.") instead of
   duplicating the live action buttons. This replaced an earlier prototype pass that sent
   multi-version Active requests to a visually different page — that inconsistency is now fixed.
2. **Row-action icons are consistent and status-correct in the listing:**
   - **`Draft`** rows show **Edit + Delete only** — the View/eye icon is removed, since a draft
     hasn't entered the workflow yet and there's nothing to "view".
   - **`In Progress`** rows now use the same **eye/View icon** as every other status (previously a
     distinct "open task" icon) — clicking behaves identically; only the icon changed, for visual
     consistency across the table.
   - **`Terminated` / `Cancelled`** rows keep View · Duplicate (HR only) · Versions (if >1) ·
     History — unchanged, but see the new sample data below for cancel/terminate reasons now
     rendering correctly.
3. **"Create new version" is picker-aware.** Clicking the create-new-version icon on an `Active`
   row:
   - If the app has **only one version**, it behaves as before — opens the wizard directly.
   - If the app has **more than one version** and none is currently a pending draft, a
     **`NewVersionPickerModal`** opens first, listing every version (newest first, tagged with its
     status and "Latest" where applicable) in a `<select>`; the chosen version's snapshot data is
     pre-filled into the new version's form (`baseAppForNewVersion`). The **new version number
     always continues from the latest version** in the lineage, even if the user chose to base the
     content on an older one — the form shows an inline note ("Fields below are pre-filled from vN
     (not the latest, vM) — review and adjust") whenever the chosen base isn't the latest.
   - If a **newer version already exists as a saved Draft**, the picker is skipped entirely and
     the icon opens that existing draft directly, so the same branch is resumed rather than
     forking a second parallel draft.
4. **"vN in draft" badge**, mirroring the existing "vN in review" badge. When an app has a newer
   version sitting in `Draft` (not yet submitted), the listing shows a **`chip-draft` pill badge**
   next to the app name — clicking it jumps straight into editing that draft. This appears
   alongside (never instead of) the in-review badge; the two are mutually exclusive per app since
   only one newer-version branch can be open at a time.
5. **New sample data added to the prototype** to exercise all of the above (see `data.jsx`):
   - **Cancelled at step 3 (Submit to PO)** — a request cancelled by IT with a written reason,
     rendering in the existing cancelled-state stop-box on the detail page.
   - **Terminated, 3-version lineage** — a request with 3 prior versions where the final (v3) was
     terminated by IT with a reason; exercises the version-chip switcher on a non-Active request.
   - **3 resolved versions, v3 live Active** — exercises the base-version picker with no pending
     draft/review sibling (goes straight to the picker on "Create new version").
   - **v1 live Active + v2 already saved as Draft** — exercises the "vN in draft" badge and the
     draft-resume shortcut on "Create new version".
6. **Archived versions get their own read-only message** in the step tracker/action-panel area
   ("Archived version — kept for reference only, no longer editable"), distinct from the
   Cancelled/Terminated stop-box copy.

---

## What changed in the previous round

1. **Listener's endpoint removed everywhere** — the create form, review page, version diff, and
   emails no longer reference a listener/callback endpoint at all.
2. **Product Owner & Tech Lead now come from Azure AD.** Both are searched via a company-directory
   picker (`AzurePicker`) — selecting a person auto-fills their email **and job title** (job title
   replaces the old "Tel." field everywhere it appeared: create form, review summary, version
   diff, emails). **PO and Tech Lead must be different people** — each picker excludes whichever
   email is already chosen in the other field, and submission is blocked with an inline error if
   they match.
3. **Access model is no longer defaulted.** The create form starts with no access model selected;
   the user must actively choose API and/or File Base, with a validation error if none is picked.
4. **Application name is an autocomplete**, not free text. Typing filters a catalogue of
   suggested names; a name already registered to any **non-terminated** request is hidden from
   suggestions (it reappears once that project is Terminated).
5. **Active requests can have PO/Tech Lead reassigned in place.** From the request detail page,
   an **"Edit PO & Tech Lead"** action (bottom-right action panel only — no duplicate button
   elsewhere) opens a modal with two Azure AD pickers. Only these two contacts change; every other
   field is locked (use **New Version** for scope changes). Saving shows a success toast and
   triggers an email to HR, IT and the newly-assigned people showing the app name, Client ID, and
   the PO/Tech Lead change (old → new).
6. **PO can now create requests** (in addition to IT and HR). The approval chain and its **length
   depend on who created the request**:
   - **Created by PO or IT → 7 steps**, HR reviews & approves up front.
   - **Created by HR → 6 steps** — the separate HR-review step is skipped, since HR is already the
     requester (avoids self-approval). See "The Workflow" below for both tables.
   - **Requested by** defaults to the current user's profile, editable to name someone else.
   - **Received via has been removed** entirely.
   - The **Product Owner field has a "Same as requester" checkbox** (plain full-width row, no
     card styling) that copies the requester's identity into the PO field.
7. **Master Data step 4 (in the create wizard) no longer selects a Source System.** It now offers
   a flat, searchable list of **18 CIF table names** to select (Joblevel, JobLevelDoa, Company,
   Business Unit, Function, Subfunction1–7, Employee Status, Contract Type, PositionMaster,
   Business Stream, Work Location, Country) with a select-all header checkbox.
8. **User Management (Master Data menu) is Azure AD–backed.** Creating/editing a console user
   searches the Azure AD directory by name or email; the matched person's name, email and job
   title populate automatically — only **Role** and an optional note/status are chosen manually.
   **Country scope has been removed** from both the table and the create/edit form. Roles are now
   exactly six: **PO, HR, IT, SO, Super Admin, Viewer** (Viewer is read-only).
9. **Master Data menus in the sidebar are visible only to IT, Super Admin and HR.** PO, SO and
   Viewer do not see the Master Data nav group at all.
10. **The "New Request" button has been removed from the Dashboard.** Request creation happens
    from Registration (or My Tasks) only.
11. **Tech Lead is optional** at request-creation time (Product Owner remains required).
12. **Cancel is available to whichever role's turn it currently is, at every review step** — not
    just at the IT-confirm step. Whoever the action panel says "Your turn" for can cancel with a
    reason. HR additionally retains the ability to cancel a request even when it isn't HR's turn
    (HR is usually the original requester).
13. **"View email templates" link removed from My Tasks** — the Email Templates gallery is a
    prototype-only communication aid for developers and will not exist in production; it is not
    linked from any in-app workflow surface other than the sidebar nav.
14. A new **"Product Owner / Tech Lead changed"** email template was added to the gallery,
    showing the from→to change for both roles plus app name, Client ID and Client Code.

---

## The Workflow

A request's `step` field tracks its stage while `status = 'In Progress'`. **Which table applies
depends on who created the request** (`createdByRole`):

### 7-step chain — created by PO or IT

| Step | Owner | Where | What happens | On complete |
|---|---|---|---|---|
| 1 · Request | PO / IT | Create wizard | Captures requester, PO/Tech Lead (Azure AD), access scope; submits | `In Progress` step 2; email HR |
| 2 · HR Review & Approve | HR | Email → detail page | HR reviews the request & access scope, approves | step 3; email IT |
| 3 · Submit to PO | IT | Email → detail → **modal** | IT enters **Key + Client Code**, forwards to PO | step 4; email PO |
| 4 · PO Testing | PO | **Offline / email** | PO tests, replies pass/fail | pass → step 5; fail → back to step 3 |
| 5 · IT Confirm | IT | **Inline on detail page** (no modal) | IT confirms the form | step 6; email SO |
| 6 · SO Submit | SO | Email → **modal** | SO enters Key + Client Code (+ File Base fields); activates | `Active`; broadcast email |
| 7 · Finished | System | Auto | Provisioned; credentials issued | `Active` |

### 6-step chain — created by HR

| Step | Owner | Where | What happens | On complete |
|---|---|---|---|---|
| 1 · HR Request | HR | Create wizard | HR is the requester, so no separate HR-review step is needed; submits directly | `In Progress` step 2; email IT |
| 2 · Submit to PO | IT | Email → detail → **modal** | IT enters Key + Client Code, forwards to PO | step 3; email PO |
| 3 · PO Testing | PO | Offline / email | PO tests, replies pass/fail | pass → step 4; fail → back to step 2 |
| 4 · IT Confirm | IT | Inline on detail page | IT confirms the form | step 5; email SO |
| 5 · SO Submit | SO | Email → modal | SO enters Key + Client Code; activates | `Active`; broadcast email |
| 6 · Finished | System | Auto | Provisioned; credentials issued | `Active` |

**Status branches (both chains):**
- **`Cancelled`** — whoever's turn it currently is (per the tables above) can cancel their pending
  step with a required reason. HR can additionally cancel even outside their own turn.
- **`Terminated`** — IT or HR may terminate an `Active` request (reason required) — end of
  lifecycle for that Client ID.
- **`Archived`** — automatic: when a newer version of the same Client ID becomes `Active`, the
  prior version is archived.
- **`Draft`** — before submission; fully editable; can be deleted (discarded) with no workflow
  trace.
- **Revision loop** — from `Active`, **New Version** opens a fresh `Draft` under the same Client
  ID; it re-enters the same chain. The current version keeps serving until the new one activates.

See `Workflow Diagram.html` for the full lifecycle as a single visual (Create → Draft → Submit →
approval chain → Active, with Discard / Cancel / Terminate / Archive / Revision-loop branches).

**Role-action matrix** (what the detail-page action panel shows):
- **Creator (HR/IT/PO as applicable):** submit/edit/delete a Draft.
- **HR:** review & approve (7-step chain only); cancel any pending step (their own turn, or any
  time as the usual requester); Duplicate (Active only); Terminate (Active).
- **IT:** Submit to PO (modal); Confirm inline (no modal); Terminate (Active).
- **PO:** record test Pass / Report a problem (offline step).
- **SO:** Open & Submit (modal).
- **Active, any role viewing:** "Edit PO & Tech Lead" action (reassign contacts only).

---

## Screens / Views

### 1. App Shell

- `flex: row`, full height. **Sidebar** left (264 expanded / 78 collapsed). **Main** right: sticky
  **Topbar** (68px) + scrolling **Content** (`paddingTop 28`, `paddingHorizontal 24–44`).
- **Sidebar:** white, 1px right border `#e7e8e7`, width animates 200ms `cubic-bezier(.2,0,0,1)`.
  - Brand area: logo only (height 38px, `banpu/assets/main-logo.png`).
  - Nav items: `padding 10×12`, `radius 8`, 14px/600, color `#4c4a52`. Hover → bg `#f4f1fb`, color
    `#482F92`. Active → gradient `120deg #3c277c→#00AEEF`, white, brand shadow.
  - **Workspace group:** Dashboard · Registration · My Tasks · Email Templates *(prototype-only;
    remove or gate out entirely in production — see note in "What changed" #13)*.
  - **Master Data group** — **rendered only when the current role is IT, Super Admin or HR.**
    PO / SO / Viewer never see this nav group. Contains User Management + the CIF/company/job
    master menus.
  - Badges: Registration shows In-Progress count; My Tasks shows count awaiting the current role
    (bg `#DA1C5C`, white, pill).
- **Topbar:** hamburger; language pill; bell; **user box = role switcher** (demo-only — in
  production this reflects the signed-in user's real role, not a switcher). Clicking (in the demo)
  opens a menu listing HR / IT / PO / SO / Super Admin / Viewer.

---

### 2. Dashboard

- `ContentNarrow` (maxWidth 1600, centred). Page head is **title + subtitle only — no "New
  Request" button** (removed; creation happens from Registration/My Tasks).
- 4-col KPI grid (2 on ≤1100px): Active / **In Progress** / Draft / Terminated (illustrative
  totals), then a 1.6fr:1fr bottom grid — attention queue (`stageLabel(app)` per row) and a status
  breakdown.

---

### 3. Registration Listing

- **Toolbar:** search, layout toggle (Table / Grouped / Cards), status filter chips (All / In
  Progress / Draft / Active / Terminated / Cancelled). **"Create Request"** accent button shows
  for **HR, IT and PO**.
- **Row actions** depend on status & role (see `RowActions` in `listing.jsx`):
  - **`Draft`** → Edit · Delete only. **No View/eye icon** — a draft hasn't entered the workflow.
  - **`In Progress`** → **View** (eye icon, same as all other statuses) · Versions (if >1) ·
    History. No edit while in the workflow.
  - **`Terminated` / `Cancelled`** → View · Duplicate (HR only) · Versions (if >1) · History.
  - **`Active`** → View (opens the shared detail page — version-chip switcher inline if >1
    version) · **Create new version** (blocked/disabled if a newer version is already open in the
    workflow; opens the base-version picker if >1 version exists and none is pending; resumes an
    existing draft if one is already open) · Duplicate (HR only) · Versions (if >1) · History.
  - A **"vN in review"** or **"vN in draft"** badge appears next to the app name whenever a newer
    version is mid-workflow or saved as a draft; clicking it jumps straight to that version/draft.

---

### 4. Create / Edit / Duplicate / New Version — Wizard

- **Tab strip stepper:** Basic Info · Row Selection · Column Selection · **Master Data**.
  API-only requests **skip and disable** the Master Data tab.
- **Workflow-variant banner** at the top of Basic Info (not shown when editing): tells the creator
  which chain applies —
  - *Creating as HR* → blue banner: "you are the requester, so this skips the separate HR review
    step… the shorter **6-step** flow."
  - *Creating as IT / Product Owner* → purple banner: "HR reviews & approves this request before
    IT provisions it — the standard **7-step** flow."
- **Tab 1 — Basic Info:**
  - **Request source:** "Requested by" — a text field **pre-filled with the current user's name**
    (from their profile), editable to raise the request on someone else's behalf. *(Received via
    has been removed entirely.)*
  - **Application details:** Application name is an **autocomplete** (type to filter suggestions;
    already-registered non-terminated names are excluded) + Client ID (disabled, auto-assigned on
    submit).
  - **Contacts** section:
    - A full-width plain row (no card/border) with a checkbox: **"Product Owner is the same as
      requester ({name})"** — ticking it copies the requester's Azure AD identity into the PO
      field.
    - **Product Owner** (required) and **Tech Lead** (optional) sit **side by side in the same
      row**, each an `AzurePicker` — search by name/email, selecting fills email + job title
      automatically (read-only display card with a "Change" affordance). **Each picker excludes
      the person already chosen in the other field**; picking the same person for both is blocked
      with an inline error ("Tech Lead must be a different person from the Product Owner").
  - **Access:** two choice cards (API / File Base) — **nothing pre-selected**; at least one is
    required to continue.
- **Duplicate banner** / **New-version banner**: unchanged in spirit — pre-fill fields, require a
  changelog on new version.
- **Footer:** Back (ghost) + Continue (primary) / Submit (accent), guarded by a **Confirm dialog**.

---

### 5. Request Detail / Workflow (the shared role page)

- **Header:** name + Client ID + requester/submitted; layout toggle (Split/Focus); **Duplicate**
  (HR + Active only); **History** (hidden for Draft). *(No "Edit PO & Tech Lead" button here — it
  lives only in the action panel, to avoid duplicating the control — see #2 in "What changed".)*
  When the app has more than one version, a **`vbadge`** pill next to the title shows which
  version is currently selected.
- **Version-chip switcher (`vswitch`)** — rendered directly below the header, **only when the app
  has more than one version**. One pill per version, newest first, each showing `vN` + a
  `StatusChip` for that version's own status (Active/Archived/In Progress/Terminated/etc.).
  Clicking a chip is purely a local selection (`selV` state in `Review`) — it does **not**
  navigate away — and re-renders everything below (step tracker, request-details card, scope
  grid) from that version's snapshot via `versionAsApp(app, version)`.
- **Step tracker:** horizontal tracker sized to the **applicable chain length (6 or 7 nodes)**
  for that specific request — read from its `createdByRole`. Node states: done / current / stop
  (Terminated/Cancelled) / idle. **Archived** versions render every node as done with no stop
  state (they completed their own chain before being superseded).
- **Action panel** (`WorkflowPanel`, sticky in Split): step- and role-specific body (see the
  Role-action matrix above) — **shown only when the selected version chip is the live version**.
  Whenever it is the viewing role's turn, a **Cancel request** control is available under a
  divider beneath the primary action, at every pending step — not just one designated step. When
  viewing an **Active** request's live version, the panel shows an **"Edit PO & Tech Lead"**
  button (opens the reassignment modal) alongside Terminate (IT/HR only).
- **Read-only version panel (`ReadOnlyVersionPanel`)** — shown in the action-panel slot whenever
  a **non-live** version chip is selected (Archived, Terminated, or a past Cancelled attempt):
  version number + `StatusChip`, that version's changelog text, and a hint ("This is a read-only
  snapshot. Switch to the live version to take action."). No action buttons render here — actions
  only ever apply to the current live version.
- **Cancelled / Terminated stop-box:** unchanged copy pattern, now reliably fed by `cancelReason`/
  `cancelBy` or `termReason`/`termBy` on the sample data added this round.
- **Archived stop notice:** a distinct purple-tinted box ("Archived version — superseded by a
  newer version and kept for reference only, no longer editable") for any version chip whose
  status is `Archived`.
- **Scope grid:** Row Selection, Column Selection (chips + PII), Master Data (CIF table chips, or
  "not used" for API-only requests), and Contacts (PO/Tech Lead with job titles, no endpoint row) —
  computed from whichever version snapshot is currently selected.

---

### 6. My Tasks (role-scoped inbox)

- Page head "Viewing as {name} ({ROLE})" + blurb per role. **No "View email templates" link**
  (removed — prototype-only surface, see "What changed" #13).
- **Awaiting {ROLE}** card + **Your drafts** card (creator roles), unchanged in structure.

---

### 7. Email Templates (gallery — prototype/dev communication aid only)

Not part of the production navigation from any in-app workflow surface (only reachable via the
sidebar in this prototype, for developer reference). Six templates: HR review, IT submit-to-PO, PO
test (offline), SO submit, Activated (broadcast to HR/IT/PO, Key visible to PO only), and
**Product Owner / Tech Lead changed** (new — shows old→new PO and Tech Lead, app name, Client ID,
Client Code; sent to HR, IT and the newly-assigned people).

---

### 8–12. Version Detail / Compare / History, Credential Modal, Reason & Confirm Dialogs, Edit
PO & Tech Lead Modal

Unchanged in structure from the prior handoff **except**: no endpoint field anywhere; Key/Client
Code panels otherwise identical. The **new Edit PO & Tech Lead modal** (`EditContactsModal` in
`modals.jsx`) shows two Azure AD pickers (with the same person-exclusion rule as the create form),
a live change-preview ("Product Owner: Praphan Tula → New Name"), and a "Save & notify" button
disabled until a real change is made and the two contacts differ.

---

### 13. User Management (Master Data menu)

- **List:** Name · Email · Job title · Role columns (**no Country scope column**).
- **Create/Edit:** `MDUserForm` — a single **Azure AD picker** (search name or email) replaces all
  manual identity fields; selecting a person shows a read-only card with name/email/job title.
  Only **Role** (select: PO / HR / IT / SO / Super Admin / Viewer) and an optional note + status
  are chosen manually. Editing an existing user disables re-picking the identity (only role/status/
  note change).

### 14. Other Master Data menus

Country / Company / Job Level / Function / Job Status — unchanged CRUD pattern. **Step 4 of the
create wizard** (a different surface — see #7 above) now sources its table picklist from the same
CIF table list as these menus' domain, but as a flat checklist rather than a menu-driven CRUD
screen.

---

## Interactions & Behaviour

- **Autocomplete (`Autocomplete` component):** debounced-free client-side filter, keyboard
  navigation (↑/↓/Enter/Esc), click-outside to close. Used for Application name.
- **Azure AD picker (`AzurePicker` component):** search-as-you-type against a directory list;
  results show avatar-initials, name, email, job title; picking fills a read-only summary card;
  `exclude` prop removes already-chosen emails (used to enforce PO ≠ Tech Lead) from the result
  set entirely (not just disabled).
- **Confirm-before-commit:** forward actions (submit draft, IT confirm, PO pass, HR approve) open
  a ConfirmDialog before committing.
- **Unique application name:** validated against the catalogue/other non-terminated requests
  before advancing past Basic Info.
- **Cancel-anytime-at-your-turn:** the action panel's Cancel control is now driven by "is it my
  turn" (`pendingRole(app) === role`) rather than a single hardcoded step, so it appears
  identically at every stage of both the 6-step and 7-step chains.
- **Edit PO & Tech Lead save:** patches only `owner/ownerEmail/ownerTitle/lead/leadEmail/
  leadTitle`; shows a success toast; in production, triggers an email to HR, IT and the newly
  assigned PO/Tech Lead with app name, Client ID, and the before/after names for both roles.
- **Toast:** fixed bottom-centre, `#232127`/white pill, auto-dismiss ~2800ms.

---

## State Management

```typescript
interface AppState {
  view: AppView;
  sidebarCollapsed: boolean;
  role: ViewAsRole;                 // PO | HR | IT | SO (workflow) — drives the whole UI
  apps: Application[];
  editingApp: Application | null;
  reviewId: string | null;
  historyApp: Application | null;
  versionsApp: Application | null;
  verView: { app; version } | null;
  cmpView: { app; target } | null;
  cred: { app; stage: CredentialStage } | null;
  reason: { app; kind: ReasonKind } | null;
  editContacts: Application | null;   // Edit PO & Tech Lead modal target
  confirm: ConfirmDialogConfig | null;
  toast: string;
  listingLayout: 'table' | 'board' | 'cards';
  reviewLayout: 'split' | 'focus';
}
```

Derived helpers (in `data.jsx`): `workflowFor(app)` (returns the 6- or 7-step array based on
`createdByRole`), `stepByKey(app, key)`, `STEP_OF(app)`, `STEP_META(app, n)`, `pendingRole(app)`,
`stageLabel(app)`, `versionsOf(app)`, `versionAsApp(app, v)` (project a single lineage version's
detail onto an app-shaped snapshot, used by both the version-chip switcher and the version-detail
pages), **`baseAppForNewVersion(app, chosenVersion)`** (new — pre-fills a new-version form from a
chosen prior version while always incrementing the version number from the latest in the lineage,
stamping `_basedOnVersion` when the choice differs from latest), `hasOpenVersion(app)` (is a newer
version already In Progress or Draft), `emailFor(kind, app)`, `auditTrail(app)`,
`jobTitleFor(email)`, `adPerson(name, email)`, `availableAppNames(apps, currentId)`.

---

## Design Tokens & Types

`tokens.ts` and `types.ts` in this bundle have been updated for the current model — see the files
directly. Highlights:

- **`AzureADPerson`** — `{ name, email, jobTitle, dept }`, sourced from a mock `AZURE_AD` directory
  array in `data.jsx` (`jobTitleFor`, `adPerson` helpers). In production this is a real Azure AD
  Graph lookup.
- **`Application`** gains `ownerTitle`, `leadTitle`, `createdByRole ('HR'|'IT'|'PO')`,
  `sameAsRequester`; loses `ownerTel`, `leadTel`, `endpoint`, `requestedVia`.
- **`WORKFLOW_STD`** (7 steps) and **`WORKFLOW_HR`** (6 steps) replace the single `WORKFLOW` array;
  `workflowFor(app)` selects the right one.
- **`Role`** for User Management is now `'PO' | 'HR' | 'IT' | 'SO' | 'Super Admin' | 'Viewer'`
  (distinct from the 4 workflow actor roles HR/IT/PO/SO used by `pendingRole`/`WorkflowStep`).
- **`MasterDataMenuKey`** unchanged; `MasterDataMenuConfig` gains `azureUser?: boolean` and
  `roleOptions?: string[]` (used by the `um` / User Management config).
- CIF table constant: `CIF_TABLES` — 18 entries (see `data.jsx`).

Status → chip colours and role colours are unchanged from the previous handoff (see `tokens.ts`).

---

## Assets

| Asset | Source | Usage |
|---|---|---|
| `banpu/assets/main-logo.png` | bundle | Sidebar (logo only), email band |
| `banpu/assets/footer-logo_white.png` | bundle | Dark backgrounds |
| Icons | Lucide-style, stroke 1.75px (`components.jsx` `Icon`) | All UI icons |
| Fonts | Kanit + Prompt (`banpu/fonts/*.woff2`, or Google Fonts on web) | All text |

---

## Files in This Bundle

| File | Description |
|---|---|
| `User Management - Access Approval.html` | Main interactive prototype — open in a browser |
| `Approval Workflow - UX Spec.html` | Original swimlane spec (superseded numbering — use README tables) |
| `Workflow Diagram.html` | One-page visual: full lifecycle loop (Create → Draft → chain → Active, + Discard/Cancel/Terminate/Archive/Revision) |
| `app.css` | All layout/component/utility styles |
| `components.jsx` | Shared primitives incl. **`Autocomplete`**, **`AzurePicker`** (new) |
| `data.jsx` | Mock data + `AZURE_AD` directory, `CIF_TABLES`, `APP_CATALOG`, `WORKFLOW_STD`/`WORKFLOW_HR`, `workflowFor`, ROLES, helpers |
| `shell.jsx` | Sidebar (role-gated Master Data group) + Topbar |
| `dashboard.jsx` | Dashboard (no New Request button) |
| `listing.jsx` | Registration listing — Create button visible to HR/IT/PO |
| `rulebuilder.jsx` | Visual rule builder (Tab 2, unchanged) |
| `createform.jsx` | Wizard — Azure AD contacts, autocomplete name, no default access, workflow-variant banner |
| `review.jsx` | Request detail/workflow — chain-length-aware tracker, cancel-at-your-turn, Edit PO & Tech Lead entry point |
| `modals.jsx` | History, Version, CredentialModal, ReasonModal, ConfirmDialog, EditContactsModal, **`NewVersionPickerModal`** (new — choose which version to base a new version on) |
| `emails.jsx` | Email gallery incl. **"PO / Tech Lead changed"** template (new) |
| `versions.jsx` | Version Detail + Compare pages (no endpoint field) |
| `tasks.jsx` | My Tasks (email-templates link removed) |
| `masterdata-data.jsx` / `masterdata.jsx` | Master Data config + CRUD, incl. Azure AD–backed `MDUserForm` for User Management |
| `tweaks-panel.jsx` | Prototype tweak panel — not for production |
| `tokens.ts` | Design tokens + status/role colour maps |
| `types.ts` | TypeScript interfaces for the current model |
| `banpu/colors_and_type.css` | Banpu Design System CSS tokens (colour source of truth) |
| `banpu/assets/`, `banpu/fonts/` | Logos + Kanit/Prompt fonts |

---

## React / React Native Implementation Notes

1. **Azure AD integration is the one real backend dependency introduced this round.** Replace the
   mock `AZURE_AD` array + `AzurePicker`'s client-side filter with a real Graph API
   people/users search (debounced, server-side), returning `{ name, email, jobTitle }` at minimum.
   Enforce PO ≠ Tech Lead server-side too, not just in the picker's `exclude` prop.
2. **Application-name availability must be server-checked**, not just filtered against a local
   mock catalogue — race conditions between two people naming an app are a real concern.
3. **Workflow length is data-driven per request** (`createdByRole` → 6 or 7 steps) — do not
   hardcode step counts anywhere in navigation, progress UI, or notification logic.
4. **Role model has two dimensions**: the **console/user role** (PO/HR/IT/SO/Super Admin/Viewer —
   used for login/permissions/nav visibility) vs. the **workflow actor role** on a given request
   (HR/IT/PO/SO/System — used by `pendingRole`/`STEP_META`). A Super Admin or Viewer is never a
   workflow actor; map console role → allowed actions carefully (Viewer = read-only everywhere).
5. **Master Data nav gating** is a simple role allow-list (IT / Super Admin / HR) — enforce it
   server-side (API authorization), not just by hiding the nav item.
6. **Cancel button visibility** is computed, not configured per-step — implement it as "does the
   current actor match `pendingRole(app)` for this app's chain" so it stays correct automatically
   for both chain lengths and any future step reordering.
7. **Edit PO & Tech Lead** should be a narrowly-scoped API endpoint (updates exactly two
   people-fields + fires one notification) — do not route it through the general request-update
   path, to guarantee "every other field is locked" holds server-side too.
8. **Email Templates gallery is dev/QA tooling only** — do not ship it as an in-app screen;
   implement the actual email sends server-side using the copy/layout shown there as the design
   reference.
9. **Version-chip selection is client-side, read-only navigation** — selecting a chip must never
   mutate server state; it only changes which version's snapshot is rendered. Only actions taken
   while the **live** version chip is selected should be allowed to call mutating endpoints;
   enforce this server-side (reject actions targeting a non-live version) in addition to hiding
   the action panel client-side.
10. **The new-version base-picker is a UX convenience only** — the resulting new version's number
    must always be computed server-side as `max(existing versions) + 1`, regardless of which prior
    version's data was used to pre-fill the form. Persist which version was used as the basis
    (`_basedOnVersion`) for audit purposes even though the new version's *content* can differ once
    the user edits it.
11. **Resuming an existing draft instead of forking a new one**: before offering "Create new
    version" as an action, check server-side whether a Draft already exists for
    `(clientId, version > liveVersion)` and route straight to it — never allow two simultaneous
    draft branches for the same Client ID from the UI.
12. Everything else (navigation, modals, shadows/gradients/fonts loading, sticky headers, tables →
    FlatList on native) follows the same guidance as before — see inline comments in each `.jsx`
    file for exact measurements.

---

> Prototype data, names and figures are illustrative. The **Banpu Design System** is the binding
> visual reference; pull exact tokens from `banpu/colors_and_type.css`.

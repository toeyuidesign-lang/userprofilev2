/* ============================================================
   Visual Rule Builder (Tab 2 — Row Selection)
   Friendly query builder: AND / OR / NOT, nested groups,
   live plain-English + code preview. Built for non-coders.
   ============================================================ */
let _uid = 100;
const uid = () => ++_uid;

const newCond = (field = 'Company Code') => ({
  id: uid(), type:'cond', not:false, field, op:'=', value:(VALUE_OPTIONS[field] || [''])[0] || ''
});
const newGroup = (match = 'AND', children) => ({
  id: uid(), type:'group', match, children: children || [newCond()]
});

const DEFAULT_TREE = newGroup('AND', [
  { id: uid(), type:'cond', not:false, field:'Company Code', op:'=', value:'BPP' },
  { id: uid(), type:'group', match:'OR', children:[
    { id: uid(), type:'cond', not:false, field:'Country', op:'=', value:'Thailand' },
    { id: uid(), type:'cond', not:false, field:'Country', op:'=', value:'Indonesia' },
  ]},
  { id: uid(), type:'cond', not:true, field:'Employment Type', op:'=', value:'Outsource' },
]);

/* recursive tree ops (immutable) */
function treeUpdate(node, id, fn) {
  if (node.id === id) return fn(node);
  if (node.type === 'group') return { ...node, children: node.children.map(c => treeUpdate(c, id, fn)) };
  return node;
}
function treeRemove(node, id) {
  if (node.type !== 'group') return node;
  return { ...node, children: node.children.filter(c => c.id !== id).map(c => treeRemove(c, id)) };
}
function treeAdd(node, groupId, child) {
  if (node.id === groupId && node.type === 'group') return { ...node, children:[...node.children, child] };
  if (node.type === 'group') return { ...node, children: node.children.map(c => treeAdd(c, groupId, child)) };
  return node;
}

/* serialize to readable code */
function toCode(node) {
  if (node.type === 'cond') {
    const opMap = { '=':'==','≠':'!=','≥':'>=','≤':'<=','contains':'~','in':'IN' };
    const expr = `${node.field.replace(/\s+/g,'_')} ${opMap[node.op] || node.op} "${node.value}"`;
    return node.not ? `NOT(${expr})` : expr;
  }
  const join = ` ${node.match} `;
  const inner = node.children.map(toCode).join(join);
  return `(${inner})`;
}
function toEnglish(node, top = true) {
  if (node.type === 'cond') {
    const v = node.value || '…';
    const s = `${node.field} ${node.op} "${v}"`;
    return node.not ? `not (${s})` : s;
  }
  const word = node.match === 'AND' ? ' and ' : ' or ';
  const inner = node.children.map(c => toEnglish(c, false)).join(word);
  return top ? inner : `( ${inner} )`;
}

function ValueControl({ cond, onChange }) {
  const opts = VALUE_OPTIONS[cond.field];
  if (opts) {
    return (
      <select value={cond.value} onChange={e => onChange({ value:e.target.value })}>
        {opts.map(o => <option key={o}>{o}</option>)}
      </select>
    );
  }
  return <input className="input" style={{ width:160, padding:'8px 12px' }} value={cond.value} placeholder="Enter value"
    onChange={e => onChange({ value:e.target.value })} />;
}

function Condition({ node, index, parentMatch, onChange, onRemove, canRemove }) {
  return (
    <div style={{ display:'flex', alignItems:'center', gap:10 }}>
      <div style={{ width:54, flex:'0 0 54px', textAlign:'right' }}>
        {index === 0
          ? <span style={{ fontSize:12, color:'var(--fg-muted)', fontWeight:600 }}>Where</span>
          : <span className={`conn ${parentMatch === 'AND' ? 'conn-and' : 'conn-or'}`}>{parentMatch}</span>}
      </div>
      <div className="cond" style={{ flex:1 }}>
        <button type="button" className={`conn ${node.not ? 'conn-not' : ''}`}
          onClick={() => onChange({ not: !node.not })}
          style={{ background: node.not ? undefined : 'var(--grey-100)', color: node.not ? undefined : 'var(--fg-muted)', cursor:'pointer' }}
          title="Toggle NOT">{node.not ? 'NOT' : 'is'}</button>
        <select value={node.field} onChange={e => onChange({ field:e.target.value, value:(VALUE_OPTIONS[e.target.value] || [''])[0] || '' })}>
          {FIELD_OPTIONS.map(f => <option key={f}>{f}</option>)}
        </select>
        <select className="opbtn" value={node.op} onChange={e => onChange({ op:e.target.value })}>
          {OPERATORS.map(o => <option key={o}>{o}</option>)}
        </select>
        <ValueControl cond={node} onChange={onChange} />
        {canRemove && <button type="button" className="delcond" onClick={onRemove} title="Remove"><Icon name="trash" size={16} /></button>}
      </div>
    </div>
  );
}

function Group({ node, depth, onUpdate, onRemove, onAddCond, onAddGroup, canRemove }) {
  return (
    <div className="group" style={{ background: depth % 2 ? 'var(--blue-50)' : 'var(--purple-50)', borderColor: depth % 2 ? 'var(--blue-300)' : 'var(--purple-200)' }}>
      <div className="group-head">
        <span className="group-tag">{depth === 0 ? 'Rule group' : 'Sub-group'}</span>
        <span style={{ fontSize:13, color:'var(--fg-secondary)', fontWeight:500 }}>Match</span>
        <div className="logic-toggle">
          <button type="button" className={`and ${node.match === 'AND' ? 'on' : ''}`} onClick={() => onUpdate({ match:'AND' })}>ALL (AND)</button>
          <button type="button" className={`or ${node.match === 'OR' ? 'on' : ''}`} onClick={() => onUpdate({ match:'OR' })}>ANY (OR)</button>
        </div>
        <span style={{ fontSize:12.5, color:'var(--fg-muted)' }}>of the conditions below</span>
        {canRemove && <button type="button" className="delcond" style={{ marginLeft:'auto' }} onClick={onRemove} title="Remove group"><Icon name="trash" size={16} /></button>}
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {node.children.map((c, i) => c.type === 'cond'
          ? <Condition key={c.id} node={c} index={i} parentMatch={node.match}
              canRemove={node.children.length > 1}
              onChange={(patch) => onUpdate(null, c.id, (n) => ({ ...n, ...patch }))}
              onRemove={() => onUpdate(null, c.id, null, true)} />
          : (
            <div key={c.id} style={{ display:'flex', alignItems:'flex-start', gap:10 }}>
              <div style={{ width:54, flex:'0 0 54px', textAlign:'right', paddingTop:18 }}>
                {i === 0 ? <span style={{ fontSize:12, color:'var(--fg-muted)', fontWeight:600 }}>Where</span>
                  : <span className={`conn ${node.match === 'AND' ? 'conn-and' : 'conn-or'}`}>{node.match}</span>}
              </div>
              <div style={{ flex:1 }}>
                <Group node={c} depth={depth + 1} canRemove
                  onUpdate={onUpdate} onRemove={() => onUpdate(null, c.id, null, true)}
                  onAddCond={onAddCond} onAddGroup={onAddGroup} />
              </div>
            </div>
          )
        )}
      </div>
      <div style={{ display:'flex', gap:10, marginTop:14, paddingLeft:64 }}>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => onAddCond(node.id)}><Icon name="plus" size={15} /> Condition</button>
        {depth < 2 && <button type="button" className="btn btn-ghost btn-sm" onClick={() => onAddGroup(node.id)}><Icon name="layers" size={15} /> Sub-group</button>}
      </div>
    </div>
  );
}

function RuleBuilder({ tree, setTree }) {
  // onUpdate signature: (patch) for root-update, or (null, id, fn, isRemove) for child ops
  const handle = (patch, id, fn, isRemove) => {
    if (id == null) { setTree({ ...tree, ...patch }); return; }
    if (isRemove) { setTree(treeRemove(tree, id)); return; }
    setTree(treeUpdate(tree, id, fn));
  };
  const addCond = (gid) => setTree(treeAdd(tree, gid, newCond()));
  const addGroup = (gid) => setTree(treeAdd(tree, gid, newGroup('OR')));

  return (
    <div>
      <div className="section-title"><Icon name="filter" size={20} style={{ color:'var(--brand)' }} /> Row Selection — Validation Rules</div>
      <div className="section-desc">Define which employee records this application is allowed to read. Build conditions visually — no code required.</div>

      {/* plain english summary */}
      <div style={{ background:'var(--green-50)', border:'1px solid var(--green-100)', borderRadius:'var(--radius-md)', padding:'14px 18px', marginBottom:18, display:'flex', gap:12 }}>
        <span style={{ color:'var(--green-600)', flex:'0 0 auto' }}><Icon name="check" size={20} /></span>
        <div style={{ fontSize:14, color:'var(--fg)', lineHeight:1.6 }}>
          <b>In plain words:</b> include a record when&nbsp;
          <span style={{ fontWeight:600, color:'var(--brand-strong)' }}>{toEnglish(tree)}</span>.
        </div>
      </div>

      <Group node={tree} depth={0} canRemove={false}
        onUpdate={handle}
        onAddCond={addCond} onAddGroup={addGroup} />

      <div style={{ marginTop:18 }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
          <Icon name="server" size={16} style={{ color:'var(--fg-muted)' }} />
          <span style={{ fontSize:13, fontWeight:600, color:'var(--fg-secondary)' }}>Generated expression</span>
          <span className="muted" style={{ fontSize:12 }}>(auto-generated, read-only)</span>
        </div>
        <div className="preview-box">{toCode(tree)}</div>
      </div>
    </div>
  );
}

Object.assign(window, { RuleBuilder, DEFAULT_TREE, newGroup });

/* ============================================================
   Shared primitives + icon set (Lucide-style, 1.75 stroke)
   ============================================================ */
const { useState, useEffect, useRef, useMemo } = React;

/* ---------------- Icons ---------------- */
const PATHS = {
  home:'M3 10.5 12 3l9 7.5M5 9.5V21h14V9.5',
  users:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M22 21v-2a4 4 0 0 0-3-3.87M16 3.13A4 4 0 0 1 16 11',
  flag:'M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7',
  building:'M3 21h18M5 21V7l8-4v18M19 21V11l-6-4M9 9h0M9 13h0M9 17h0',
  briefcase:'M20 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2',
  gitbranch:'M6 3v12M18 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM15 6a9 9 0 0 1-9 9',
  function:'M9 17H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H9M3 9h18',
  activity:'M22 12h-4l-3 9L9 3l-3 9H2',
  grid:'M3 3h7v7H3zM14 3h7v7h-7zM14 14h7v7h-7zM3 14h7v7H3z',
  gauge:'M12 14l4-4M3.34 19a10 10 0 1 1 17.32 0',
  layers:'M12 2 2 7l10 5 10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
  plus:'M12 5v14M5 12h14',
  download:'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  search:'M21 21l-4.35-4.35M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z',
  edit:'M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z',
  history:'M3 3v5h5M3.05 13A9 9 0 1 0 6 5.3L3 8M12 7v5l4 2',
  eye:'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  chevL:'M15 18l-6-6 6-6',
  chevR:'M9 18l6-6-6-6',
  chevD:'M6 9l6 6 6-6',
  chevU:'M18 15l-6-6-6 6',
  close:'M18 6 6 18M6 6l12 12',
  check:'M20 6 9 17l-5-5',
  menu:'M3 6h18M3 12h18M3 18h18',
  logout:'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  mail:'M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2zM22 6 12 13 2 6',
  phone:'M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z',
  link:'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71',
  server:'M5 3h14a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zM5 13h14a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2zM7 7h0M7 17h0',
  settings:'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z',
  filter:'M22 3H2l8 9.46V19l4 2v-8.54z',
  clock:'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 6v6l4 2',
  alert:'M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h0',
  filecheck:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M9 15l2 2 4-4',
  fileplus:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6M12 18v-6M9 15h6',
  send:'M22 2 11 13M22 2l-7 20-4-9-9-4z',
  rotate:'M3 2v6h6M3.51 9a9 9 0 1 0 2.13-3.36L3 8',
  x2:'M9 9l6 6M15 9l-6 6',
  trash:'M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2',
  bell:'M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0',
  user:'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8',
  copy:'M9 9h11a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2zM5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1',
  calendar:'M8 2v4M16 2v4M3 10h18M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
  trend:'M22 7 13.5 15.5 8.5 10.5 2 17M16 7h6v6',
  shield:'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  inbox:'M22 12h-6l-2 3h-4l-2-3H2M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z',
  dots:'M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM12 6a1 1 0 1 0 0-2 1 1 0 0 0 0 2zM12 20a1 1 0 1 0 0-2 1 1 0 0 0 0 2z',
};
function Icon({ name, size = 20, className = '', style = {}, fill = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"
      className={className} style={style}>
      {(PATHS[name] || '').split('M').filter(Boolean).map((d, i) => <path key={i} d={'M' + d} />)}
    </svg>
  );
}

/* ---------------- Button ---------------- */
function Btn({ variant = 'primary', size, icon, iconRight, children, className = '', ...p }) {
  const cls = `btn btn-${variant} ${size ? 'btn-' + size : ''} ${className}`;
  return (
    <button className={cls} {...p}>
      {icon && <Icon name={icon} size={size === 'sm' ? 16 : 18} />}
      {children}
      {iconRight && <Icon name={iconRight} size={size === 'sm' ? 16 : 18} />}
    </button>
  );
}

/* ---------------- Status chip ---------------- */
const STATUS = {
  Draft:        { cls: 'chip-draft' },
  'In Progress':{ cls: 'chip-progress' },
  Pending:      { cls: 'chip-pending' },
  Approved:     { cls: 'chip-approved' },
  Rejected:     { cls: 'chip-rejected' },
  Revise:       { cls: 'chip-revise' },
  Active:       { cls: 'chip-active' },
  Archived:     { cls: 'chip-archived' },
  Terminated:   { cls: 'chip-terminated' },
  Cancelled:    { cls: 'chip-cancelled' },
  Inactive:     { cls: 'chip-inactive' },
};
function StatusChip({ status, dot = true }) {
  const s = STATUS[status] || STATUS.Draft;
  return <span className={`chip ${s.cls}`}>{dot && <span className="dot"></span>}{status}</span>;
}

/* ---------------- Field ---------------- */
function Field({ label, required, hint, error, children, full, style }) {
  return (
    <div className="field" style={{ gridColumn: full ? '1 / -1' : 'auto', ...style }}>
      {label && <label>{label}{required && <span className="req">*</span>}</label>}
      {children}
      {hint && !error && <span className="hint">{hint}</span>}
      {error && <span className="err-msg"><Icon name="alert" size={13} />{error}</span>}
    </div>
  );
}
function TextInput({ icon, error, ...p }) {
  if (icon) return (
    <div className="inputgroup">
      <span className="adorn"><Icon name={icon} size={16} /></span>
      <input className={`input ${error ? 'err' : ''}`} {...p} />
    </div>
  );
  return <input className={`input ${error ? 'err' : ''}`} {...p} />;
}
function Select({ children, error, ...p }) {
  return <select className={`selectfield ${error ? 'err' : ''}`} {...p}>{children}</select>;
}

/* ---------------- Autocomplete (type-ahead select) ----------------
   Free text with a suggestion dropdown. `options` are the selectable
   suggestions; typing filters them. Picking one fills the field. */
function Autocomplete({ value, onChange, options = [], icon, error, placeholder, emptyNote }) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const wrapRef = useRef(null);
  const q = (value || '').toLowerCase().trim();
  const matches = options.filter(o => o.toLowerCase().includes(q)).slice(0, 8);
  useEffect(() => {
    const h = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  const pick = (o) => { onChange(o); setOpen(false); setActive(-1); };
  return (
    <div className="ac-wrap" ref={wrapRef} style={{ position:'relative' }}>
      <div className={icon ? 'inputgroup' : ''}>
        {icon && <span className="adorn"><Icon name={icon} size={16} /></span>}
        <input className={`input ${error ? 'err' : ''}`} value={value} placeholder={placeholder}
          autoComplete="off"
          onChange={e => { onChange(e.target.value); setOpen(true); setActive(-1); }}
          onFocus={() => setOpen(true)}
          onKeyDown={e => {
            if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive(a => Math.min(matches.length - 1, a + 1)); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(0, a - 1)); }
            else if (e.key === 'Enter' && open && active >= 0 && matches[active]) { e.preventDefault(); pick(matches[active]); }
            else if (e.key === 'Escape') setOpen(false);
          }} />
      </div>
      {open && (
        <div className="ac-menu">
          {matches.length === 0
            ? <div className="ac-empty">{q ? (emptyNote || 'No matches available.') : 'Start typing to search…'}</div>
            : matches.map((o, i) => (
              <button key={o} type="button" className={`ac-item ${i === active ? 'on' : ''}`}
                onMouseEnter={() => setActive(i)} onMouseDown={(e) => { e.preventDefault(); pick(o); }}>
                <Icon name="search" size={14} style={{ color:'var(--fg-muted)' }} />
                <span>{o}</span>
              </button>
            ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- Azure AD person picker ----------------
   Search the company Azure AD directory by name or email; picking a
   person fills their email + job title automatically (read-only). */
function AzurePicker({ value, onSelect, onClear, placeholder = 'Search name or email\u2026', error, disabled, exclude = [] }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);
  const dir = (typeof AZURE_AD !== 'undefined' ? AZURE_AD : (window.AZURE_AD || []));
  const results = dir
    .filter(p => !exclude.includes(p.email))
    .filter(p => (p.name + ' ' + p.email).toLowerCase().includes(q.toLowerCase().trim())).slice(0, 6);
  useEffect(() => {
    const h = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  if (value && value.name) {
    return (
      <div className="ad-card">
        <span className="ad-av">{value.name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase()}</span>
        <div className="ad-meta">
          <div className="ad-nm">{value.name} <span className="ad-src"><Icon name="shield" size={11} /> Azure AD</span></div>
          <div className="ad-sub"><Icon name="mail" size={12} />{value.email || '\u2014'}</div>
          <div className="ad-sub"><Icon name="briefcase" size={12} />{value.jobTitle || '\u2014'}</div>
        </div>
        {!disabled && <button type="button" className="ad-change" onClick={() => { onClear && onClear(); setQ(''); setOpen(true); }}>Change</button>}
      </div>
    );
  }
  return (
    <div className="ac-wrap" ref={wrapRef} style={{ position:'relative' }}>
      <div className="inputgroup">
        <span className="adorn"><Icon name="search" size={16} /></span>
        <input className={`input ${error ? 'err' : ''}`} value={q} placeholder={placeholder} autoComplete="off"
          onChange={e => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} />
      </div>
      {open && (
        <div className="ac-menu">
          {results.length === 0
            ? <div className="ac-empty">{q.trim() ? 'No one in the directory matches.' : 'Search the company directory by name or email\u2026'}</div>
            : results.map(p => (
              <button key={p.email} type="button" className="ac-item ad-item"
                onMouseDown={(e) => { e.preventDefault(); onSelect(p); setOpen(false); setQ(''); }}>
                <span className="ad-av sm">{p.name.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase()}</span>
                <span className="ad-item-tt"><b>{p.name}</b><span>{p.email} \u00b7 {p.jobTitle}</span></span>
              </button>
            ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- Checkbox ---------------- */
function Check({ on, indeterminate, onClick }) {
  return (
    <button type="button" role="checkbox" aria-checked={indeterminate ? 'mixed' : !!on}
      className={`cbox ${on || indeterminate ? 'checked' : ''}`} onClick={onClick}>
      {on && (
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor"
          strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"></path></svg>
      )}
      {!on && indeterminate && <span style={{ width: 10, height: 2.5, background: 'currentColor', borderRadius: 2 }}></span>}
    </button>
  );
}

/* ---------------- Modal ---------------- */
function Modal({ title, onClose, children, footer, size }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={`modal ${size || ''}`}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="iconbtn" style={{ border: 'none' }} onClick={onClose}><Icon name="close" /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------------- Toast ---------------- */
function Toast({ msg, icon = 'check' }) {
  if (!msg) return null;
  return <div className="toast"><Icon name={icon} size={18} style={{ color: 'var(--green-300)' }} />{msg}</div>;
}

Object.assign(window, { Icon, Btn, StatusChip, STATUS, Field, TextInput, Select, Check, Modal, Toast,
  Autocomplete, AzurePicker,
  useState, useEffect, useRef, useMemo });

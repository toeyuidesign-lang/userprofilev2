/**
 * TypeScript interfaces for all data models
 * User Management — Project Access Approval System
 *
 * NOTE: this supersedes all earlier handoffs. Legacy statuses
 *       Pending / Approved / Revise / Rejected / Inactive, the 'Listener'
 *       access type, ownerTel/leadTel, endpoint and requestedVia are REMOVED.
 */

// ─────────────────────────────────────────
// AZURE AD DIRECTORY
//   Product Owner, Tech Lead and console User Management identities are
//   all resolved from the company Azure AD directory — never typed manually.
// ─────────────────────────────────────────

export interface AzureADPerson {
  name: string;
  email: string;
  jobTitle: string;
  dept?: string;
}

// ─────────────────────────────────────────
// STATUS MODEL
//   Draft → In Progress (steps 2..N-1) → Active
//   Branches: Cancelled (any pending step), Terminated (from Active)
//   Archived: a prior version superseded by a newer Active version
// ─────────────────────────────────────────

export type ApplicationStatus =
  | 'Draft'
  | 'In Progress'
  | 'Active'
  | 'Archived'
  | 'Terminated'
  | 'Cancelled';

export type AccessType = 'API' | 'File Base';   // 'Listener' removed

export interface Application {
  no: number;
  uid: string;              // stable identity across versions, e.g. 'CLT-00010482-v2'
  name: string;
  id: string;                // Client ID, e.g. 'CLT-00010482'

  // who created it — determines which workflow chain (6 or 7 steps) applies
  createdByRole: 'HR' | 'IT' | 'PO';

  // Product Owner — resolved from Azure AD
  owner: string;
  ownerEmail: string;
  ownerTitle: string;        // Azure AD job title (replaces the old ownerTel)
  sameAsRequester?: boolean; // true if PO was filled via the "Same as requester" checkbox

  // Tech Lead — resolved from Azure AD, OPTIONAL
  lead?: string;
  leadEmail?: string;
  leadTitle?: string;        // Azure AD job title (replaces the old leadTel)

  access: AccessType[];       // at least one required; no default
  status: ApplicationStatus;
  step?: number;              // 1..N, current stage — N depends on createdByRole's chain length

  requester: string;          // free text, pre-filled with the creator's own name, editable
  submitted: string;          // 'dd/mm/yyyy'
  updated: string;
  columns: number;
  rules: number;
  sources: number;            // count of selected CIF master-data tables
  version?: number;

  // credentials captured during the flow
  key?: string;                // integration Key (entered by IT)
  clientCode?: string;         // Client Code (entered by IT, locked downstream)
  poResult?: 'pass' | 'fail';

  // closure metadata
  termReason?: string;
  termBy?: string;
  cancelReason?: string;
  duplicatedFrom?: string;
  fileBase?: FileBaseConfig | null;

  // internal — used to render the "before" side of the contacts-changed email preview
  _prevOwner?: string;
  _prevLead?: string;
}

// ─────────────────────────────────────────
// ROLES & WORKFLOW
//
// Two distinct role concepts:
//  - WorkflowRole: who acts on a given step of a given request (HR/IT/PO/SO/System)
//  - ConsoleRole:  the signed-in user's permission role in the app (PO/HR/IT/SO/Super Admin/Viewer)
// A Super Admin or Viewer is never a workflow actor.
// ─────────────────────────────────────────

export type WorkflowRole = 'HR' | 'IT' | 'PO' | 'SO' | 'System';
export type ViewAsRole = 'HR' | 'IT' | 'PO' | 'SO';     // workflow-actor viewing roles
export type ConsoleRole = 'PO' | 'HR' | 'IT' | 'SO' | 'Super Admin' | 'Viewer';

export interface WorkflowStep {
  n: number;
  key: string;                // 'request' | 'hr_review' | 'it_submit' | 'po_test' | 'it_confirm' | 'so_submit' | 'finished'
  role: WorkflowRole;
  actor: 'hr' | 'it' | 'po' | 'so' | 'sys';
  label: string;
  short: string;
  type: 'form' | 'modal' | 'offline' | 'page' | 'system';
  email?: 'it' | 'po' | 'hr' | 'so';
  desc: string;
}

/** Standard chain (7 steps) — used when createdByRole is 'PO' or 'IT'. */
export type WorkflowStd = WorkflowStep[];   // length 7, includes 'hr_review'
/** HR chain (6 steps) — used when createdByRole is 'HR'; skips 'hr_review'. */
export type WorkflowHr = WorkflowStep[];    // length 6

/** Resolve the applicable chain for a request. */
export declare function workflowFor(app: Pick<Application, 'createdByRole'>): WorkflowStep[];

export type WorkflowAction =
  | 'edit'
  | 'submit_draft'
  | 'delete_draft'
  | 'hr_approve'            // 7-step chain only
  | 'submit_po'             // IT → opens credential modal (it2)
  | 'it_confirm_inline'     // IT → confirm directly on the detail page
  | 'cancel_request'        // available to whoever's turn it is, at any step; requires reason
  | 'po_tested'
  | 'po_failed'             // requires reason
  | 'so_submit'             // SO → opens credential modal (so)
  | 'terminate';            // Active → Terminated; requires reason

export interface FileBaseConfig {
  host: string;
  port: string;
  username: string;
  directory: string;
}

// ─────────────────────────────────────────
// EMAIL TEMPLATES
// ─────────────────────────────────────────

export type EmailKind = 'it' | 'po' | 'hr' | 'so' | 'active' | 'contacts';

export interface EmailContactChange {
  label: 'Product Owner' | 'Tech Lead';
  from: string;
  to: string;
}

export interface EmailTemplate {
  kind: EmailKind;
  to: string;
  from: string;
  subject: string;
  preheader: string;
  role: WorkflowRole | 'ALL';
  cta: string;
  step: number;
  intro: string;
  offline?: boolean;
  showKey?: boolean;
  broadcast?: boolean;
  contacts?: boolean;                    // true for the PO/Tech Lead changed template
  changes?: EmailContactChange[];        // populated when contacts === true
}

// ─────────────────────────────────────────
// VERSIONING
// ─────────────────────────────────────────

export interface VersionDetail {
  access: AccessType[];
  key?: string;
  clientCode?: string;
  columns: number;
  rules: number;
  sources: number;
  cols?: string[];
  rule?: string;
  pii?: number;
  masterData?: string[];    // CIF table names selected for this version
}

export interface AppVersion {
  version: number;
  status: ApplicationStatus;
  created: string;
  by: string;
  changelog: string;
  usedBy: string[];
  prevVersion: number | null;
  isLatest?: boolean;
  detail?: VersionDetail;
}

// ─────────────────────────────────────────
// CREATE FORM
// ─────────────────────────────────────────

export interface ApplicationFormValues {
  name: string;
  id: string;
  owner: string;
  ownerEmail: string;
  ownerTitle: string;
  lead: string;               // optional
  leadEmail: string;
  leadTitle: string;
  access: AccessType[];       // no default; at least one required
  requester: string;          // pre-filled with current user, editable
  sameAsRequester: boolean;
}

export type FormErrors = Partial<Record<keyof ApplicationFormValues, string>>;

// ─────────────────────────────────────────
// RULE BUILDER (Tab 2) — unchanged
// ─────────────────────────────────────────

export type LogicMatch = 'AND' | 'OR';
export type Operator = '=' | '≠' | '>' | '<' | '≥' | '≤' | 'contains' | 'in';

export interface RuleCondition {
  id: number;
  type: 'cond';
  not: boolean;
  field: string;
  op: Operator;
  value: string;
}

export interface RuleGroup {
  id: number;
  type: 'group';
  match: LogicMatch;
  children: (RuleCondition | RuleGroup)[];
}

export type RuleNode = RuleCondition | RuleGroup;

// ─────────────────────────────────────────
// COLUMN SELECTION (Tab 3) — unchanged
// ─────────────────────────────────────────

export type ColumnDataType = 'Number' | 'Text' | 'Calculation' | 'Date';

export interface DataColumn {
  name: string;
  type: ColumnDataType;
  remark: string;
  sensitive: boolean;
}

// ─────────────────────────────────────────
// MASTER DATA (Tab 4 + sidebar menus)
//   Tab 4 no longer selects a Source System — it picks from CIF_TABLES directly.
//   NOTE: when access is API-only, the Master Data tab is DISABLED.
// ─────────────────────────────────────────

export const CIF_TABLES = [
  'Joblevel', 'JobLevelDoa', 'Company', 'Business Unit', 'Function',
  'Subfunction1', 'Subfunction2', 'Subfunction3', 'Subfunction4', 'Subfunction5',
  'Subfunction6', 'Subfunction7', 'Employee Status', 'Contract Type', 'PositionMaster',
  'Business Stream', 'Work Location', 'Country',
] as const;
export type CifTable = typeof CIF_TABLES[number];

export type MasterDataStatus = 'Active' | 'Inactive';

export interface MasterDataRow {
  id: string;
  status: MasterDataStatus;
  created: string;
  createdBy: string;
  desc: string;
  [key: string]: string;
}

export interface MasterDataFieldConfig {
  key: string;
  label: string;
  type: 'text' | 'select';
  required?: boolean;
  placeholder?: string;
  hint?: string;
  options?: string[];
  validate?: 'email';
}

export interface MasterDataColumnConfig {
  key: string;
  label: string;
  strong?: boolean;
}

export interface MasterDataMenuConfig {
  title: string;
  singular: string;
  icon: string;
  idPrefix: string;
  desc: string;
  /** true only for the User Management ('um') menu — swaps the manual form for the Azure AD picker form. */
  azureUser?: boolean;
  /** Role choices for the 'um' menu: PO, HR, IT, SO, Super Admin, Viewer. */
  roleOptions?: ConsoleRole[];
  columns: MasterDataColumnConfig[];
  fields: MasterDataFieldConfig[];
  rows: MasterDataRow[];
}

export type MasterDataMenuKey =
  | 'um' | 'country' | 'company' | 'joblevel'
  | 'mapping' | 'function' | 'jobstatus';

/** Sidebar visibility: the entire Master Data nav group is gated to these console roles. */
export const MASTER_DATA_VISIBLE_TO: ConsoleRole[] = ['IT', 'Super Admin', 'HR'];

// ─────────────────────────────────────────
// AUDIT / HISTORY LOG
// ─────────────────────────────────────────

export type HistoryAction =
  | 'Create' | 'Update' | 'Submit' | 'Notify' | 'View'
  | 'Approve' | 'Activate' | 'Reject' | 'Deactivate' | 'Version';

export interface HistoryEntry {
  date: string;
  actor: string;
  role: string;
  action: HistoryAction;
  detail: string;
  version: number;
}

// ─────────────────────────────────────────
// MODALS / DIALOGS
// ─────────────────────────────────────────

export type CredentialStage = 'it2' | 'it4' | 'so';
export type ReasonKind = 'cancel_request' | 'delete_draft' | 'terminate' | 'po_failed';

export interface ConfirmDialogConfig {
  type: WorkflowAction;
  title: string;
  message: string;
  confirmLabel: string;
  icon: string;
  variant: 'accent' | 'success' | 'danger' | 'primary';
}

/** Payload saved by the "Edit PO & Tech Lead" modal (Active requests only). */
export interface EditContactsPayload {
  owner: string;
  ownerEmail: string;
  ownerTitle: string;
  lead: string;
  leadEmail: string;
  leadTitle: string;
}

// ─────────────────────────────────────────
// APP NAVIGATION
// ─────────────────────────────────────────

export type AppView =
  | 'dashboard'
  | 'listing'
  | 'tasks'
  | 'emails'              // dev/QA tooling only — do not ship as an in-app screen
  | 'create'
  | 'review'
  | 'version'
  | 'compare'
  | MasterDataMenuKey;

export type ListingLayout = 'table' | 'board' | 'cards';
export type ReviewLayout = 'split' | 'focus';

export type RootDrawerParamList = {
  Dashboard: undefined;
  Registration: undefined;
  MyTasks: undefined;
  UserManagement: undefined;
  Country: undefined;
  Company: undefined;
  JobLevel: undefined;
  JobLevelMapping: undefined;
  Function: undefined;
  JobStatus: undefined;
};

export type RegistrationStackParamList = {
  Listing: undefined;
  CreateRequest: { app?: Application } | undefined;
  Review: { app: Application; role: ViewAsRole };
  VersionDetail: { app: Application; version: number };
  VersionCompare: { app: Application; target?: number };
};

export type MasterDataStackParamList = {
  MDListing: { menu: MasterDataMenuKey };
  MDForm: { menu: MasterDataMenuKey; row?: MasterDataRow };
};

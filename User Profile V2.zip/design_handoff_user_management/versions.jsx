/* ============================================================
   Version detail (single version) + Version compare (diff).
   Reached from the Version History modal. Each reads the chosen
   version's own snapshot via versionAsApp(), so it shows that
   version's real detail and status — not the live record.
   ============================================================ */

/* ---- a labelled field row ---- */
function VRow({ label, children, changed }) {
  return (
    <div className="vrow" style={changed ? { background:'var(--warning-bg)' } : {}}>
      <span className="vrow-l">{label}{changed && <span className="vrow-tag">changed</span>}</span>
      <span className="vrow-r">{children}</span>
    </div>
  );
}

function versionSnapshot(app, v) {
  return versionAsApp(app, v);
}

/* ---------------- Single version detail page ---------------- */
function VersionDetail({ app, version, onExit, openVersions }) {
  const snap = versionSnapshot(app, version);
  const all = [...versionsOf(app)].reverse();
  const apiOnly = (snap.access || []).length === 1 && snap.access[0] === 'API';
  const cols = snap.cols || [];

  return (
    <div className="content-narrow fade-in">
      <div className="crumbs">
        <button className="backlink" onClick={onExit}><Icon name="chevL" size={18} /> Back</button>
        <span className="crumb-path">{app.name}&nbsp;/&nbsp;Versions&nbsp;/&nbsp;<span className="cur">Version {version.version}</span></span>
      </div>

      <div className="page-head" style={{ marginBottom:18 }}>
        <div>
          <div style={{ display:'flex', alignItems:'center', gap:12, flexWrap:'wrap' }}>
            <div className="page-title">{app.name}</div>
            <span className="vbadge">v{version.version}</span>
            <StatusChip status={version.status} />
            {version.isLatest && <span className="chip chip-info" style={{ padding:'2px 10px' }}>Latest</span>}
          </div>
          <div className="page-sub"><span className="cell-id">{app.id}</span> · Created {version.created} · {version.by}</div>
        </div>
        <Btn variant="ghost" icon="layers" onClick={() => openVersions(app)}>All versions</Btn>
      </div>

      {/* version switcher */}
      <div className="vswitch">
        {all.map(v => (
          <button key={v.version} className={`vswitch-pill ${v.version === version.version ? 'on' : ''}`} onClick={() => onExit('view', v)}>
            <span className="vswitch-v">v{v.version}</span>
            <StatusChip status={v.status} />
          </button>
        ))}
      </div>

      <div className="card card-pad" style={{ marginBottom:18 }}>
        <div className="section-title"><Icon name="edit" size={20} style={{ color:'var(--brand)' }} /> What changed in this version</div>
        <p style={{ fontSize:14, color:'var(--fg-secondary)', lineHeight:1.6, margin:'6px 0 0' }}>{version.changelog}</p>
        {version.prevVersion &&
          <div style={{ marginTop:12 }}><Btn variant="outline" size="sm" icon="layers" onClick={() => onExit('compare', version)}>Compare with v{version.prevVersion}</Btn></div>}
      </div>

      <div className="review-grid">
        <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
          <div className="card card-pad">
            <div className="section-title"><Icon name="user" size={20} style={{ color:'var(--brand)' }} /> Configuration · v{version.version}</div>
            <div style={{ marginTop:10 }}>
              <VRow label="Status"><StatusChip status={version.status} /></VRow>
              <VRow label="Access models"><AccessTags access={snap.access || []} /></VRow>
              <VRow label="Credentials">
                <span className="chip chip-info" style={{ padding:'2px 9px', fontSize:11, fontFamily:'monospace' }}>Key · {snap.key || '—'}</span>
                <span className="chip chip-info" style={{ padding:'2px 9px', fontSize:11, fontFamily:'monospace', marginLeft:6 }}>Code · {snap.clientCode || '—'}</span>
              </VRow>
              <VRow label="Columns"><b>{snap.columns}</b> fields{snap.pii ? <span className="chip chip-rejected" style={{ padding:'1px 8px', fontSize:10.5, marginLeft:8 }}><Icon name="shield" size={10} /> {snap.pii} PII</span> : null}</VRow>
              <VRow label="Row rules"><b>{snap.rules}</b> validation rule{snap.rules !== 1 ? 's' : ''}</VRow>
              <VRow label="Master data">{apiOnly ? <span className="muted" style={{ fontSize:13 }}>Not used (API only)</span> : <b>{snap.sources}</b>}{!apiOnly && ' source systems'}</VRow>
            </div>
          </div>
        </div>

        <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
          <div className="card card-pad">
            <div className="section-title"><Icon name="filter" size={20} style={{ color:'var(--brand)' }} /> Row selection</div>
            <div className="preview-box" style={{ fontSize:12.5, padding:'11px 13px', marginTop:6 }}>{snap.rule || '—'}</div>
          </div>
          <div className="card card-pad">
            <div className="section-title"><Icon name="grid" size={20} style={{ color:'var(--brand)' }} /> Columns shared</div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:8 }}>
              {cols.length ? cols.map(c => <span key={c} className="chip chip-active" style={{ padding:'2px 9px', fontSize:11.5 }}>{c}</span>)
                : <span className="muted" style={{ fontSize:13 }}>No column list recorded for this version.</span>}
            </div>
          </div>
          {!apiOnly && (
            <div className="card card-pad">
              <div className="section-title"><Icon name="settings" size={20} style={{ color:'var(--brand)' }} /> Master data sources</div>
              <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:8 }}>
                {(snap.masterData || []).map(c => <span key={c} className="chip chip-info" style={{ padding:'2px 9px', fontSize:11.5 }}>{c}</span>)}
              </div>
            </div>
          )}
          {version.usedBy && version.usedBy.length > 0 && (
            <div className="card card-pad">
              <div className="section-title"><Icon name="server" size={20} style={{ color:'var(--brand)' }} /> In use by</div>
              <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:8 }}>
                {version.usedBy.map(u => <span key={u} className="chip chip-active" style={{ padding:'2px 9px', fontSize:11.5 }}><Icon name="server" size={11} />{u}</span>)}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Side-by-side compare ---------------- */
function VersionCompare({ app, target, onExit, openVersions }) {
  const all = [...versionsOf(app)];  // oldest first
  // default: compare the two newest; or target vs its prevVersion
  let bV, aV;
  if (target) {
    aV = target;
    bV = all.find(x => x.version === target.prevVersion) || all[all.indexOf(target) - 1];
  } else {
    aV = all[all.length - 1];
    bV = all[all.length - 2];
  }
  if (!bV) bV = aV;
  const [leftV, setLeftV] = useState(bV.version);
  const [rightV, setRightV] = useState(aV.version);
  const L = versionSnapshot(app, all.find(x => x.version === leftV));
  const R = versionSnapshot(app, all.find(x => x.version === rightV));

  const rows = [
    { k:'Status', l:L.status, r:R.status, render:(x) => <StatusChip status={x} /> },
    { k:'Access models', l:(L.access||[]).join(', '), r:(R.access||[]).join(', ') },
    { k:'Key', l:L.key, r:R.key, mono:true },
    { k:'Client Code', l:L.clientCode, r:R.clientCode, mono:true },
    { k:'Columns', l:String(L.columns), r:String(R.columns) },
    { k:'PII fields', l:String(L.pii||0), r:String(R.pii||0) },
    { k:'Row rules', l:String(L.rules), r:String(R.rules) },
    { k:'Filter expression', l:L.rule, r:R.rule },
    { k:'Master data', l:(L.masterData||[]).join(', ')||'—', r:(R.masterData||[]).join(', ')||'—' },
  ];
  // column-list diff
  const lc = L.cols || [], rc = R.cols || [];
  const added = rc.filter(c => !lc.includes(c));
  const removed = lc.filter(c => !rc.includes(c));
  const changedCount = rows.filter(x => String(x.l) !== String(x.r)).length + (added.length || removed.length ? 1 : 0);

  const VSelect = ({ value, onChange }) => (
    <select className="input" value={value} onChange={e => onChange(Number(e.target.value))} style={{ width:'auto', fontWeight:600, fontFamily:'var(--font-display)' }}>
      {all.map(v => <option key={v.version} value={v.version}>v{v.version} · {v.status}</option>)}
    </select>
  );

  return (
    <div className="content-narrow fade-in">
      <div className="crumbs">
        <button className="backlink" onClick={onExit}><Icon name="chevL" size={18} /> Back</button>
        <span className="crumb-path">{app.name}&nbsp;/&nbsp;Versions&nbsp;/&nbsp;<span className="cur">Compare</span></span>
      </div>

      <div className="page-head" style={{ marginBottom:18 }}>
        <div>
          <div className="page-title">Compare versions</div>
          <div className="page-sub"><span className="cell-id">{app.id}</span> · {changedCount} field{changedCount !== 1 ? 's' : ''} differ between the selected versions</div>
        </div>
        <Btn variant="ghost" icon="layers" onClick={() => openVersions(app)}>All versions</Btn>
      </div>

      <div className="card" style={{ overflow:'hidden' }}>
        <div className="cmp-head">
          <div className="cmp-cell-h cmp-field">Field</div>
          <div className="cmp-cell-h"><span className="cmp-side">Version</span><VSelect value={leftV} onChange={setLeftV} /></div>
          <div className="cmp-cell-h"><span className="cmp-side">Version</span><VSelect value={rightV} onChange={setRightV} /></div>
        </div>
        {rows.map(row => {
          const diff = String(row.l) !== String(row.r);
          const rend = row.render || ((x) => <span style={row.mono ? { fontFamily:'monospace', fontSize:12.5 } : { fontSize:13 }}>{x || '—'}</span>);
          return (
            <div className={`cmp-row ${diff ? 'diff' : ''}`} key={row.k}>
              <div className="cmp-cell cmp-field">{row.k}{diff && <span className="vrow-tag">≠</span>}</div>
              <div className="cmp-cell">{rend(row.l)}</div>
              <div className="cmp-cell">{rend(row.r)}</div>
            </div>
          );
        })}
        {/* column diff row */}
        <div className={`cmp-row ${(added.length || removed.length) ? 'diff' : ''}`}>
          <div className="cmp-cell cmp-field">Column list{(added.length || removed.length) ? <span className="vrow-tag">≠</span> : null}</div>
          <div className="cmp-cell" style={{ alignItems:'flex-start' }}>
            <div style={{ display:'flex', flexWrap:'wrap', gap:5 }}>
              {lc.map(c => <span key={c} className={`chip ${removed.includes(c) ? 'chip-rejected' : 'chip-active'}`} style={{ padding:'1px 8px', fontSize:11 }}>{removed.includes(c) ? '−' : ''} {c}</span>)}
            </div>
          </div>
          <div className="cmp-cell" style={{ alignItems:'flex-start' }}>
            <div style={{ display:'flex', flexWrap:'wrap', gap:5 }}>
              {rc.map(c => <span key={c} className={`chip ${added.includes(c) ? 'chip-progress' : 'chip-active'}`} style={{ padding:'1px 8px', fontSize:11 }}>{added.includes(c) ? '+' : ''} {c}</span>)}
            </div>
          </div>
        </div>
      </div>

      <div style={{ display:'flex', gap:18, marginTop:14, fontSize:12.5, color:'var(--fg-secondary)' }}>
        <span style={{ display:'flex', alignItems:'center', gap:7 }}><i style={{ width:14, height:14, borderRadius:4, background:'var(--warning-bg)', border:'1px solid var(--warning)' }}></i> Field differs</span>
        <span style={{ display:'flex', alignItems:'center', gap:7 }}><span className="chip chip-progress" style={{ padding:'1px 8px', fontSize:11 }}>+ added</span></span>
        <span style={{ display:'flex', alignItems:'center', gap:7 }}><span className="chip chip-rejected" style={{ padding:'1px 8px', fontSize:11 }}>− removed</span></span>
      </div>
    </div>
  );
}

Object.assign(window, { VersionDetail, VersionCompare });

/* ============================================================
   Mock data for the prototype
   ============================================================ */
const APPS = [
  { no:1, uid:'CLT-00010482-v2', name:'Employee Engagement', id:'CLT-00010482', owner:'Naree Suksai', ownerEmail:'naree.s@banpu.com', ownerTel:'+66 81 234 5601',
    lead:'Anan Wong', leadEmail:'anan.w@banpu.com', leadTel:'+66 81 234 5602', access:['API','File Base'],
    status:'Active', key:'eng_5c2a-ENGAGE', clientCode:'CLT-00010482', endpoint:'https://eng.banpu.io/api', requester:'People Experience Team', requestedVia:'Email',
    submitted:'02/06/2026', updated:'04/06/2026', columns:9, rules:2, sources:3, version:2 },
  { no:2, uid:'CLT-00010477-v2', name:'Talent Mobility Portal', id:'CLT-00010477', owner:'Praphan Tula', ownerEmail:'praphan.t@banpu.com', ownerTel:'+66 81 234 5611',
    lead:'Kanya Rit', leadEmail:'kanya.r@banpu.com', leadTel:'+66 81 234 5612', access:['API'],
    status:'In Progress', step:2, endpoint:'https://talent.banpu.io/hook', requester:'Group HRIS', requestedVia:'Email',
    submitted:'05/06/2026', updated:'05/06/2026', columns:9, rules:2, sources:3, version:2 },
  { no:3, name:'Payroll Sync — Indonesia', id:'CLT-00010465', owner:'Dewi Anggraini', ownerEmail:'dewi.a@banpu.com', ownerTel:'+62 811 234 561',
    lead:'Budi Hartono', leadEmail:'budi.h@banpu.com', leadTel:'+62 811 234 562', access:['API','File Base'],
    status:'In Progress', step:4, key:'tlm_9f3a-PAYID', clientCode:'CLT-00010465', endpoint:'https://payroll-id.banpu.io', requester:'Finance Shared Services', requestedVia:'Verbal',
    submitted:'05/06/2026', updated:'06/06/2026', columns:21, rules:4, sources:2 },
  { no:4, name:'Learning Hub LMS', id:'CLT-00010450', owner:'Somchai Pat', ownerEmail:'somchai.p@banpu.com', ownerTel:'+66 81 234 5631',
    lead:'Wirat Chan', leadEmail:'wirat.c@banpu.com', leadTel:'+66 81 234 5632', access:['API'],
    status:'Active', key:'lms_8d4b-LEARN', clientCode:'CLT-00010450', endpoint:'https://lms.banpu.io/api', requester:'Learning & Culture', requestedVia:'Email',
    submitted:'01/06/2026', updated:'03/06/2026', columns:11, rules:1, sources:4 },
  { no:5, name:'Access Card Provisioning', id:'CLT-00010441', owner:'Manop Iam', ownerEmail:'manop.i@banpu.com', ownerTel:'+66 81 234 5641',
    lead:'Surasak Boon', leadEmail:'surasak.b@banpu.com', leadTel:'+66 81 234 5642', access:['File Base'],
    status:'In Progress', step:5, key:'acp_2b7c-CARD', clientCode:'CLT-00010441', poResult:'pass', endpoint:'https://access.banpu.io', requester:'Workplace Services', requestedVia:'Email',
    submitted:'30/05/2026', updated:'04/06/2026', columns:6, rules:2, sources:1 },
  { no:6, name:'BKV US — Headcount Feed', id:'CLT-00010432', owner:'Sarah Miller', ownerEmail:'sarah.m@bkv.com', ownerTel:'+1 720 555 0101',
    lead:'James Carter', leadEmail:'james.c@bkv.com', leadTel:'+1 720 555 0102', access:['API'],
    status:'Draft', endpoint:'', requester:'BKV People Ops', requestedVia:'Email',
    submitted:'06/06/2026', updated:'06/06/2026', columns:8, rules:0, sources:0 },
  { no:7, name:'Safety Induction Tracker', id:'CLT-00010418', owner:'Pichai Som', ownerEmail:'pichai.s@banpu.com', ownerTel:'+66 81 234 5661',
    lead:'Ratana Pim', leadEmail:'ratana.p@banpu.com', leadTel:'+66 81 234 5662', access:['API'],
    status:'In Progress', step:6, key:'sit_7d1e-SAFE', clientCode:'CLT-00010418', poResult:'pass', endpoint:'https://safety.banpu.io', requester:'HSE Australia', requestedVia:'Verbal',
    submitted:'28/05/2026', updated:'31/05/2026', columns:5, rules:1, sources:2 },
  { no:8, name:'Org Chart Visualizer', id:'CLT-00010405', owner:'Nattaya Kul', ownerEmail:'nattaya.k@banpu.com', ownerTel:'+66 81 234 5671',
    lead:'Decha Wong', leadEmail:'decha.w@banpu.com', leadTel:'+66 81 234 5672', access:['API'],
    status:'Active', key:'org_3f9c-ORGVIZ', clientCode:'CLT-00010405', endpoint:'https://orgchart.banpu.io', requester:'Strategy & Transformation', requestedVia:'Email',
    submitted:'20/05/2026', updated:'22/05/2026', columns:7, rules:1, sources:3 },
  { no:9, name:'Contractor Onboarding', id:'CLT-00010390', owner:'Veerasak Lim', ownerEmail:'veerasak.l@banpu.com', ownerTel:'+66 81 234 5681',
    lead:'Pornchai Sak', leadEmail:'pornchai.s@banpu.com', leadTel:'+66 81 234 5682', access:['File Base'],
    status:'In Progress', step:6, key:'con_4a8f-ONBRD', clientCode:'CLT-00010390', poResult:'pass', endpoint:'https://contractor.banpu.io', requester:'Procurement', requestedVia:'Email',
    submitted:'12/05/2026', updated:'18/05/2026', columns:10, rules:2, sources:2 },
  { no:10, name:'Mongolia Site HR Bridge', id:'CLT-00010377', owner:'Bat-Erdene G.', ownerEmail:'bat.g@banpu.com', ownerTel:'+976 9911 2233',
    lead:'Temuujin B.', leadEmail:'temuujin.b@banpu.com', leadTel:'+976 9911 2244', access:['API','File Base'],
    status:'Terminated', termReason:'Site decommissioned — Mongolia payroll migrated to group SAP. Access no longer required.', termBy:'Krit Wattana (IT)', endpoint:'https://mn-hr.banpu.io', requester:'Mongolia Operations', requestedVia:'Verbal',
    submitted:'08/05/2026', updated:'10/05/2026', columns:13, rules:3, sources:4 },
  { no:11, name:'Vendor Portal SSO', id:'CLT-00010364', owner:'Apinya Sri', ownerEmail:'apinya.s@banpu.com', ownerTel:'+66 81 234 5691',
    lead:'Chai Ngam', leadEmail:'chai.n@banpu.com', leadTel:'+66 81 234 5692', access:['API'],
    status:'Cancelled', cancelReason:'Duplicate of CLT-00010405 (Org Chart Visualizer) — requester redirected to the existing integration.', endpoint:'https://vendor.banpu.io', requester:'Procurement', requestedVia:'Email',
    submitted:'14/05/2026', updated:'16/05/2026', columns:6, rules:1, sources:1 },
  { no:12, uid:'CLT-00010351', name:'Wellness App — TH', id:'CLT-00010351', owner:'Malee Thong', ownerEmail:'malee.t@banpu.com', ownerTel:'+66 81 234 5701',
    lead:'Wichai Som', leadEmail:'wichai.s@banpu.com', leadTel:'+66 81 234 5702', access:['File Base'],
    status:'Cancelled', cancelReason:'Vendor contract not renewed — request withdrawn by HR before provisioning.', endpoint:'https://wellness-th.banpu.io', requester:'People Experience Team', requestedVia:'Verbal',
    submitted:'02/05/2026', updated:'09/05/2026', columns:9, rules:2, sources:2 },
  // ---- live (currently-Active) versions sitting alongside an in-progress new version ----
  { no:13, uid:'CLT-00010482-v3', name:'Employee Engagement', id:'CLT-00010482', owner:'Naree Suksai', ownerEmail:'naree.s@banpu.com', ownerTel:'+66 81 234 5601',
    lead:'Anan Wong', leadEmail:'anan.w@banpu.com', leadTel:'+66 81 234 5602', access:['API','File Base'],
    status:'In Progress', step:5, key:'eng_9f1d-PULSE', clientCode:'CLT-00010482', poResult:'pass', endpoint:'https://eng.banpu.io/api', requester:'People Experience Team', requestedVia:'Email',
    submitted:'20/06/2026', updated:'22/06/2026', columns:11, rules:3, sources:3, version:3 },
  { no:14, uid:'CLT-00010477-v1', name:'Talent Mobility Portal', id:'CLT-00010477', owner:'Praphan Tula', ownerEmail:'praphan.t@banpu.com', ownerTel:'+66 81 234 5611',
    lead:'Kanya Rit', leadEmail:'kanya.r@banpu.com', leadTel:'+66 81 234 5612', access:['API'],
    status:'Active', key:'tlm_4b2a-LIVE', clientCode:'CLT-00010477', endpoint:'https://talent.banpu.io/v1', requester:'Group HRIS', requestedVia:'Email',
    submitted:'20/04/2026', updated:'20/04/2026', columns:7, rules:1, sources:2, version:1 },
  // ---- HR-created request (uses the shorter HR workflow — no separate HR review) ----
  { no:15, uid:'CLT-00010495', name:'Benefits Enrollment Portal', id:'CLT-00010495', createdByRole:'HR',
    owner:'Somchai Pat', ownerEmail:'somchai.p@banpu.com', ownerTitle:'Learning Platform Owner',
    lead:'Wirat Chan', leadEmail:'wirat.c@banpu.com', leadTitle:'Applications Engineer', access:['API','File Base'],
    status:'In Progress', step:2, requester:'Moni Roy',
    submitted:'25/06/2026', updated:'26/06/2026', columns:8, rules:2, sources:2 },
  // ---- sample: cancelled by IT at step 3 (Submit to PO), with a reason ----
  { no:16, uid:'CLT-00010512', name:'Succession Planning Board', id:'CLT-00010512', owner:'Nattaya Kul', ownerEmail:'nattaya.k@banpu.com', ownerTel:'+66 81 234 5711',
    lead:'Decha Wong', leadEmail:'decha.w@banpu.com', leadTel:'+66 81 234 5712', access:['API'],
    status:'Cancelled', step:3, cancelReason:'IT found the requested endpoint uses a deprecated auth scheme (OAuth 1.0). Cancelling until the vendor upgrades to OAuth 2.0 — please resubmit once ready.', cancelBy:'Krit Wattana (IT)',
    endpoint:'https://succession.banpu.io', requester:'Strategy & Transformation', requestedVia:'Email',
    submitted:'24/06/2026', updated:'26/06/2026', columns:8, rules:2, sources:2 },
  // ---- sample: terminated integration that had 3 prior versions ----
  { no:17, uid:'CLT-00010530', name:'Time & Attendance Bridge', id:'CLT-00010530', owner:'Manop Iam', ownerEmail:'manop.i@banpu.com', ownerTel:'+66 81 234 5721',
    lead:'Surasak Boon', leadEmail:'surasak.b@banpu.com', leadTel:'+66 81 234 5722', access:['API','File Base'],
    status:'Terminated', step:7, version:3, key:'tna_9e0f-FINAL', clientCode:'CLT-00010530',
    termReason:'Migrated to the group Time & Attendance platform; this integration was decommissioned.', termBy:'Krit Wattana (IT)',
    endpoint:'https://tna.banpu.io/api', requester:'Workplace Services', requestedVia:'Email',
    submitted:'10/01/2026', updated:'15/05/2026', columns:8, rules:2, sources:2 },
  // ---- sample: 3 versions, all resolved — v3 is the live Active version.
  //      "Create new version" here has no open draft/pending sibling, so it
  //      goes straight to the base-version picker (v1 / v2 / v3 to start from). ----
  { no:18, uid:'CLT-00010560', name:'Recruitment ATS Feed', id:'CLT-00010560', owner:'Veerasak Lim', ownerEmail:'veerasak.l@banpu.com', ownerTel:'+66 81 234 5731',
    lead:'Pornchai Sak', leadEmail:'pornchai.s@banpu.com', leadTel:'+66 81 234 5732', access:['API','File Base'],
    status:'Active', version:3, key:'ats_7b3e-LIVE3', clientCode:'CLT-00010560',
    endpoint:'https://ats.banpu.io/api', requester:'Procurement', requestedVia:'Email',
    submitted:'14/02/2026', updated:'19/06/2026', columns:10, rules:2, sources:2 },
  // ---- sample: v1 is live Active, and a v2 has already been saved as a DRAFT
  //      (not submitted yet). The listing shows a "v2 in draft" badge, and
  //      "Create new version" stays enabled — clicking it resumes that same
  //      draft instead of starting yet another branch. ----
  { no:19, uid:'CLT-00010545', name:'Travel Desk Integration', id:'CLT-00010545', owner:'Apinya Sri', ownerEmail:'apinya.s@banpu.com', ownerTel:'+66 81 234 5741',
    lead:'Chai Ngam', leadEmail:'chai.n@banpu.com', leadTel:'+66 81 234 5742', access:['API'],
    status:'Active', version:1, key:'trv_2d4f-LIVE', clientCode:'CLT-00010545',
    endpoint:'https://travel.banpu.io/api', requester:'Corporate Services', requestedVia:'Email',
    submitted:'05/03/2026', updated:'05/03/2026', columns:6, rules:1, sources:1 },
  { no:20, uid:'CLT-00010545-v2-draft', id:'CLT-00010545', name:'Travel Desk Integration', owner:'Apinya Sri', ownerEmail:'apinya.s@banpu.com',
    lead:'Chai Ngam', leadEmail:'chai.n@banpu.com', access:['API','File Base'],
    status:'Draft', version:2, requester:'Apinya Sri',
    submitted:'01/07/2026', updated:'02/07/2026', columns:9, rules:2, sources:2 },
];
APPS.forEach(a => { if (!a.uid) a.uid = a.id; });

const COLUMNS = [
  { name:'UserID', type:'Number', remark:'Unique person identifier', sensitive:false },
  { name:'Country', type:'Text', remark:'ISO country of employment', sensitive:false },
  { name:'PersonIDExternal', type:'Number', remark:'External HRIS reference', sensitive:false },
  { name:'JobTitle', type:'Text', remark:'Current position title', sensitive:false },
  { name:'PreferredEmail', type:'Text', remark:'Primary contact email', sensitive:true },
  { name:'AgeRange', type:'Calculation', remark:'Derived banded age', sensitive:true },
  { name:'BusinessUnit', type:'Text', remark:'Reporting business unit', sensitive:false },
  { name:'CostCenter', type:'Number', remark:'Finance cost center code', sensitive:false },
  { name:'EmploymentType', type:'Text', remark:'Permanent / contract / intern', sensitive:false },
  { name:'HireDate', type:'Date', remark:'Date of joining', sensitive:false },
  { name:'ManagerID', type:'Number', remark:'Direct manager person ID', sensitive:false },
  { name:'Location', type:'Text', remark:'Office / site location', sensitive:false },
  { name:'JobLevelDOA', type:'Number', remark:'Delegation of authority level', sensitive:true },
  { name:'Salary', type:'Number', remark:'Monthly gross — restricted', sensitive:true },
];

const FIELD_OPTIONS = ['Company Code','Business Unit','Country','Job Level DOA','Employment Type','Cost Center','Function','Location','Hire Date','Manager ID'];
const VALUE_OPTIONS = {
  'Company Code':['BPP','BANPU','BKV','BPIN','BPAU'],
  'Business Unit':['Energy Resources','Energy Generation','Energy Technology','Corporate'],
  'Country':['Thailand','Indonesia','Australia','USA','Mongolia','China','Japan','Lao PDR'],
  'Job Level DOA':['L1','L2','L3','L4','L5','Executive'],
  'Employment Type':['Permanent','Contract','Intern','Outsource'],
  'Function':['HR','Finance','Operations','IT','HSE','Procurement'],
};
const OPERATORS = ['=','≠','>','<','≥','≤','contains','in'];

const MASTER_GROUPS = [
  { group:'Job Level DOA', type:'Number', items:[
    { name:'Employee Image', remark:'Profile photo reference' },
    { name:'Country', remark:'Country master record' },
    { name:'Company', remark:'Legal entity master' },
    { name:'SubFunction 1', remark:'Sub-function taxonomy' },
    { name:'Business Unit', remark:'BU master record' },
    { name:'Function', remark:'Function master record' },
  ]},
  { group:'Value', type:'Number', items:[
    { name:'Grade Band', remark:'Compensation grade band' },
    { name:'Currency', remark:'Local payroll currency' },
  ]},
];
const SOURCE_SYSTEMS = ['SAP SuccessFactors','Workday EU','Local HRIS — TH','Local HRIS — ID','Active Directory','BKV Oracle HCM','Mongolia Payroll'];

/* ============================================================
   Company Azure AD directory (mock)
   Product Owner, Tech Lead and console users are resolved from
   here — searching by name/email auto-fills email + job title.
   ============================================================ */
const AZURE_AD = [
  { name:'Moni Roy',        email:'moni.r@banpu.com',     jobTitle:'HR Systems Administrator',      dept:'Human Resources' },
  { name:'Krit Wattana',    email:'krit.w@banpu.com',     jobTitle:'IT Integration Engineer',       dept:'Information Technology' },
  { name:'Suda Niran',      email:'suda.n@banpu.com',     jobTitle:'System Owner — Data Platform',  dept:'Information Technology' },
  { name:'Naree Suksai',    email:'naree.s@banpu.com',    jobTitle:'People Experience Manager',     dept:'Human Resources' },
  { name:'Anan Wong',       email:'anan.w@banpu.com',     jobTitle:'Senior Systems Analyst',        dept:'Information Technology' },
  { name:'Praphan Tula',    email:'praphan.t@banpu.com',  jobTitle:'HRIS Product Owner',            dept:'Human Resources' },
  { name:'Kanya Rit',       email:'kanya.r@banpu.com',    jobTitle:'HRIS Analyst',                  dept:'Human Resources' },
  { name:'Somchai Pat',     email:'somchai.p@banpu.com',  jobTitle:'Learning Platform Owner',       dept:'Learning & Culture' },
  { name:'Wirat Chan',      email:'wirat.c@banpu.com',    jobTitle:'Applications Engineer',          dept:'Information Technology' },
  { name:'Nattaya Kul',     email:'nattaya.k@banpu.com',  jobTitle:'Strategy Product Owner',        dept:'Strategy & Transformation' },
  { name:'Decha Wong',      email:'decha.w@banpu.com',    jobTitle:'Data Engineer',                 dept:'Information Technology' },
  { name:'Dewi Anggraini',  email:'dewi.a@banpu.com',     jobTitle:'HR Operations Lead — ITM',      dept:'Human Resources' },
  { name:'Budi Hartono',    email:'budi.h@banpu.com',     jobTitle:'IT Analyst — ITM',              dept:'Information Technology' },
  { name:'Sarah Miller',    email:'sarah.m@bkv.com',      jobTitle:'People Ops Lead — BKV',         dept:'Human Resources' },
  { name:'James Carter',    email:'james.c@bkv.com',      jobTitle:'Platform Engineer — BKV',       dept:'Information Technology' },
  { name:'Manop Iam',       email:'manop.i@banpu.com',    jobTitle:'Workplace Services Manager',    dept:'Corporate Services' },
  { name:'Surasak Boon',    email:'surasak.b@banpu.com',  jobTitle:'Facilities Systems Engineer',   dept:'Corporate Services' },
  { name:'Pichai Som',      email:'pichai.s@banpu.com',   jobTitle:'HSE Systems Owner',             dept:'Health, Safety & Environment' },
  { name:'Ratana Pim',      email:'ratana.p@banpu.com',   jobTitle:'HSE Analyst',                   dept:'Health, Safety & Environment' },
  { name:'Pimchanok R.',    email:'pimchanok.r@banpu.com',jobTitle:'Group HR Director',             dept:'Human Resources' },
  { name:'Veerasak Lim',    email:'veerasak.l@banpu.com', jobTitle:'Procurement Product Owner',     dept:'Procurement' },
  { name:'Pornchai Sak',    email:'pornchai.s@banpu.com', jobTitle:'Procurement Systems Analyst',   dept:'Procurement' },
];
const jobTitleFor = (email) => (AZURE_AD.find(p => p.email === email) || {}).jobTitle || '—';
const adPerson = (name, email) => ({ name, email, jobTitle: jobTitleFor(email) });

/* ---- Available Master Data tables from CIF (Step 4 picker) ---- */
const CIF_TABLES = [
  'Joblevel','JobLevelDoa','Company','Business Unit','Function',
  'Subfunction1','Subfunction2','Subfunction3','Subfunction4','Subfunction5',
  'Subfunction6','Subfunction7','Employee Status','Contract Type','PositionMaster',
  'Business Stream','Work Location','Country',
];

/* ---- Application-name catalogue for the create autocomplete ----
   A name is selectable only if it is NOT already registered in an
   active/in-progress request. Names whose only record was Terminated
   become available again. */
const APP_CATALOG = [
  'Employee Engagement','Talent Mobility Portal','Payroll Sync — Indonesia','Learning Hub LMS',
  'Access Card Provisioning','BKV US — Headcount Feed','Safety Induction Tracker','Org Chart Visualizer',
  'Contractor Onboarding','Mongolia Site HR Bridge','Vendor Portal SSO','Wellness App — TH',
  'Succession Planning Board','Time & Attendance Bridge','Recruitment ATS Feed','Expense Approval Sync',
  'Diversity Dashboard','Field Workforce App','Benefits Enrollment Portal','Travel Desk Integration',
];
function availableAppNames(apps, currentId) {
  // names taken by any non-terminated request (excluding the one being edited)
  const taken = new Set(apps
    .filter(a => a.status !== 'Terminated' && a.id !== currentId)
    .map(a => a.name.trim().toLowerCase()));
  return APP_CATALOG.filter(n => !taken.has(n.trim().toLowerCase()));
}

/* ============================================================
   VERSIONING
   Each application keeps a full version lineage. Editing a
   finalized (Active/Approved/Inactive/Rejected) version creates
   a NEW version that re-enters the approval line; the previous
   version stays available so dependent teams don't break.
   ============================================================ */

// people in the workflow
const ROLES = {
  hr:    { name:'Moni Roy',      role:'HR Administrator' },
  it:    { name:'Krit Wattana',  role:'IT Administrator' },
  po:    { name:'Product Owner', role:'Product Owner' },
  so:    { name:'Suda Niran',    role:'System Owner' },
  sys:   { name:'System',        role:'Automated' },
};

/* ============================================================
   APPROVAL WORKFLOW — two variants depending on who created it.
   • Created by PO or IT  → HR reviews & approves up front (7 steps).
   • Created by HR         → HR is the requester, so the separate
     HR-review step is skipped to avoid self-approval (6 steps).
   Step logic keys off each step's `key`, so both variants share the
   same action handlers.
   ============================================================ */
const WORKFLOW_STD = [
  { n:1, key:'request',    role:'PO', actor:'po', label:'Request',            short:'Request created', type:'form',
    desc:'A Product Owner or IT captures the requester details and access scope, then submits the request.' },
  { n:2, key:'hr_review',  role:'HR', actor:'hr', label:'HR Review & Approve', short:'Awaiting HR review', type:'page', email:'hr',
    desc:'HR reviews the submitted request and access scope, then approves it into the workflow.' },
  { n:3, key:'it_submit',  role:'IT', actor:'it', label:'Submit to PO',       short:'Awaiting IT', type:'modal', email:'it',
    desc:'IT reviews the request, enters the integration Key & Client Code, and forwards it to the Product Owner for testing.' },
  { n:4, key:'po_test',    role:'PO', actor:'po', label:'PO Testing',         short:'PO testing (offline)', type:'offline', email:'po',
    desc:'The Product Owner tests the integration in their environment and replies with the result. Handled offline by email.' },
  { n:5, key:'it_confirm', role:'IT', actor:'it', label:'IT Confirm',         short:'Awaiting IT confirm', type:'page',
    desc:'After the PO confirms a successful test, IT confirms the request form and routes it to the System Owner.' },
  { n:6, key:'so_submit',  role:'SO', actor:'so', label:'SO Submit',          short:'Awaiting System Owner', type:'modal', email:'so',
    desc:'The System Owner enters the Key & Client Code to provision the integration.' },
  { n:7, key:'finished',   role:'System', actor:'sys', label:'Finished',      short:'Active', type:'system',
    desc:'Provisioning complete. The integration is now Active.' },
];
const WORKFLOW_HR = [
  { n:1, key:'request',    role:'HR', actor:'hr', label:'HR Request',   short:'Request created', type:'form',
    desc:'HR captures the requester details and access scope, then submits the request. As the requester, no separate HR review is needed.' },
  { n:2, key:'it_submit',  role:'IT', actor:'it', label:'Submit to PO',  short:'Awaiting IT', type:'modal', email:'it',
    desc:'IT reviews the request, enters the integration Key & Client Code, and forwards it to the Product Owner for testing.' },
  { n:3, key:'po_test',    role:'PO', actor:'po', label:'PO Testing',    short:'PO testing (offline)', type:'offline', email:'po',
    desc:'The Product Owner tests the integration and replies with the result. Handled offline by email.' },
  { n:4, key:'it_confirm', role:'IT', actor:'it', label:'IT Confirm',    short:'Awaiting IT confirm', type:'page',
    desc:'After the PO confirms a successful test, IT confirms the request form and routes it to the System Owner.' },
  { n:5, key:'so_submit',  role:'SO', actor:'so', label:'SO Submit',     short:'Awaiting System Owner', type:'modal', email:'so',
    desc:'The System Owner enters the Key & Client Code to provision the integration.' },
  { n:6, key:'finished',   role:'System', actor:'sys', label:'Finished', short:'Active', type:'system',
    desc:'Provisioning complete. The integration is now Active.' },
];
const WORKFLOW = WORKFLOW_STD;   // default (used by generic email gallery reps)
const workflowFor = (app) => (app && app.createdByRole === 'HR') ? WORKFLOW_HR : WORKFLOW_STD;
const stepByKey = (app, key) => workflowFor(app).find(w => w.key === key);
const STEP_OF = (app) => app.step || (app.status === 'Active' ? workflowFor(app).length : 1);
const STEP_META = (app, n) => workflowFor(app).find(w => w.n === (n == null ? STEP_OF(app) : n)) || workflowFor(app)[0];
// the person assigned to act on this app right now (null if not actionable)
function pendingRole(app) {
  if (app.status !== 'In Progress') return null;
  const m = STEP_META(app, STEP_OF(app));
  return m.role === 'System' ? null : m.role;
}
// human-readable label of the current stage
function stageLabel(app) {
  if (app.status === 'Draft') return 'Draft';
  if (app.status === 'Active') return 'Active';
  if (app.status === 'Archived') return 'Archived (previous version)';
  if (app.status === 'Terminated') return 'Terminated';
  if (app.status === 'Cancelled') return 'Cancelled';
  return STEP_META(app, STEP_OF(app)).short;
}

/* ---------- Email template content per step ---------- */
function emailFor(kind, app) {
  const base = { kind, app, id: app.id || 'CLT-0000XXXX', name: app.name };
  const T = {
    it: {
      to: `${ROLES.it.name} · it.useraccess@banpu.com`,
      from: 'User Management <no-reply@banpu.io>',
      subject: `[Action required] Access request approved by HR — ${app.name} (${app.id})`,
      preheader: 'HR approved a request. IT to issue credentials and forward to the Product Owner.',
      role: 'IT', cta: 'Open & Submit to PO', step: 3,
      intro: `HR has approved the access request for ${app.name} (requested by ${app.requester}). Please review the details, issue the integration Key & Client Code, then forward to the Product Owner for testing.`,
    },
    po: {
      to: `${app.owner} · ${app.ownerEmail}`,
      from: 'User Management <no-reply@banpu.io>',
      subject: `[Please test] ${app.name} integration ready for your testing (${app.id})`,
      preheader: 'IT has provisioned a test integration. Please test and reply with the result.',
      role: 'PO', cta: 'Reply with test result', step: 4, offline: true, showKey: true,
      intro: `IT has set up the ${app.name} integration for testing. Please run your tests against the endpoint below and reply to this email with the outcome (pass / fail + notes). This step is handled offline. Your integration Key is included below — keep it confidential.`,
    },
    hr: {
      to: `${app.requester} · ${ROLES.hr.name} <moni.roy@banpu.com>`,
      from: 'User Management <no-reply@banpu.io>',
      subject: `[Review & approve] ${app.name} — HR review (${app.id})`,
      preheader: 'A new request needs HR review and approval before IT provisions it.',
      role: 'HR', cta: 'Review & Approve', step: 2,
      intro: `A new access request for ${app.name} was submitted by ${app.requester}. As HR, please review the request details and access scope, then approve it to route to IT for provisioning.`,
    },
    so: {
      to: `${ROLES.so.name} · system.owner@banpu.com`,
      from: 'User Management <no-reply@banpu.io>',
      subject: `[Provision] ${app.name} approved — ready to activate (${app.id})`,
      preheader: 'IT confirmed the request. System Owner to enter credentials and activate.',
      role: 'SO', cta: 'Open & Submit', step: 6,
      intro: `${app.name} has been confirmed by IT and is ready for provisioning. As System Owner, please enter the Key & Client Code to provision the integration and set it Active.`,
    },
    active: {
      to: `${app.requester} (HR) · ${ROLES.it.name} (IT) · ${app.owner} (PO)`,
      from: 'User Management <no-reply@banpu.io>',
      subject: `[Activated] ${app.name} is now live (${app.id})`,
      preheader: 'Provisioning complete — the integration is Active.',
      role: 'ALL', cta: 'View request', step: 7, broadcast: true,
      intro: `${app.name} has been provisioned by the System Owner and is now Active. This notification is sent to HR, IT and the Product Owner. The integration Key is shared with the Product Owner only.`,
    },
    contacts: {
      to: `${ROLES.hr.name} (HR) · ${ROLES.it.name} (IT) · ${app.owner} (new assignee)`,
      from: 'User Management <no-reply@banpu.io>',
      subject: `[Updated] Product Owner / Tech Lead changed — ${app.name} (${app.id})`,
      preheader: 'The people responsible for this integration were updated.',
      role: 'ALL', cta: 'View request', step: workflowFor(app).length, broadcast: true, contacts: true,
      intro: `The assigned Product Owner and/or Tech Lead for ${app.name} have been updated (for example, a handover or a departing employee). This notification is sent to HR, IT and the newly-assigned people. The integration's scope, columns and credentials are unchanged.`,
      changes: [
        { label:'Product Owner', from: app._prevOwner || 'Praphan Tula', to: app.owner || '—' },
        { label:'Tech Lead',     from: app._prevLead  || 'Kanya Rit',    to: app.lead  || 'Not specified' },
      ],
    },
  };
  return { ...base, ...T[kind] };
}
const EMAIL_KINDS = ['it','po','hr','so','active','contacts'];

// version lineage keyed by Client ID. Only apps with >1 version listed here;
// everything else is treated as a single v1 (see versionsOf()).
const LINEAGE = {
  'CLT-00010482': [   // Employee Engagement — full 3-version lineage
    { version:1, status:'Archived',  created:'12/03/2026', by:'Moni Roy',
      changelog:'Initial release — TH/ID headcount feed, API only.',
      usedBy:['Power BI HR Dashboard'], prevVersion:null,
      detail:{ access:['API'], endpoint:'https://eng.banpu.io/v1', key:'eng_1a0p-INIT', clientCode:'CLT-00010482',
        columns:6, rules:1, sources:0, cols:['UserID','Country','BusinessUnit','JobTitle','HireDate','Status'],
        rule:'(Company_Code == "BPP")', pii:0, masterData:[] } },
    { version:2, status:'Active',  created:'04/06/2026', by:'Moni Roy',
      changelog:'Added Mongolia & Lao PDR sources; added File Base delivery; restricted Salary & AgeRange (PII).',
      usedBy:['Power BI HR Dashboard','Town Hall Mobile App'], prevVersion:1,
      detail:{ access:['API','File Base'], endpoint:'https://eng.banpu.io/api', key:'eng_5c2a-ENGAGE', clientCode:'CLT-00010482',
        columns:9, rules:2, sources:3, cols:['UserID','Country','BusinessUnit','JobTitle','HireDate','Status','CostCenter','Region','Salary'],
        rule:'(Company_Code == "BPP") AND (Country IN [TH, ID, MN, LA])', pii:2, masterData:['SAP SF','HRIS-TH','AD'] } },
    { version:3, status:'In Progress', created:'20/06/2026', by:'Moni Roy', step:5,
      changelog:'Adds Engagement Score & Survey Wave columns for the FY26 pulse survey. Pending approval — v2 stays live until this is Active.',
      usedBy:[], prevVersion:2, isLatest:true,
      detail:{ access:['API','File Base'], endpoint:'https://eng.banpu.io/api', key:'eng_9f1d-PULSE', clientCode:'CLT-00010482',
        columns:11, rules:3, sources:3, cols:['UserID','Country','BusinessUnit','JobTitle','HireDate','Status','CostCenter','Region','Salary','EngagementScore','SurveyWave'],
        rule:'(Company_Code == "BPP") AND (Country IN [TH, ID, MN, LA]) AND (Active == true)', pii:2, masterData:['SAP SF','HRIS-TH','AD'] } },
  ],
  'CLT-00010477': [   // Talent Mobility Portal — v1 live while v2 pending
    { version:1, status:'Active',  created:'20/04/2026', by:'Moni Roy',
      changelog:'Initial release — API read-only. Remains active until v2 is approved & activated.',
      usedBy:['Talent Mobility Portal'], prevVersion:null,
      detail:{ access:['API'], endpoint:'https://talent.banpu.io/v1', key:'tlm_4b2a-LIVE', clientCode:'CLT-00010477',
        columns:7, rules:1, sources:2, cols:['UserID','Country','JobTitle','JobFamily','Grade','Mobility','Status'],
        rule:'(Region == "APAC")', pii:0, masterData:['SAP SF','AD'] } },
    { version:2, status:'In Progress', created:'05/06/2026', by:'Moni Roy', step:2,
      changelog:'Added Business Unit & Cost Center columns for the new mobility report. Will replace v1 only once Active.',
      usedBy:[], prevVersion:1, isLatest:true,
      detail:{ access:['API'], endpoint:'https://talent.banpu.io/hook', key:'tlm_9f3a-PAYID', clientCode:'CLT-00010477',
        columns:9, rules:2, sources:3, cols:['UserID','Country','JobTitle','JobFamily','Grade','Mobility','Status','BusinessUnit','CostCenter'],
        rule:'(Region == "APAC") AND (Active == true)', pii:0, masterData:['SAP SF','AD','HRIS-TH'] } },
  ],
  'CLT-00010530': [   // Time & Attendance Bridge — 3-version lineage, ultimately terminated
    { version:1, status:'Archived', created:'10/01/2026', by:'Moni Roy',
      changelog:'Initial release — TH attendance feed, API only.',
      usedBy:[], prevVersion:null,
      detail:{ access:['API'], endpoint:'https://tna.banpu.io/v1', key:'tna_1a2b-INIT', clientCode:'CLT-00010530',
        columns:5, rules:1, sources:0, cols:['UserID','Country','ShiftCode','ClockIn','ClockOut'],
        rule:'(Company_Code == "BPP")', pii:0, masterData:[] } },
    { version:2, status:'Archived', created:'02/03/2026', by:'Moni Roy',
      changelog:'Added Indonesia sources and File Base delivery.',
      usedBy:[], prevVersion:1,
      detail:{ access:['API','File Base'], endpoint:'https://tna.banpu.io/api', key:'tna_5c6d-ATTND', clientCode:'CLT-00010530',
        columns:8, rules:2, sources:2, cols:['UserID','Country','ShiftCode','ClockIn','ClockOut','OvertimeHrs','CostCenter','Site'],
        rule:'(Company_Code == "BPP") AND (Country IN [TH, ID])', pii:0, masterData:['SAP SF','HRIS-TH'] } },
    { version:3, status:'Terminated', created:'15/05/2026', by:'Moni Roy', step:7,
      changelog:'Migrated to the group Time & Attendance platform; this integration was decommissioned.',
      usedBy:[], prevVersion:2, isLatest:true,
      detail:{ access:['API','File Base'], endpoint:'https://tna.banpu.io/api', key:'tna_9e0f-FINAL', clientCode:'CLT-00010530',
        columns:8, rules:2, sources:2, cols:['UserID','Country','ShiftCode','ClockIn','ClockOut','OvertimeHrs','CostCenter','Site'],
        rule:'(Company_Code == "BPP") AND (Country IN [TH, ID])', pii:0, masterData:['SAP SF','HRIS-TH'] } },
  ],
  'CLT-00010560': [   // Recruitment ATS Feed — 3 versions, all resolved, v3 live Active
    { version:1, status:'Archived', created:'14/02/2026', by:'Veerasak Lim',
      changelog:'Initial release — candidate feed, API only.',
      usedBy:[], prevVersion:null,
      detail:{ access:['API'], endpoint:'https://ats.banpu.io/v1', key:'ats_1c2d-INIT', clientCode:'CLT-00010560',
        columns:6, rules:1, sources:0, cols:['CandidateID','Country','Requisition','Stage','AppliedDate','Status'],
        rule:'(Company_Code == "BPP")', pii:0, masterData:[] } },
    { version:2, status:'Archived', created:'10/04/2026', by:'Veerasak Lim',
      changelog:'Added Business Unit & File Base delivery for the regional recruiting team.',
      usedBy:[], prevVersion:1,
      detail:{ access:['API','File Base'], endpoint:'https://ats.banpu.io/v2', key:'ats_4e5f-STEP2', clientCode:'CLT-00010560',
        columns:8, rules:2, sources:1, cols:['CandidateID','Country','Requisition','Stage','AppliedDate','Status','BusinessUnit','Recruiter'],
        rule:'(Company_Code == "BPP") AND (Region == "APAC")', pii:0, masterData:['SAP SF'] } },
    { version:3, status:'Active', created:'19/06/2026', by:'Veerasak Lim', step:7,
      changelog:'Added Offer Status & Source Channel columns for the FY26 hiring dashboard.',
      usedBy:['Recruiting Dashboard'], prevVersion:2, isLatest:true,
      detail:{ access:['API','File Base'], endpoint:'https://ats.banpu.io/api', key:'ats_7b3e-LIVE3', clientCode:'CLT-00010560',
        columns:10, rules:2, sources:2, cols:['CandidateID','Country','Requisition','Stage','AppliedDate','Status','BusinessUnit','Recruiter','OfferStatus','SourceChannel'],
        rule:'(Company_Code == "BPP") AND (Region == "APAC")', pii:0, masterData:['SAP SF','AD'] } },
  ],
};

// project a single version's detail onto an app-shaped object (for the version-detail / compare views)
function versionAsApp(app, v) {
  const d = v.detail || {};
  const wfLen = workflowFor(app).length;
  const step = v.step != null ? v.step
    : (v.status === 'Active' || v.status === 'Archived') ? wfLen
    : v.status === 'In Progress' ? Math.max(1, wfLen - 2)
    : 1;
  return { ...app, ...d, status:v.status, version:v.version, submitted:v.created, updated:v.created,
    step, _versionView:true, changelog:v.changelog, by:v.by, usedBy:v.usedBy, isLatest:v.isLatest };
}

// pre-fill a "create new version" form from a CHOSEN prior version, while the
// new version number always continues from the latest version in the lineage.
function baseAppForNewVersion(app, chosenVersion) {
  const lineage = versionsOf(app);
  const maxV = Math.max(...lineage.map(v => v.version));
  const snap = versionAsApp(app, chosenVersion);
  return { ...snap, status:'Active', version:maxV, uid:app.uid, id:app.id,
    _basedOnVersion: chosenVersion.version !== maxV ? chosenVersion.version : null };
}

// return the lineage array for an app (synthesises a single v1 if none recorded)
function versionsOf(app) {
  if (LINEAGE[app.id]) return LINEAGE[app.id];
  return [{ version:1, status:app.status, created:app.submitted, by:'Moni Roy',
    changelog:'Initial release.', usedBy:[app.name], prevVersion:null, isLatest:true,
    detail:{ access:app.access, endpoint:app.endpoint, key:app.key, clientCode:app.clientCode,
      columns:app.columns, rules:app.rules, sources:app.sources } }];
}

/* ---------- Comprehensive audit-trail generator ----------
   Produces a full who-did-what trail reflecting the 7-step
   approval workflow, up to the app's current step. Newest first. */
function auditTrail(app) {
  const v = app.version || 1;
  const ev = [];
  const E = (who, action, time, detail, version = v) =>
    ev.push({ actor: ROLES[who].name, role: ROLES[who].role, action, date: time, detail, version });
  const d = app.submitted;
  const u = app.updated;
  const piiNote = app.columns >= 12 ? ' (incl. 2 PII fields flagged for review)' : '';

  const createdBy = app.createdByRole || 'PO';
  const creatorActor = { HR:'hr', IT:'it', PO:'po' }[createdBy] || 'po';
  const wf = workflowFor(app);

  // ----- step 1: authoring by the creator (always) -----
  if (v > 1) E(creatorActor, 'Version', `${d} 08:55`, `Started version v${v}, branched from v${v - 1} of ${app.id}. Previous version remains available to dependent teams.`);
  E(creatorActor, 'Create', `${d} 09:12`, v > 1 ? `Cloned v${v - 1} as draft for v${v}` : `Created request for ${app.requester}`);
  E(creatorActor, 'Update', `${d} 10:08`, `Defined access scope — ${app.rules} rule${app.rules !== 1 ? 's' : ''}, ${app.columns} column${app.columns !== 1 ? 's' : ''}${piiNote}`);

  if (app.status === 'Draft') {
    E(creatorActor, 'Update', `${d} 10:40`, 'Saved as draft — not yet submitted');
    return ev.reverse();
  }
  if (app.status === 'Cancelled') {
    E(creatorActor, 'Submit', `${d} 11:00`, 'Submitted request');
    E('it', 'Reject', `${u} 14:20`, app.cancelReason || 'Cancelled — request closed.');
    return ev.reverse();
  }

  const step = STEP_OF(app);
  const nextMeta = wf[1];   // the first step after "request"
  // step 1 done — submitted, routed to the next owner
  E(creatorActor, 'Submit', `${d} 11:00`, nextMeta.key === 'hr_review' ? 'Submitted request — routed to HR for review' : 'Submitted request — routed to IT');
  E('sys', 'Notify', `${d} 11:00`, `Emailed ${ROLES[nextMeta.actor].name} (${nextMeta.role}) — ${nextMeta.label}`);

  const KEY_EVENT = {
    hr_review:  { actor:'hr', action:'Approve', detail:'HR reviewed the request and access scope and approved it.', notify:`Emailed ${ROLES.it.name} (IT) — Submit to PO` },
    it_submit:  { actor:'it', action:'Update',  detail:`Entered Key & Client Code; forwarded to Product Owner (${app.owner}) for testing`, notify:`Emailed ${app.owner} (Product Owner) — please test` },
    po_test:    { actor:'po', action:'Approve', detail:`Product Owner tested the integration — result: ${app.poResult === 'pass' ? 'PASS' : 'reported'}. Replied by email.` },
    it_confirm: { actor:'it', action:'Approve', detail:'IT confirmed the request form. Cleared to the System Owner for provisioning.', notify:`Emailed ${ROLES.so.name} (System Owner) — provision` },
  };
  // walk each completed step (n < current) and emit its event
  wf.forEach(w => {
    if (w.key === 'request' || w.key === 'finished' || w.key === 'so_submit') return;
    if (w.n < step) {
      const k = KEY_EVENT[w.key]; if (!k) return;
      const t = w.n <= 2 ? d : u;
      E(k.actor, k.action, `${t} ${9 + w.n}:${w.n}0`, k.detail);
      if (k.notify) E('sys', 'Notify', `${t} ${9 + w.n}:${w.n}5`, k.notify);
    }
  });

  if (app.status === 'Active' || step >= wf.length) {
    E('so', 'Approve', `${u} 11:25`, 'System Owner entered Key & Client Code and provisioned the integration.');
    E('sys', 'Activate', `${u} 11:26`, `Provisioned & activated v${v}. Credentials issued to ${app.owner}.`);
    if (v > 1) E('sys', 'Notify', `${u} 11:26`, `v${v - 1} retained as a previous version — no disruption to existing consumers.`);
  }
  if (app.status === 'Terminated') {
    E('it', 'Deactivate', `${u} 17:00`, app.termReason || 'Terminated — access revoked.');
  }
  // current pending pointer
  if (app.status === 'In Progress') {
    const m = STEP_META(app, step);
    E(m.actor === 'po' ? 'po' : m.actor, 'View', `${u} now`, `Awaiting: ${m.label} — owned by ${ROLES[m.actor].name}`);
  }
  return ev.reverse();
}

// is there already an unfinished newer version in this app's lineage?
// (used to block creating a second concurrent new version)
function hasOpenVersion(app) {
  return versionsOf(app).some(v => v.status === 'In Progress' || v.status === 'Draft');
}

Object.assign(window, { APPS, COLUMNS, FIELD_OPTIONS, VALUE_OPTIONS, OPERATORS, MASTER_GROUPS, SOURCE_SYSTEMS,
  AZURE_AD, jobTitleFor, adPerson, CIF_TABLES, APP_CATALOG, availableAppNames,
  ROLES, LINEAGE, versionsOf, versionAsApp, baseAppForNewVersion, hasOpenVersion, auditTrail,
  WORKFLOW, WORKFLOW_STD, WORKFLOW_HR, workflowFor, stepByKey, STEP_OF, STEP_META, pendingRole, stageLabel, emailFor, EMAIL_KINDS });

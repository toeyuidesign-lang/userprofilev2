/* ============================================================
   History (audit) log modal · Version lineage modal · Action modal
   ============================================================ */
const ACTION_ICON = {
  Create:'fileplus', Update:'edit', Submit:'send', Notify:'bell', View:'eye',
  Approve:'check', Revise:'rotate', Reject:'x2', Activate:'shield', Deactivate:'x2', Version:'copy',
};
const ACTION_COLOR = {
  Create:'var(--ink-500)', Update:'var(--brand)', Submit:'var(--blue-600)', Notify:'var(--ink-400)',
  View:'var(--ink-500)', Approve:'var(--green-600)', Revise:'var(--purple-600)', Reject:'var(--danger)',
  Activate:'var(--green-600)', Deactivate:'var(--ink-600)', Version:'var(--banpu-plum)',
};
const ROLE_ABBR = (n) => n.split(' ').map(w => w[0]).join('').slice(0,2).toUpperCase();

/* ---------------- Audit / History log ---------------- */
function HistoryModal({ app, onClose }) {
  const trail = useMemo(() => auditTrail(app), [app]);
  const FILTERS = ['All','Authoring','Approval','System'];
  const groupOf = (a) => ['Create','Update','Version','Submit'].includes(a) ? 'Authoring'
    : ['View','Approve','Revise','Reject'].includes(a) ? 'Approval' : 'System';
  const [filter, setFilter] = useState('All');
  const rows = trail.filter(e => filter === 'All' || groupOf(e.action) === filter);

  return (
    <Modal title="History Log" onClose={onClose}
      footer={<Btn variant="ghost" onClick={onClose}>Close</Btn>}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:18, paddingBottom:18, borderBottom:'1px solid var(--border-subtle)' }}>
        <div className="avatar" style={{ background:'var(--gradient-brand)', color:'#fff', borderRadius:'var(--radius-sm)' }}><Icon name="layers" size={18} /></div>
        <div>
          <div className="cell-strong" style={{ fontSize:15 }}>{app.name}</div>
          <div className="cell-id">{app.id} · v{app.version || 1}</div>
        </div>
        <div style={{ marginLeft:'auto' }}><StatusChip status={app.status} /></div>
      </div>

      {/* filter chips */}
      <div style={{ display:'flex', gap:8, marginBottom:20, flexWrap:'wrap' }}>
        {FILTERS.map(f => (
          <button key={f} onClick={() => setFilter(f)} style={{
            padding:'6px 13px', borderRadius:'999px', fontSize:12.5, fontWeight:600,
            border:`1.5px solid ${filter === f ? 'var(--brand)' : 'var(--border)'}`,
            background: filter === f ? 'var(--brand)' : '#fff', color: filter === f ? '#fff' : 'var(--fg-secondary)' }}>
            {f}
          </button>
        ))}
      </div>

      <div className="timeline">
        {rows.map((h, i) => (
          <div className="tl-item" key={i}>
            <div className="tl-dot done" style={{ background: ACTION_COLOR[h.action], borderColor: ACTION_COLOR[h.action] }}>
              <Icon name={ACTION_ICON[h.action]} size={11} />
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap' }}>
              <span className="ti">{h.action === 'Version' ? 'New version' : h.action}</span>
              {app.version > 1 && <span className="chip chip-revise" style={{ padding:'1px 8px', fontSize:10.5 }}>v{h.version}</span>}
              <span className="ts" style={{ margin:0, marginLeft:'auto' }}>{h.date}</span>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8, margin:'6px 0 0' }}>
              <span style={{ width:24, height:24, borderRadius:'50%', flex:'0 0 24px', background:'var(--purple-100)', color:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:10, fontWeight:700, fontFamily:'var(--font-display)' }}>{ROLE_ABBR(h.actor)}</span>
              <span style={{ fontSize:12.5, color:'var(--fg-secondary)' }}><b style={{ color:'var(--fg)' }}>{h.actor}</b> · {h.role}</span>
            </div>
            <div className="tc" style={{ marginTop:8 }}>{h.detail}</div>
          </div>
        ))}
      </div>
    </Modal>
  );
}

/* ---------------- Version lineage ---------------- */
function VersionModal({ app, onClose, onView, onCompare, onNewVersion }) {
  const versions = useMemo(() => [...versionsOf(app)].reverse(), [app]);  // newest first
  const multi = versions.length > 1;
  const versionLocked = hasOpenVersion(app);   // a newer version is already in the workflow
  return (
    <Modal title="Version History" onClose={onClose}
      footer={<>
        <Btn variant="ghost" onClick={onClose}>Close</Btn>
        {multi && <Btn variant="outline" icon="layers" onClick={() => onCompare(app)}>Compare versions</Btn>}
        {versionLocked
          ? <span title="A new version is already in progress"><Btn variant="accent" icon="gitbranch" disabled>New version in progress</Btn></span>
          : <Btn variant="accent" icon="gitbranch" onClick={() => onNewVersion(app)}>Create new version</Btn>}
      </>}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:18, paddingBottom:18, borderBottom:'1px solid var(--border-subtle)' }}>
        <div className="avatar" style={{ background:'var(--gradient-brand)', color:'#fff', borderRadius:'var(--radius-sm)' }}><Icon name="layers" size={18} /></div>
        <div>
          <div className="cell-strong" style={{ fontSize:15 }}>{app.name}</div>
          <div className="cell-id">{app.id}</div>
        </div>
        <span className="tag" style={{ marginLeft:'auto' }}><Icon name="copy" size={13} />{versions.length} version{versions.length !== 1 ? 's' : ''}</span>
      </div>

      <div style={{ background:'var(--blue-50)', border:'1px solid var(--blue-100)', borderRadius:'var(--radius-md)', padding:'12px 15px', marginBottom:20, display:'flex', gap:10, fontSize:13, color:'var(--fg-secondary)', lineHeight:1.55 }}>
        <span style={{ color:'var(--blue-600)', flex:'0 0 auto' }}><Icon name="shield" size={18} /></span>
        <span>While a new version is pending approval, the current version stays <b>Active</b> and keeps serving connected teams. Once the new version becomes Active, the previous one is moved to <b>Archived</b> — preserved for reference, no disruption to existing consumers.</span>
      </div>

      <div className="timeline">
        {versions.map(v => {
          const latest = v.isLatest || versions.length === 1;
          return (
            <div className="tl-item" key={v.version}>
              <div className={`tl-dot ${latest ? 'cur' : 'done'}`} style={latest ? {} : { background:'var(--grey-200)', borderColor:'var(--grey-200)' }}>
                {!latest && <span style={{ fontSize:9, fontWeight:700, color:'var(--ink-600)' }}>v{v.version}</span>}
                {latest && <span style={{ width:7, height:7, borderRadius:'50%', background:'#fff' }}></span>}
              </div>
              <div style={{ border:`1.5px solid ${latest ? 'var(--purple-200)' : 'var(--border)'}`, borderRadius:'var(--radius-md)', padding:'13px 16px', background: latest ? 'var(--purple-50)' : '#fff' }}>
                <div style={{ display:'flex', alignItems:'center', gap:9, flexWrap:'wrap' }}>
                  <span className="cell-strong" style={{ fontSize:15, fontFamily:'var(--font-display)' }}>Version {v.version}</span>
                  <StatusChip status={v.status} />
                  {latest
                    ? <span className="chip chip-info" style={{ padding:'2px 9px' }}>Latest</span>
                    : <span className="chip chip-draft" style={{ padding:'2px 9px' }}>Previous</span>}
                  <span className="ts" style={{ margin:0, marginLeft:'auto' }}>{v.created} · {v.by}</span>
                </div>
                <div style={{ fontSize:13, color:'var(--fg-secondary)', margin:'9px 0 0', lineHeight:1.5 }}>{v.changelog}</div>
                {v.prevVersion && (
                  <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:9, fontSize:12.5, color:'var(--brand)', fontWeight:600 }}>
                    <Icon name="link" size={13} /> References v{v.prevVersion}
                  </div>
                )}
                {v.usedBy && v.usedBy.length > 0 && (
                  <div style={{ display:'flex', alignItems:'center', gap:7, marginTop:10, flexWrap:'wrap' }}>
                    <span className="muted" style={{ fontSize:11.5, fontWeight:600 }}>In use by</span>
                    {v.usedBy.map(u => <span key={u} className="chip chip-active" style={{ padding:'2px 9px', fontSize:11 }}><Icon name="server" size={11} />{u}</span>)}
                  </div>
                )}
                <div style={{ display:'flex', gap:8, marginTop:13 }}>
                  <Btn variant="outline" size="sm" icon="eye" onClick={() => onView(app, v)}>View v{v.version}</Btn>
                  {v.prevVersion && <Btn variant="ghost" size="sm" icon="layers" onClick={() => onCompare(app, v)}>Compare with v{v.prevVersion}</Btn>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Modal>
  );
}

/* ---------------- Key + Client Code credential window ----------------
   Used by IT (Submit to PO, step 2 — Confirm disabled), IT (Confirm,
   step 4 — same window, Confirm now enabled, can Cancel), and SO (step 6). */
function CredentialModal({ app, stage, onClose, onSubmit, onCancelRequest }) {
  const ro = stage === 'it4';
  const [k, setK] = useState(ro ? (app.key || '') : '');
  // SO: Client Code defaults to what IT entered and is locked (cannot be edited)
  const codeLocked = ro || stage === 'so';
  const [c, setC] = useState(ro ? (app.clientCode || '') : (stage === 'so' ? (app.clientCode || '') : ''));
  const isFileBase = (app.access || []).includes('File Base');
  // File Base extra fields (mock data pre-filled while real values are collected)
  const [fb, setFb] = useState({
    host: 'sftp.banpu.io',
    port: '22',
    username: (app.id ? app.id.toLowerCase().replace('clt-', 'svc_') : 'svc_account'),
    directory: `/inbound/${(app.name || 'app').toLowerCase().replace(/[^a-z0-9]+/g, '-')}/`,
  });
  const filled = k.trim() && c.trim();
  const title = { it2:'Submit to Product Owner', it4:'Confirm request form', so:'Provision integration' }[stage];
  const desc = {
    it2:'Enter the integration Key & Client Code, then forward to the Product Owner for testing.',
    it4:'The Product Owner tested this integration successfully. Confirm the request form to send it to HR for final review.',
    so:'Enter the integration Key & Client Code to provision and activate this integration.',
  }[stage];

  let footer;
  if (stage === 'it2') footer = <>
    <Btn variant="danger" icon="x2" onClick={onCancelRequest}>Cancel request</Btn>
    <span style={{ flex:1 }}></span>
    <Btn variant="ghost" onClick={onClose}>Close</Btn>
    <Btn variant="accent" icon="send" disabled={!filled} onClick={() => onSubmit('submit_po', { key:k, clientCode:c })}>Submit to PO</Btn>
  </>;
  else if (stage === 'it4') footer = <>
    <Btn variant="danger" icon="x2" onClick={onCancelRequest}>Cancel request</Btn>
    <span style={{ flex:1 }}></span>
    <Btn variant="outline" icon="check" disabled>Submitted to PO</Btn>
    <Btn variant="success" icon="filecheck" onClick={() => onSubmit('it_confirm', { key:k, clientCode:c })}>Confirm</Btn>
  </>;
  else footer = <>
    <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
    <Btn variant="accent" icon="send" disabled={!filled} onClick={() => onSubmit('so_submit', { key:k, clientCode:c, fileBase: isFileBase ? fb : null })}>Submit &amp; activate</Btn>
  </>;

  return (
    <Modal title={title} size="sm" onClose={onClose} footer={footer}>
      <div style={{ display:'flex', gap:14, marginBottom:18 }}>
        <span style={{ width:44, height:44, flex:'0 0 44px', borderRadius:'50%', background:'var(--purple-50)', color:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}><Icon name="link" size={22} /></span>
        <div>
          <div className="cell-strong" style={{ marginBottom:4 }}>{app.name} <span className="cell-id" style={{ fontWeight:400 }}>· {app.id}</span></div>
          <div className="muted" style={{ fontSize:13, lineHeight:1.5 }}>{desc}</div>
        </div>
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
        <Field label="Key" required>
          <TextInput icon="shield" value={k} placeholder="e.g. tlm_9f3a-XXXX" disabled={ro} onChange={e => setK(e.target.value)} style={ro ? { background:'var(--grey-50)', fontFamily:'monospace' } : { fontFamily:'monospace' }} />
        </Field>
        <Field label="Client Code" required>
          <TextInput icon="server" value={c} placeholder="e.g. CLT-0001XXXX" disabled={codeLocked} onChange={e => setC(e.target.value)} style={codeLocked ? { background:'var(--grey-50)', fontFamily:'monospace' } : { fontFamily:'monospace' }} />
        </Field>
      </div>
      {stage === 'so' && app.clientCode &&
        <div style={{ display:'flex', gap:9, alignItems:'flex-start', marginTop:10, marginBottom:6, fontSize:12, color:'var(--fg-muted)', lineHeight:1.5 }}>
          <Icon name="shield" size={14} style={{ flex:'0 0 auto', marginTop:1, color:'var(--green-600)' }} />
          <span>Client Code is locked to the value IT submitted and cannot be edited here.</span>
        </div>}
      {stage === 'so' && isFileBase &&
        <div style={{ marginTop:14, border:'1px solid var(--border)', borderRadius:'var(--radius-md)', overflow:'hidden' }}>
          <div style={{ background:'var(--blue-50)', padding:'10px 14px', display:'flex', alignItems:'center', gap:9, borderBottom:'1px solid var(--blue-100)' }}>
            <Icon name="download" size={16} style={{ color:'var(--blue-700)' }} />
            <span style={{ fontSize:13, fontWeight:600, color:'var(--blue-700)' }}>File Base delivery</span>
            <span className="chip chip-info" style={{ marginLeft:'auto', padding:'1px 8px', fontSize:10.5 }}>mock data</span>
          </div>
          <div style={{ padding:'14px 16px' }}>
            <div style={{ fontSize:12, color:'var(--fg-muted)', lineHeight:1.5, marginBottom:12 }}>This request uses File Base access — four delivery details are required. Pre-filled with placeholder values while the real configuration is collected.</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
              <Field label="SFTP host"><TextInput value={fb.host} onChange={e => setFb({ ...fb, host:e.target.value })} style={{ fontFamily:'monospace' }} /></Field>
              <Field label="Port"><TextInput value={fb.port} onChange={e => setFb({ ...fb, port:e.target.value })} style={{ fontFamily:'monospace' }} /></Field>
              <Field label="Service username"><TextInput value={fb.username} onChange={e => setFb({ ...fb, username:e.target.value })} style={{ fontFamily:'monospace' }} /></Field>
              <Field label="Drop directory"><TextInput value={fb.directory} onChange={e => setFb({ ...fb, directory:e.target.value })} style={{ fontFamily:'monospace' }} /></Field>
            </div>
          </div>
        </div>}
      {stage === 'it2' &&
        <div style={{ display:'flex', gap:9, alignItems:'flex-start', marginTop:14, fontSize:12.5, color:'var(--fg-muted)', lineHeight:1.5 }}>
          <Icon name="clock" size={15} style={{ flex:'0 0 auto', marginTop:1 }} />
          <span>After you submit, the Product Owner tests offline. You'll confirm the request later (step 4) from the request detail page.</span>
        </div>}
    </Modal>
  );
}

/* ---------------- Reason-required actions (cancel / terminate / problem) ---------------- */
function ReasonModal({ app, kind, onClose, onConfirm }) {
  const [note, setNote] = useState('');
  const conf = {
    cancel_request: { title:'Cancel request', verb:'Cancel request', icon:'x2', color:'var(--danger)', btn:'danger',
      desc:`This closes ${app.name} and notifies the requester. The request will be marked Cancelled.`, label:'Reason for cancelling', need:true },
    delete_draft: { title:'Delete draft', verb:'Delete draft', icon:'trash', color:'var(--danger)', btn:'danger',
      desc:`This draft has not entered the workflow, so it is removed permanently. This cannot be undone.`, label:'Note (optional)', need:false },
    terminate: { title:'Terminate request', verb:'Terminate', icon:'x2', color:'var(--danger)', btn:'danger',
      desc:`This revokes access for ${app.name}. The integration will be set to Terminated. A reason is required.`, label:'Reason for termination', need:true },
    po_failed: { title:'Report a problem', verb:'Send back to IT', icon:'rotate', color:'var(--purple-600)', btn:'primary',
      desc:`Describe what failed during testing. IT will be notified to review.`, label:'What went wrong?', need:true },
  }[kind];
  return (
    <Modal title={conf.title} size="sm" onClose={onClose}
      footer={<>
        <Btn variant="ghost" onClick={onClose}>Back</Btn>
        <Btn variant={conf.btn} icon={conf.icon} disabled={conf.need && !note.trim()} onClick={() => onConfirm(kind, note)}>{conf.verb}</Btn>
      </>}>
      <div style={{ display:'flex', gap:14, marginBottom:18 }}>
        <span style={{ width:44, height:44, flex:'0 0 44px', borderRadius:'50%', background:'var(--grey-50)', color:conf.color, display:'flex', alignItems:'center', justifyContent:'center' }}><Icon name={conf.icon} size={22} /></span>
        <div>
          <div className="cell-strong" style={{ marginBottom:4 }}>{app.name}</div>
          <div className="muted" style={{ fontSize:13, lineHeight:1.5 }}>{conf.desc}</div>
        </div>
      </div>
      <Field label={conf.label} required={conf.need}>
        <textarea className="input" rows={3} placeholder="Type your message…" value={note} onChange={e => setNote(e.target.value)} style={{ resize:'vertical' }} />
      </Field>
    </Modal>
  );
}

/* ---------------- Generic confirm dialog (guards quick clicks) ---------------- */
function ConfirmDialog({ title, message, confirmLabel, variant = 'accent', icon = 'check', onClose, onConfirm }) {
  return (
    <Modal title={title} size="sm" onClose={onClose}
      footer={<>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
        <Btn variant={variant} icon={icon} onClick={onConfirm}>{confirmLabel}</Btn>
      </>}>
      <div style={{ display:'flex', gap:14, alignItems:'flex-start' }}>
        <span style={{ width:44, height:44, flex:'0 0 44px', borderRadius:'50%', background:'var(--purple-50)', color:'var(--brand)', display:'flex', alignItems:'center', justifyContent:'center' }}><Icon name={icon} size={22} /></span>
        <div style={{ fontSize:13.5, color:'var(--fg-secondary)', lineHeight:1.6, paddingTop:2 }}>{message}</div>
      </div>
    </Modal>
  );
}

/* ---------------- Edit PO & Tech Lead (Active only) ----------------
   Reassign the Product Owner / Tech Lead of a live integration (e.g.
   handover or resignation) without changing any other field. On save,
   HR, IT and the newly-assigned people are notified by email. */
function EditContactsModal({ app, onClose, onSave }) {
  const [po, setPo] = useState({ name:app.owner, email:app.ownerEmail, jobTitle:app.ownerTitle || jobTitleFor(app.ownerEmail) });
  const [lead, setLead] = useState(app.lead ? { name:app.lead, email:app.leadEmail, jobTitle:app.leadTitle || jobTitleFor(app.leadEmail) } : null);
  const poChanged = po && po.email !== app.ownerEmail;
  const leadChanged = (lead?.email || '') !== (app.leadEmail || '');
  const samePerson = po && lead && po.email && po.email === lead.email;
  const dirty = (poChanged || leadChanged) && po && po.name && !samePerson;

  const Change = ({ label, from, to, changed }) => (
    <div className="ec-change">
      <span className="ec-change-l">{label}</span>
      <span className="ec-change-r">
        <span className={changed ? 'ec-old' : ''}>{from || 'Not specified'}</span>
        {changed && <><Icon name="chevR" size={13} /><b>{to || 'Not specified'}</b></>}
      </span>
    </div>
  );

  return (
    <Modal title="Edit PO & Tech Lead" onClose={onClose}
      footer={<>
        <Btn variant="ghost" onClick={onClose}>Cancel</Btn>
        <Btn variant="primary" icon="check" disabled={!dirty}
          onClick={() => onSave({ owner:po.name, ownerEmail:po.email, ownerTitle:po.jobTitle,
            lead:lead?.name || '', leadEmail:lead?.email || '', leadTitle:lead?.jobTitle || '' })}>Save & notify</Btn>
      </>}>
      <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:16, paddingBottom:16, borderBottom:'1px solid var(--border-subtle)' }}>
        <div className="avatar" style={{ background:'var(--gradient-brand)', color:'#fff', borderRadius:'var(--radius-sm)' }}><Icon name="layers" size={18} /></div>
        <div>
          <div className="cell-strong" style={{ fontSize:15 }}>{app.name}</div>
          <div className="cell-id">{app.id} · Client Code {app.clientCode || '—'}</div>
        </div>
        <div style={{ marginLeft:'auto' }}><StatusChip status={app.status} /></div>
      </div>

      <div style={{ background:'var(--blue-50)', border:'1px solid var(--blue-100)', borderRadius:'var(--radius-md)', padding:'11px 14px', marginBottom:18, display:'flex', gap:10, fontSize:12.5, color:'var(--fg-secondary)', lineHeight:1.55 }}>
        <span style={{ color:'var(--blue-600)', flex:'0 0 auto' }}><Icon name="shield" size={17} /></span>
        <span>Only the assigned people change here — scope, columns and credentials stay exactly as they are. To change what data the integration receives, create a <b>New version</b> instead.</span>
      </div>

      <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
        <Field label="Product Owner" required>
          <AzurePicker value={po} onSelect={setPo} onClear={() => setPo(null)} exclude={lead?.email ? [lead.email] : []} placeholder="Search Product Owner in Azure AD…" />
        </Field>
        <Field label="Tech Lead" hint="Optional" error={samePerson ? 'Tech Lead must differ from the Product Owner' : undefined}>
          <AzurePicker value={lead} onSelect={setLead} onClear={() => setLead(null)} exclude={po?.email ? [po.email] : []} placeholder="Search Tech Lead in Azure AD…" />
        </Field>
      </div>

      <div style={{ marginTop:18, border:'1px solid var(--border)', borderRadius:'var(--radius-md)', overflow:'hidden' }}>
        <div style={{ background:'var(--purple-50)', padding:'10px 14px', display:'flex', alignItems:'center', gap:9, borderBottom:'1px solid var(--purple-200)' }}>
          <Icon name="mail" size={16} style={{ color:'var(--brand)' }} />
          <span style={{ fontSize:13, fontWeight:600, color:'var(--brand)' }}>Notification preview</span>
          <span className="muted" style={{ marginLeft:'auto', fontSize:11.5 }}>To: HR · IT · new assignees</span>
        </div>
        <div style={{ padding:'12px 15px' }}>
          <div className="ec-change"><span className="ec-change-l">Application</span><span className="ec-change-r"><b>{app.name}</b></span></div>
          <div className="ec-change"><span className="ec-change-l">Client ID</span><span className="ec-change-r">{app.id}</span></div>
          <Change label="Product Owner" from={app.owner} to={po?.name} changed={poChanged} />
          <Change label="Tech Lead" from={app.lead} to={lead?.name} changed={leadChanged} />
        </div>
      </div>
    </Modal>
  );
}

Object.assign(window, { HistoryModal, VersionModal, CredentialModal, ReasonModal, ConfirmDialog, EditContactsModal });

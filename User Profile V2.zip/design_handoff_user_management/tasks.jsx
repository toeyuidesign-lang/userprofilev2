/* ============================================================
   My Tasks — a role-scoped to-do inbox. Shows the requests
   currently awaiting the role you're viewing as, and opens
   each one straight into its action page.
   ============================================================ */
const ROLE_BLURB = {
  HR: 'Requests you submitted that are back for your final review, plus your drafts.',
  IT: 'New requests to forward to the Product Owner, and tested requests to confirm.',
  PO: 'Integrations assigned to you for testing — handled offline by email.',
  SO: 'Approved requests waiting to be provisioned and activated.',
};
const ROLE_ICON = { HR:'user', IT:'settings', PO:'briefcase', SO:'shield' };

function Tasks({ apps, role, openTask, openEdit, openDelete, openVersions, go }) {
  const tasks = apps.filter(a => pendingRole(a) === role);
  const drafts = role === 'HR' ? apps.filter(a => a.status === 'Draft') : [];
  const me = role === 'PO' ? 'Product Owner' : (ROLES[{ HR:'hr', IT:'it', SO:'so' }[role]] || {}).name;

  const TaskRow = ({ a, draft }) => {
    const m = STEP_META(a, STEP_OF(a));
    const lineage = versionsOf(a);
    const liveV = lineage.find(v => v.status === 'Active');
    const isNewVersionTask = !draft && (a.version || 1) > 1 && !!liveV;
    return (
      <div className="taskrow">
        <div className="avatar" style={{ background:'var(--purple-50)' }}><Icon name={isNewVersionTask ? 'gitbranch' : 'layers'} size={18} /></div>
        <div className="tt">
          <div className="nm">{a.name}{isNewVersionTask && <span className="chip chip-revise" style={{ marginLeft:8, padding:'1px 8px', fontSize:10.5 }}>new version · v{a.version}</span>}</div>
          <div className="mt"><span className="cell-id">{a.id}</span> · {draft ? 'Draft — not submitted' : `Step ${m.n} · ${m.label}`} · {a.requester}</div>
          {isNewVersionTask &&
            <div className="task-vnote">
              <Icon name="history" size={13} />
              <span>Revision of an existing integration — <b>v{liveV.version}</b> stays live until this is approved.</span>
              <button className="task-vlink" onClick={() => openVersions(a)}>View versions</button>
            </div>}
        </div>
        <StatusChip status={a.status} />
        {draft
          ? <div style={{ display:'flex', gap:8 }}>
              <Btn variant="outline" size="sm" icon="edit" onClick={() => openEdit(a)}>Open</Btn>
              <Btn variant="ghost" size="sm" icon="trash" onClick={() => openDelete(a)}>Delete</Btn>
            </div>
          : <Btn variant="accent" size="sm" icon="chevR" onClick={() => openTask(a, role)}>Take action</Btn>}
      </div>
    );
  };

  return (
    <div className="content-narrow fade-in">
      <div className="page-head">
        <div>
          <div className="page-title">My Tasks</div>
          <div className="page-sub">Viewing as <b>{me}</b> ({role}). {ROLE_BLURB[role]}</div>
        </div>
      </div>

      <div className="card">
        <div className="toolbar" style={{ borderBottom:'1px solid var(--border-subtle)' }}>
          <div className="section-title" style={{ margin:0, fontSize:15 }}>
            <span style={{ color:'var(--brand)', display:'flex' }}><Icon name={ROLE_ICON[role]} size={18} /></span>
            Awaiting {role}
          </div>
          <div className="spacer" style={{ flex:1 }}></div>
          <span className="chip chip-progress" style={{ padding:'4px 11px' }}>{tasks.length} task{tasks.length !== 1 ? 's' : ''}</span>
        </div>
        <div style={{ padding:'8px 22px 16px' }}>
          {tasks.length === 0
            ? <div className="empty"><Icon name="check" size={32} style={{ opacity:.4 }} /><div style={{ marginTop:10 }}>You're all caught up — no requests awaiting {role}.</div></div>
            : <div className="tasklist">{tasks.map(a => <TaskRow key={a.no} a={a} />)}</div>}
        </div>
      </div>

      {drafts.length > 0 && (
        <div className="card" style={{ marginTop:18 }}>
          <div className="toolbar" style={{ borderBottom:'1px solid var(--border-subtle)' }}>
            <div className="section-title" style={{ margin:0, fontSize:15 }}><Icon name="edit" size={18} style={{ color:'var(--brand)' }} /> Your drafts</div>
          </div>
          <div style={{ padding:'8px 22px 16px' }}>
            <div className="tasklist">{drafts.map(a => <TaskRow key={a.no} a={a} draft />)}</div>
          </div>
        </div>
      )}
    </div>
  );
}

Object.assign(window, { Tasks });

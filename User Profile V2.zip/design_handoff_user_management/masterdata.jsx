/* ============================================================
   Master Data — generic CRUD module
   List (search / status / date filters, sort, paging chrome)
   ⇄ Create / Edit form ⇄ Delete confirm
   ============================================================ */
const MD_STORE = {};   // keeps edits while navigating between menus

function MasterData({ menu, toast }) {
  const cfg = MD_CONFIG[menu];
  const [rows, setRowsRaw] = useState(() => MD_STORE[menu] || cfg.rows);
  const setRows = (r) => { MD_STORE[menu] = r; setRowsRaw(r); };
  const [mode, setMode] = useState('list');         // list | form
  const [editing, setEditing] = useState(null);     // row being edited (null = create)
  const [del, setDel] = useState(null);             // row pending delete

  const openCreate = () => { setEditing(null); setMode('form'); };
  const openEdit = (row) => { setEditing(row); setMode('form'); };

  const save = (values) => {
    if (editing) {
      setRows(rows.map(r => r.id === editing.id ? { ...r, ...values } : r));
      toast(`${cfg.singular} updated`);
    } else {
      const n = rows.length + 1;
      const id = `${cfg.idPrefix}-${String(n).padStart(3, '0')}`;
      setRows([{ ...values, id, created:'11/06/2026 ' + new Date().toTimeString().slice(0,5), createdBy:'Moni Roy' }, ...rows]);
      toast(`${cfg.singular} created`);
    }
    setMode('list');
  };
  const confirmDelete = () => {
    setRows(rows.filter(r => r.id !== del.id));
    toast(`${cfg.singular} deleted`);
    setDel(null);
  };

  return (
    <div className="content-narrow fade-in" key={menu}>
      {mode === 'list'
        ? <MDList cfg={cfg} rows={rows} openCreate={openCreate} openEdit={openEdit} onDelete={setDel} />
        : cfg.azureUser
          ? <MDUserForm cfg={cfg} editing={editing} onCancel={() => setMode('list')} onSave={save} />
          : <MDForm cfg={cfg} editing={editing} onCancel={() => setMode('list')} onSave={save} />}
      {del && (
        <Modal title={`Delete ${cfg.singular.toLowerCase()}?`} size="sm" onClose={() => setDel(null)}
          footer={<>
            <Btn variant="ghost" onClick={() => setDel(null)}>Cancel</Btn>
            <Btn variant="danger" icon="trash" onClick={confirmDelete}>Delete</Btn>
          </>}>
          <div style={{ display:'flex', gap:14 }}>
            <span style={{ width:44, height:44, flex:'0 0 44px', borderRadius:'50%', background:'var(--danger-bg)', color:'var(--danger)', display:'flex', alignItems:'center', justifyContent:'center' }}><Icon name="trash" size={20} /></span>
            <div style={{ fontSize:14, lineHeight:1.6 }}>
              <b>{del[cfg.columns[0].key]}</b> <span className="cell-id">{del.id}</span> will be removed permanently.
              <div className="muted" style={{ marginTop:6 }}>Applications referencing this record keep working but new requests can no longer select it.</div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ---------------- Listing ---------------- */
function MDList({ cfg, rows, openCreate, openEdit, onDelete }) {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('All');
  const [sort, setSort] = useState(null);   // {key, dir}

  let view = rows.filter(r =>
    (status === 'All' || r.status === status) &&
    (q === '' || Object.values(r).join(' ').toLowerCase().includes(q.toLowerCase()))
  );
  if (sort) {
    view = [...view].sort((a, b) => String(a[sort.key] ?? '').localeCompare(String(b[sort.key] ?? '')) * sort.dir);
  }
  const clickSort = (key) => setSort(s => !s || s.key !== key ? { key, dir:1 } : s.dir === 1 ? { key, dir:-1 } : null);

  const headCell = (key, label) => (
    <th key={key} onClick={() => clickSort(key)} style={{ cursor:'pointer', userSelect:'none' }}>
      {label}
      <span className="sort" style={{ opacity: sort?.key === key ? 1 : .35, display:'inline-block', transform: sort?.key === key && sort.dir === -1 ? 'rotate(180deg)' : 'none' }}>
        <Icon name="chevD" size={13} />
      </span>
    </th>
  );

  return (
    <div>
      <div className="page-head">
        <div>
          <div className="page-title">{cfg.title}</div>
          <div className="page-sub">{cfg.desc}</div>
        </div>
        <div style={{ display:'flex', gap:12 }}>
          <Btn variant="ghost" icon="download">Export</Btn>
          <Btn variant="accent" icon="plus" onClick={openCreate}>Create {cfg.singular}</Btn>
        </div>
      </div>

      <div className="card">
        <div className="toolbar">
          <span style={{ fontSize:13, fontWeight:600, color:'var(--fg-secondary)' }}>Filter:</span>
          <div className="search" style={{ minWidth:220, maxWidth:300 }}>
            <Icon name="search" size={18} />
            <input placeholder="Search ID, name…" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="search datebox"><Icon name="calendar" size={16} /><input placeholder="dd/mm/yyyy" /></div>
          <span className="muted">–</span>
          <div className="search datebox"><Icon name="calendar" size={16} /><input placeholder="dd/mm/yyyy" /></div>
          <select className="selectfield" style={{ width:140 }} value={status} onChange={e => setStatus(e.target.value)}>
            <option>All</option><option>Active</option><option>Inactive</option>
          </select>
          <div style={{ flex:1 }}></div>
          <span className="muted" style={{ fontSize:13 }}>{view.length} records</span>
        </div>

        {view.length === 0
          ? <div className="empty"><Icon name="search" size={32} style={{ opacity:.4 }} /><div style={{ marginTop:10 }}>No records match your filters.</div></div>
          : (
            <div className="tablewrap" style={{ border:'none', borderRadius:0 }}>
              <table className="tbl">
                <thead><tr>
                  <th style={{ width:46 }}>No</th>
                  {headCell('id','ID')}
                  {cfg.columns.map(c => headCell(c.key, c.label))}
                  {headCell('status','Status')}
                  {headCell('created','Create date')}
                  <th>Created by</th>
                  <th>Description</th>
                  <th style={{ textAlign:'right' }}>Action</th>
                </tr></thead>
                <tbody>
                  {view.map((r, i) => (
                    <tr key={r.id}>
                      <td className="muted">{i + 1}</td>
                      <td><span className="cell-id">{r.id}</span></td>
                      {cfg.columns.map(c => (
                        <td key={c.key} className={c.strong ? 'cell-strong' : ''}>{r[c.key] || '—'}</td>
                      ))}
                      <td><StatusChip status={r.status} /></td>
                      <td className="muted" style={{ whiteSpace:'nowrap' }}>{r.created}</td>
                      <td className="muted">{r.createdBy}</td>
                      <td className="muted" style={{ maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>{r.desc || '—'}</td>
                      <td>
                        <div className="rowact" style={{ justifyContent:'flex-end' }}>
                          <button title="Edit" onClick={() => openEdit(r)}><Icon name="edit" size={17} /></button>
                          <button title="Delete" onClick={() => onDelete(r)} style={{ color:'var(--danger)' }}><Icon name="trash" size={17} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

        <div className="pager">
          <span>Result 1–{view.length} of {view.length}</span>
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <span className="selectbox">100 items <Icon name="chevD" size={15} /></span>
            <div className="pages">
              <button className="pg"><Icon name="chevL" size={16} /></button>
              <button className="pg on">1</button>
              <button className="pg"><Icon name="chevR" size={16} /></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Azure AD user form (User Management) ---------------- */
function MDUserForm({ cfg, editing, onCancel, onSave }) {
  const [person, setPerson] = useState(editing ? { name:editing.name, email:editing.email, jobTitle:editing.jobTitle || jobTitleFor(editing.email) } : null);
  const [role, setRole] = useState(editing?.role || '');
  const [status, setStatus] = useState(editing?.status || 'Active');
  const [desc, setDesc] = useState(editing?.desc || '');
  const [errors, setErrors] = useState({});
  const roleOptions = cfg.roleOptions || ['PO','HR','IT','SO','Super Admin','Viewer'];

  const submit = () => {
    const e = {};
    if (!person) e.person = 'Select a user from Azure AD';
    if (!role) e.role = 'Select a role';
    setErrors(e);
    if (Object.keys(e).length) return;
    onSave({ name:person.name, email:person.email, jobTitle:person.jobTitle, role, status, desc });
  };

  return (
    <div>
      <div className="crumbs">
        <button className="backlink" onClick={onCancel}><Icon name="chevL" size={18} /> Go back</button>
        <span className="crumb-path">Master Data&nbsp;/&nbsp;{cfg.title}&nbsp;/&nbsp;<span className="cur">{editing ? 'Edit' : 'Create'}</span></span>
      </div>

      <div className="page-head" style={{ marginBottom:18 }}>
        <div>
          <div className="page-title">{editing ? 'Edit user' : 'New user'}</div>
          <div className="page-sub">{editing
            ? <>Editing <span className="cell-id">{editing.id}</span> · created {editing.created} by {editing.createdBy}</>
            : 'Search the company Azure AD directory and assign a role.'}</div>
        </div>
      </div>

      <div className="card card-pad">
        <div className="section-title"><Icon name="users" size={20} style={{ color:'var(--brand)' }} /> Directory user</div>
        <div className="section-desc">Search by name or email — details are pulled from Azure AD automatically.</div>
        <div style={{ maxWidth:460 }}>
          <Field label="User" required error={errors.person}>
            <AzurePicker value={person} onSelect={setPerson} onClear={() => setPerson(null)} error={errors.person}
              disabled={!!editing} placeholder="Search name or email…" />
          </Field>
        </div>

        <div className="divider"></div>
        <div className="section-title"><Icon name="shield" size={20} style={{ color:'var(--brand)' }} /> Role &amp; access</div>
        <div className="section-desc">Assign one role. <b>Viewer</b> can only view; other roles map to the approval workflow.</div>
        <div className="fgrid" style={{ gridTemplateColumns:'repeat(auto-fit, minmax(240px, 1fr))' }}>
          <Field label="Role" required error={errors.role}>
            <Select value={role} error={errors.role} onChange={e => setRole(e.target.value)}>
              <option value="" disabled>Select role…</option>
              {roleOptions.map(o => <option key={o}>{o}</option>)}
            </Select>
          </Field>
        </div>

        <div className="fgrid" style={{ gridTemplateColumns:'1fr', marginTop:20 }}>
          <Field label="Note (optional)">
            <textarea className="input" rows={3} placeholder="Enter a note" value={desc}
              onChange={e => setDesc(e.target.value)} style={{ resize:'vertical' }}></textarea>
          </Field>
          <Field label="Status">
            <div className="radio-group">
              {['Active','Inactive'].map(s => (
                <button type="button" key={s} className={`radio ${status === s ? 'on' : ''}`} onClick={() => setStatus(s)}>
                  <span className="rdot"></span>{s}
                </button>
              ))}
            </div>
          </Field>
        </div>

        <div className="divider"></div>
        <div style={{ display:'flex', justifyContent:'flex-end', gap:12 }}>
          <Btn variant="ghost" icon="close" onClick={onCancel}>Cancel</Btn>
          <Btn variant="primary" icon="check" onClick={submit}>Submit</Btn>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Create / Edit form ---------------- */
function MDForm({ cfg, editing, onCancel, onSave }) {
  const [vals, setVals] = useState(() => {
    const v = {};
    cfg.fields.forEach(f => v[f.key] = editing?.[f.key] ?? (f.type === 'select' ? '' : ''));
    v.desc = editing?.desc || '';
    v.status = editing?.status || 'Active';
    return v;
  });
  const [errors, setErrors] = useState({});
  const set = (k, v) => setVals(s => ({ ...s, [k]: v }));

  const submit = () => {
    const e = {};
    cfg.fields.forEach(f => {
      if (f.required && !String(vals[f.key]).trim()) e[f.key] = `${f.label} is required`;
      else if (f.validate === 'email' && vals[f.key] && !/^\S+@\S+\.\S+$/.test(vals[f.key])) e[f.key] = 'Enter a valid email';
    });
    setErrors(e);
    if (Object.keys(e).length) return;
    onSave(vals);
  };

  return (
    <div>
      <div className="crumbs">
        <button className="backlink" onClick={onCancel}><Icon name="chevL" size={18} /> Go back</button>
        <span className="crumb-path">Master Data&nbsp;/&nbsp;{cfg.title}&nbsp;/&nbsp;<span className="cur">{editing ? 'Edit' : 'Create'}</span></span>
      </div>

      <div className="page-head" style={{ marginBottom:18 }}>
        <div>
          <div className="page-title">{editing ? `Edit ${cfg.singular}` : `New ${cfg.singular}`}</div>
          <div className="page-sub">
            {editing
              ? <>Editing <span className="cell-id">{editing.id}</span> · created {editing.created} by {editing.createdBy}</>
              : cfg.desc}
          </div>
        </div>
      </div>

      <div className="card card-pad">
        <div className="section-title"><Icon name={cfg.icon} size={20} style={{ color:'var(--brand)' }} /> {cfg.singular} Detail</div>
        <div className="section-desc">Fields marked <span style={{ color:'var(--danger)' }}>*</span> are required.</div>

        <div className="fgrid" style={{ gridTemplateColumns:'repeat(auto-fit, minmax(240px, 1fr))' }}>
          {cfg.fields.map(f => (
            <Field key={f.key} label={f.label} required={f.required} hint={f.hint} error={errors[f.key]}>
              {f.type === 'select'
                ? (
                  <Select value={vals[f.key]} error={errors[f.key]} onChange={e => set(f.key, e.target.value)}>
                    <option value="" disabled>Select…</option>
                    {f.options.map(o => <option key={o}>{o}</option>)}
                  </Select>
                )
                : <TextInput value={vals[f.key]} placeholder={f.placeholder} error={errors[f.key]} onChange={e => set(f.key, e.target.value)} />}
            </Field>
          ))}
        </div>

        <div className="fgrid" style={{ gridTemplateColumns:'1fr', marginTop:20 }}>
          <Field label="Description (optional)">
            <textarea className="input" rows={3} placeholder="Enter description" value={vals.desc}
              onChange={e => set('desc', e.target.value)} style={{ resize:'vertical' }}></textarea>
          </Field>
          <Field label="Status">
            <div className="radio-group">
              {['Active','Inactive'].map(s => (
                <button type="button" key={s} className={`radio ${vals.status === s ? 'on' : ''}`} onClick={() => set('status', s)}>
                  <span className="rdot"></span>{s}
                </button>
              ))}
            </div>
          </Field>
        </div>

        <div className="divider"></div>
        <div style={{ display:'flex', justifyContent:'flex-end', gap:12 }}>
          <Btn variant="ghost" icon="close" onClick={onCancel}>Cancel</Btn>
          <Btn variant="primary" icon="check" onClick={submit}>Submit</Btn>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { MasterData });

/* ============================================================
   Master Data — per-menu config + mock rows
   Every row carries: id, status, created, createdBy, desc
   ============================================================ */
const MD_COUNTRIES = ['Thailand','Indonesia','Australia','USA','Mongolia','China','Japan','Lao PDR','Vietnam'];
const MD_JOBLEVELS = ['L1 — Officer','L2 — Senior Officer','L3 — Manager','L4 — Senior Manager','L5 — Vice President','EX — Executive'];

const MD_CONFIG = {
  um: {
    title:'User Management', singular:'User', icon:'users', idPrefix:'USR', azureUser:true,
    desc:'People who can sign in to this console and what they are allowed to do. Users are selected from the company Azure AD directory.',
    roleOptions:['PO','HR','IT','SO','Super Admin','Viewer'],
    columns:[
      { key:'name', label:'Name', strong:true },
      { key:'email', label:'Email' },
      { key:'jobTitle', label:'Job title' },
      { key:'role', label:'Role' },
    ],
    fields:[
      { key:'role', label:'Role', type:'select', required:true, options:['PO','HR','IT','SO','Super Admin','Viewer'] },
    ],
    rows:[
      { id:'USR-0001', name:'Moni Roy', email:'moni.r@banpu.com', jobTitle:'HR Systems Administrator', role:'HR', status:'Active', created:'02/01/2026 09:12', createdBy:'System', desc:'Primary HR intake administrator' },
      { id:'USR-0002', name:'Pimchanok R.', email:'pimchanok.r@banpu.com', jobTitle:'Group HR Director', role:'Super Admin', status:'Active', created:'02/01/2026 09:14', createdBy:'System', desc:'Full administrative access' },
      { id:'USR-0003', name:'Anan Wong', email:'anan.w@banpu.com', jobTitle:'Senior Systems Analyst', role:'IT', status:'Active', created:'15/01/2026 14:02', createdBy:'Moni Roy', desc:'' },
      { id:'USR-0004', name:'Dewi Anggraini', email:'dewi.a@banpu.com', jobTitle:'HR Operations Lead — ITM', role:'HR', status:'Active', created:'20/01/2026 10:30', createdBy:'Moni Roy', desc:'HR ops — ITM Jakarta' },
      { id:'USR-0005', name:'Sarah Miller', email:'sarah.m@bkv.com', jobTitle:'People Ops Lead — BKV', role:'PO', status:'Active', created:'03/02/2026 08:45', createdBy:'Moni Roy', desc:'BKV People Ops lead' },
      { id:'USR-0006', name:'Bat-Erdene G.', email:'bat.g@banpu.com', jobTitle:'Site HR Coordinator', role:'Viewer', status:'Inactive', created:'10/02/2026 11:20', createdBy:'Moni Roy', desc:'On long-term leave' },
      { id:'USR-0007', name:'Kanya Rit', email:'kanya.r@banpu.com', jobTitle:'HRIS Analyst', role:'IT', status:'Active', created:'18/03/2026 16:05', createdBy:'Pimchanok R.', desc:'' },
      { id:'USR-0008', name:'Suda Niran', email:'suda.n@banpu.com', jobTitle:'System Owner — Data Platform', role:'SO', status:'Active', created:'02/04/2026 09:00', createdBy:'Moni Roy', desc:'Provisioning & activation' },
    ],
  },

  country: {
    title:'Country', singular:'Country', icon:'flag', idPrefix:'CTY',
    desc:'Countries of operation used across employee records and access rules.',
    columns:[
      { key:'code', label:'Code', strong:true },
      { key:'name', label:'Country name' },
      { key:'region', label:'Region' },
      { key:'currency', label:'Currency' },
    ],
    fields:[
      { key:'code', label:'Country code', type:'text', required:true, placeholder:'ISO 2-letter, e.g. TH', hint:'Used as the key in integrations' },
      { key:'name', label:'Country name', type:'text', required:true, placeholder:'e.g. Thailand' },
      { key:'region', label:'Region', type:'select', required:true, options:['Asia-Pacific','Americas','EMEA'] },
      { key:'currency', label:'Local currency', type:'select', options:['THB','IDR','AUD','USD','MNT','CNY','JPY','LAK','VND'] },
    ],
    rows:[
      { id:'CTY-001', code:'TH', name:'Thailand', region:'Asia-Pacific', currency:'THB', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'Headquarters' },
      { id:'CTY-002', code:'ID', name:'Indonesia', region:'Asia-Pacific', currency:'IDR', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'' },
      { id:'CTY-003', code:'AU', name:'Australia', region:'Asia-Pacific', currency:'AUD', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'' },
      { id:'CTY-004', code:'US', name:'USA', region:'Americas', currency:'USD', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'BKV operations' },
      { id:'CTY-005', code:'MN', name:'Mongolia', region:'Asia-Pacific', currency:'MNT', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'' },
      { id:'CTY-006', code:'CN', name:'China', region:'Asia-Pacific', currency:'CNY', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'' },
      { id:'CTY-007', code:'JP', name:'Japan', region:'Asia-Pacific', currency:'JPY', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'' },
      { id:'CTY-008', code:'LA', name:'Lao PDR', region:'Asia-Pacific', currency:'LAK', status:'Active', created:'02/01/2026 09:00', createdBy:'System', desc:'' },
      { id:'CTY-009', code:'VN', name:'Vietnam', region:'Asia-Pacific', currency:'VND', status:'Inactive', created:'02/01/2026 09:00', createdBy:'System', desc:'Pending entity setup' },
    ],
  },

  company: {
    title:'Company', singular:'Company', icon:'building', idPrefix:'CMP',
    desc:'Legal entities in the group. Each employee record belongs to one company.',
    columns:[
      { key:'code', label:'Code', strong:true },
      { key:'name', label:'Company name' },
      { key:'country', label:'Country' },
      { key:'group', label:'Business group' },
    ],
    fields:[
      { key:'code', label:'Company code', type:'text', required:true, placeholder:'e.g. BPP' },
      { key:'name', label:'Company name', type:'text', required:true, placeholder:'Legal entity name' },
      { key:'country', label:'Country', type:'select', required:true, options:MD_COUNTRIES },
      { key:'group', label:'Business group', type:'select', required:true, options:['Energy Resources','Energy Generation','Energy Technology','Corporate'] },
    ],
    rows:[
      { id:'CMP-001', code:'BANPU', name:'Banpu Public Company Limited', country:'Thailand', group:'Corporate', status:'Active', created:'02/01/2026 09:05', createdBy:'System', desc:'Group headquarters' },
      { id:'CMP-002', code:'BPP', name:'Banpu Power PCL', country:'Thailand', group:'Energy Generation', status:'Active', created:'02/01/2026 09:05', createdBy:'System', desc:'' },
      { id:'CMP-003', code:'ITM', name:'PT Indo Tambangraya Megah Tbk', country:'Indonesia', group:'Energy Resources', status:'Active', created:'02/01/2026 09:05', createdBy:'System', desc:'' },
      { id:'CMP-004', code:'BKV', name:'BKV Corporation', country:'USA', group:'Energy Resources', status:'Active', created:'02/01/2026 09:05', createdBy:'System', desc:'US closed-loop gas' },
      { id:'CMP-005', code:'CEY', name:'Centennial Coal Co.', country:'Australia', group:'Energy Resources', status:'Active', created:'02/01/2026 09:05', createdBy:'System', desc:'' },
      { id:'CMP-006', code:'BNEXT', name:'Banpu NEXT Co., Ltd.', country:'Thailand', group:'Energy Technology', status:'Active', created:'02/01/2026 09:05', createdBy:'System', desc:'Green flagship' },
      { id:'CMP-007', code:'BPCN', name:'Banpu Investment (China)', country:'China', group:'Energy Generation', status:'Inactive', created:'02/01/2026 09:05', createdBy:'System', desc:'Under restructuring' },
    ],
  },

  joblevel: {
    title:'Job Level', singular:'Job Level', icon:'briefcase', idPrefix:'JLV',
    desc:'Organizational levels with their delegation-of-authority (DOA) rank.',
    columns:[
      { key:'code', label:'Code', strong:true },
      { key:'name', label:'Level name' },
      { key:'doa', label:'DOA rank' },
    ],
    fields:[
      { key:'code', label:'Level code', type:'text', required:true, placeholder:'e.g. L3' },
      { key:'name', label:'Level name', type:'text', required:true, placeholder:'e.g. Manager' },
      { key:'doa', label:'DOA rank', type:'select', required:true, options:['DOA 1','DOA 2','DOA 3','DOA 4','DOA 5','DOA 6'], hint:'Higher rank = wider approval authority' },
    ],
    rows:[
      { id:'JLV-001', code:'L1', name:'Officer', doa:'DOA 1', status:'Active', created:'02/01/2026 09:10', createdBy:'System', desc:'' },
      { id:'JLV-002', code:'L2', name:'Senior Officer', doa:'DOA 2', status:'Active', created:'02/01/2026 09:10', createdBy:'System', desc:'' },
      { id:'JLV-003', code:'L3', name:'Manager', doa:'DOA 3', status:'Active', created:'02/01/2026 09:10', createdBy:'System', desc:'' },
      { id:'JLV-004', code:'L4', name:'Senior Manager', doa:'DOA 4', status:'Active', created:'02/01/2026 09:10', createdBy:'System', desc:'' },
      { id:'JLV-005', code:'L5', name:'Vice President', doa:'DOA 5', status:'Active', created:'02/01/2026 09:10', createdBy:'System', desc:'' },
      { id:'JLV-006', code:'EX', name:'Executive', doa:'DOA 6', status:'Active', created:'02/01/2026 09:10', createdBy:'System', desc:'SVP and above' },
      { id:'JLV-007', code:'L0', name:'Trainee', doa:'DOA 1', status:'Inactive', created:'05/03/2026 13:40', createdBy:'Moni Roy', desc:'Merged into L1' },
    ],
  },

  mapping: {
    title:'Job Level Mapping', singular:'Mapping', icon:'gitbranch', idPrefix:'MAP',
    desc:'Translate grades from each source system into the standard job levels.',
    columns:[
      { key:'sourceSystem', label:'Source system', strong:true },
      { key:'sourceValue', label:'Source grade' },
      { key:'jobLevel', label:'Maps to job level' },
    ],
    fields:[
      { key:'sourceSystem', label:'Source system', type:'select', required:true, options:SOURCE_SYSTEMS },
      { key:'sourceValue', label:'Source grade / value', type:'text', required:true, placeholder:'e.g. GR07', hint:'Value exactly as it appears in the source system' },
      { key:'jobLevel', label:'Maps to job level', type:'select', required:true, options:MD_JOBLEVELS },
    ],
    rows:[
      { id:'MAP-001', sourceSystem:'SAP SuccessFactors', sourceValue:'GR05', jobLevel:'L1 — Officer', status:'Active', created:'04/01/2026 10:00', createdBy:'System', desc:'' },
      { id:'MAP-002', sourceSystem:'SAP SuccessFactors', sourceValue:'GR07', jobLevel:'L2 — Senior Officer', status:'Active', created:'04/01/2026 10:00', createdBy:'System', desc:'' },
      { id:'MAP-003', sourceSystem:'SAP SuccessFactors', sourceValue:'GR09', jobLevel:'L3 — Manager', status:'Active', created:'04/01/2026 10:01', createdBy:'System', desc:'' },
      { id:'MAP-004', sourceSystem:'BKV Oracle HCM', sourceValue:'M2', jobLevel:'L3 — Manager', status:'Active', created:'06/02/2026 15:22', createdBy:'Sarah Miller', desc:'US manager band' },
      { id:'MAP-005', sourceSystem:'BKV Oracle HCM', sourceValue:'M4', jobLevel:'L5 — Vice President', status:'Active', created:'06/02/2026 15:24', createdBy:'Sarah Miller', desc:'' },
      { id:'MAP-006', sourceSystem:'Local HRIS — TH', sourceValue:'S3', jobLevel:'L2 — Senior Officer', status:'Active', created:'12/02/2026 09:18', createdBy:'Moni Roy', desc:'' },
      { id:'MAP-007', sourceSystem:'Local HRIS — ID', sourceValue:'STAFF-A', jobLevel:'L1 — Officer', status:'Inactive', created:'20/02/2026 11:47', createdBy:'Dewi Anggraini', desc:'Replaced by new grade scheme' },
      { id:'MAP-008', sourceSystem:'Mongolia Payroll', sourceValue:'BAND-3', jobLevel:'L3 — Manager', status:'Active', created:'01/03/2026 08:30', createdBy:'Moni Roy', desc:'' },
    ],
  },

  function: {
    title:'Function', singular:'Function', icon:'function', idPrefix:'FNC',
    desc:'Functional areas of the organization used to classify positions.',
    columns:[
      { key:'code', label:'Code', strong:true },
      { key:'name', label:'Function name' },
      { key:'parent', label:'Parent function' },
    ],
    fields:[
      { key:'code', label:'Function code', type:'text', required:true, placeholder:'e.g. HR' },
      { key:'name', label:'Function name', type:'text', required:true, placeholder:'e.g. Human Resources' },
      { key:'parent', label:'Parent function', type:'select', options:['None','Human Resources','Finance','Operations','Information Technology','Health, Safety & Environment','Procurement','Legal','Strategy & Transformation'] },
    ],
    rows:[
      { id:'FNC-001', code:'HR', name:'Human Resources', parent:'None', status:'Active', created:'02/01/2026 09:20', createdBy:'System', desc:'' },
      { id:'FNC-002', code:'HR-TA', name:'Talent Acquisition', parent:'Human Resources', status:'Active', created:'02/01/2026 09:21', createdBy:'System', desc:'' },
      { id:'FNC-003', code:'FIN', name:'Finance', parent:'None', status:'Active', created:'02/01/2026 09:20', createdBy:'System', desc:'' },
      { id:'FNC-004', code:'OPS', name:'Operations', parent:'None', status:'Active', created:'02/01/2026 09:20', createdBy:'System', desc:'' },
      { id:'FNC-005', code:'IT', name:'Information Technology', parent:'None', status:'Active', created:'02/01/2026 09:20', createdBy:'System', desc:'' },
      { id:'FNC-006', code:'HSE', name:'Health, Safety & Environment', parent:'None', status:'Active', created:'02/01/2026 09:20', createdBy:'System', desc:'' },
      { id:'FNC-007', code:'PRC', name:'Procurement', parent:'None', status:'Active', created:'02/01/2026 09:20', createdBy:'System', desc:'' },
      { id:'FNC-008', code:'LGL', name:'Legal', parent:'None', status:'Inactive', created:'02/01/2026 09:20', createdBy:'System', desc:'Merged into Corporate Affairs' },
    ],
  },

  jobstatus: {
    title:'Job Status', singular:'Job Status', icon:'activity', idPrefix:'JST',
    desc:'Employment statuses that drive whether a person appears in data feeds.',
    columns:[
      { key:'code', label:'Code', strong:true },
      { key:'name', label:'Status name' },
      { key:'category', label:'Category' },
      { key:'inFeed', label:'Included in feeds' },
    ],
    fields:[
      { key:'code', label:'Status code', type:'text', required:true, placeholder:'e.g. ACT' },
      { key:'name', label:'Status name', type:'text', required:true, placeholder:'e.g. Active' },
      { key:'category', label:'Category', type:'select', required:true, options:['Employed','Not employed'] },
      { key:'inFeed', label:'Included in feeds', type:'select', required:true, options:['Yes','No'], hint:'Whether records with this status are shared with applications' },
    ],
    rows:[
      { id:'JST-001', code:'ACT', name:'Active', category:'Employed', inFeed:'Yes', status:'Active', created:'02/01/2026 09:25', createdBy:'System', desc:'' },
      { id:'JST-002', code:'PRB', name:'Probation', category:'Employed', inFeed:'Yes', status:'Active', created:'02/01/2026 09:25', createdBy:'System', desc:'' },
      { id:'JST-003', code:'LVE', name:'On Leave', category:'Employed', inFeed:'Yes', status:'Active', created:'02/01/2026 09:25', createdBy:'System', desc:'Unpaid / long-term leave' },
      { id:'JST-004', code:'SUS', name:'Suspended', category:'Employed', inFeed:'No', status:'Active', created:'02/01/2026 09:25', createdBy:'System', desc:'' },
      { id:'JST-005', code:'RSG', name:'Resigned', category:'Not employed', inFeed:'No', status:'Active', created:'02/01/2026 09:25', createdBy:'System', desc:'' },
      { id:'JST-006', code:'RET', name:'Retired', category:'Not employed', inFeed:'No', status:'Active', created:'02/01/2026 09:25', createdBy:'System', desc:'' },
      { id:'JST-007', code:'TRM', name:'Terminated', category:'Not employed', inFeed:'No', status:'Inactive', created:'02/01/2026 09:25', createdBy:'System', desc:'Use RSG going forward' },
    ],
  },
};

Object.assign(window, { MD_CONFIG });

/* ============================================================
   Create / Edit Client Detail — 4-tab wizard
   ============================================================ */
const TABS = [
  { key:0, label:'Basic Info', icon:'user' },
  { key:1, label:'Row Selection', icon:'filter' },
  { key:2, label:'Column Selection', icon:'grid' },
  { key:3, label:'Master Data', icon:'settings' },
];

function CreateForm({ editing, onExit, toast, openHistory, openVersions, onSaveDraft, today = '22/06/2026', apps = [], me, role }) {
  // Editing a finalized version (live/closed) creates a NEW version that
  // re-enters approval; the old version stays available. Editing an
  // in-flight version (Draft/Pending/Revise) just updates it in place.
  const isNewVersion = !!editing && !editing.duplicatedFrom && ['Active','Terminated','Cancelled'].includes(editing.status);
  const baseVersion = editing?.version || 1;
  const nextVersion = isNewVersion ? baseVersion + 1 : baseVersion;

  const [tab, setTab] = useState(0);
  const [maxSeen, setMaxSeen] = useState(0);
  const [changelog, setChangelog] = useState('');
  const [form, setForm] = useState(() => ({
    name: editing?.name || '', id: editing?.id || '',
    owner: editing?.owner || '', ownerEmail: editing?.ownerEmail || '', ownerTitle: editing?.ownerTitle || (editing?.ownerEmail && jobTitleFor(editing.ownerEmail) !== '—' ? jobTitleFor(editing.ownerEmail) : ''),
    lead: editing?.lead || '', leadEmail: editing?.leadEmail || '', leadTitle: editing?.leadTitle || '',
    access: editing?.access ? editing.access.filter(a => a !== 'Listener') : [],
    api: 'REST v2 — read only',
    requester: editing?.requester || (me && me.name) || '',
    sameAsRequester: false,
  }));
  const [errors, setErrors] = useState({});
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [tree, setTree] = useState(DEFAULT_TREE);
  const [cols, setCols] = useState(() => new Set(COLUMNS.filter(c => !c.sensitive).map(c => c.name)));
  const [tables, setTables] = useState(() => new Set(['Company','Business Unit','Function','Country']));

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const go = (t) => { setTab(t); setMaxSeen(m => Math.max(m, t)); };
  const apiOnly = form.access.length === 1 && form.access[0] === 'API';
  const lastTab = apiOnly ? 2 : 3;
  useEffect(() => { if (apiOnly && tab === 3) setTab(2); }, [apiOnly, tab]);

  // application name must be unique across all other requests
  const nameClash = (nm) => apps.some(a =>
    a.id !== editing?.id && a.name.trim().toLowerCase() === nm.trim().toLowerCase());
  const validateBasic = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Application name is required';
    else if (nameClash(form.name)) e.name = 'An application with this name already exists';
    if (!form.owner.trim()) e.owner = 'Product owner is required';
    if (form.lead && form.leadEmail && form.leadEmail === form.ownerEmail) e.lead = 'Tech Lead must be a different person from the Product Owner';
    if (form.access.length === 0) e.access = 'Select at least one access model';
    setErrors(e); return Object.keys(e).length === 0;
  };
  const next = () => { if (tab === 0 && !validateBasic()) return; go(Math.min(lastTab, tab + 1)); };

  const trySubmit = () => {
    if (!validateBasic()) { setTab(0); toast('Please fix the highlighted fields'); return; }
    if (isNewVersion && !changelog.trim()) { setTab(0); toast('Please describe what changed in this version'); return; }
    setConfirmOpen(true);   // ask once more before committing
  };
  const submit = () => {
    setConfirmOpen(false);
    toast(isNewVersion ? `Version v${nextVersion} submitted for approval` : 'Request submitted for approval');
    onExit();
  };

  const saveDraft = () => {
    if (!form.name.trim()) { toast('Add an application name before saving a draft'); return; }
    const draftVersion = isNewVersion ? nextVersion : baseVersion;
    const uid = isNewVersion ? `${editing.id}-v${draftVersion}-draft` : (editing?.uid || `DRAFT-${form.name.replace(/[^A-Za-z0-9]+/g, '').slice(0,8).toUpperCase()}`);
    const payload = {
      uid, id: editing?.id || form.id || uid,
      name: form.name, owner: form.owner, ownerEmail: form.ownerEmail, ownerTitle: form.ownerTitle,
      lead: form.lead, leadEmail: form.leadEmail, leadTitle: form.leadTitle,
      access: form.access, requester: form.requester,
      status: 'Draft', version: draftVersion,
      submitted: editing?.submitted || today, updated: today,
      columns: cols.size, rules: 0, sources: tables.size,
    };
    onSaveDraft && onSaveDraft(payload);
    toast(isNewVersion ? `Draft saved — v${draftVersion} in draft` : 'Draft saved');
  };

  return (
    <div className="content-narrow fade-in">
      <div className="crumbs">
        <button className="backlink" onClick={onExit}><Icon name="chevL" size={18} /> Back to listing</button>
        <span className="crumb-path">Registration Listing&nbsp;/&nbsp;<span className="cur">{editing ? 'Edit' : 'New'} Request</span></span>
      </div>

      <div className="page-head" style={{ marginBottom:16 }}>
        <div>
          <div className="page-title">{editing ? form.name || 'Client Detail' : 'New Access Request'}</div>
          <div className="page-sub">
            {editing ? <>Client ID <span className="cell-id">{form.id}</span> · </> : 'HR intake — fill in the details received from the requester. '}
            {editing && <StatusChip status={editing.status} />}
            {editing && <span className="chip chip-revise" style={{ marginLeft:8, padding:'2px 9px' }}>{isNewVersion ? `Editing → v${nextVersion}` : `v${baseVersion}`}</span>}
          </div>
        </div>
        <div style={{ display:'flex', gap:12 }}>
          {editing && <Btn variant="ghost" icon="copy" onClick={() => openVersions(editing)}>Versions</Btn>}
          {editing && <Btn variant="ghost" icon="history" onClick={() => openHistory(editing)}>History</Btn>}
          <Btn variant="ghost" icon="download" onClick={saveDraft}>Save draft</Btn>
        </div>
      </div>

      {editing?.duplicatedFrom && (
        <div style={{ background:'var(--blue-50)', border:'1px solid var(--blue-100)', borderRadius:'var(--radius-md)', padding:'14px 18px', marginBottom:18, display:'flex', gap:12, alignItems:'flex-start' }}>
          <span style={{ color:'var(--blue-600)', flex:'0 0 auto' }}><Icon name="copy" size={20} /></span>
          <div style={{ fontSize:13.5, lineHeight:1.55 }}><b>Duplicated from {editing.duplicatedFrom}.</b> <span className="muted">All fields were pre-filled — adjust the few that differ (application name, owner, scope) and submit as a new request.</span></div>
        </div>
      )}

      {isNewVersion && (
        <div style={{ background:'var(--purple-50)', border:'1px solid var(--purple-200)', borderRadius:'var(--radius-md)', padding:'16px 18px', marginBottom:18 }}>
          <div style={{ display:'flex', gap:12, alignItems:'flex-start' }}>
            <span style={{ color:'var(--banpu-plum)', flex:'0 0 auto' }}><Icon name="copy" size={20} /></span>
            <div style={{ flex:1 }}>
              <div style={{ fontWeight:600, color:'var(--fg)', fontSize:14 }}>You are creating version v{nextVersion}</div>
              <div className="muted" style={{ fontSize:13, lineHeight:1.55, marginTop:3 }}>
                Saving will branch a new version from <b style={{ color:'var(--brand)' }}>v{baseVersion}</b> and send it through approval again. v{baseVersion} stays <b>available</b> so teams already connected to it keep working — the new version references it.
              </div>
              <div style={{ marginTop:13 }}>
                <Field label={`What changed in v${nextVersion}?`} required error={isNewVersion && !changelog.trim() && tab === 0 ? undefined : undefined}>
                  <textarea className="input" rows={2} placeholder="e.g. Added Cost Center column; restricted Salary (PII)" value={changelog} onChange={e => setChangelog(e.target.value)} style={{ resize:'vertical', background:'#fff' }}></textarea>
                </Field>
              </div>
              {editing._basedOnVersion ? (
                <div style={{ marginTop:11, display:'flex', gap:8, alignItems:'flex-start', fontSize:12.5, color:'var(--fg-secondary)', lineHeight:1.5 }}>
                  <Icon name="copy" size={14} style={{ flex:'0 0 auto', marginTop:1 }} />
                  <span>Fields below are pre-filled from <b>v{editing._basedOnVersion}</b> (not the latest, v{baseVersion}) — review and adjust before submitting.</span>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      )}

      {!editing && (
        <div style={{ background: role === 'HR' ? 'var(--blue-50)' : 'var(--purple-50)', border:`1px solid ${role === 'HR' ? 'var(--blue-100)' : 'var(--purple-200)'}`, borderRadius:'var(--radius-md)', padding:'13px 16px', marginBottom:18, display:'flex', gap:11, alignItems:'flex-start' }}>
          <span style={{ color: role === 'HR' ? 'var(--blue-600)' : 'var(--brand)', flex:'0 0 auto' }}><Icon name="gitbranch" size={19} /></span>
          <div style={{ fontSize:13, lineHeight:1.55 }}>
            {role === 'HR'
              ? <><b>Creating as HR.</b> <span className="muted">You are the requester, so the request skips the separate HR review step — it goes straight to IT. This is the shorter <b>6-step</b> flow.</span></>
              : <><b>Creating as {role === 'IT' ? 'IT' : 'Product Owner'}.</b> <span className="muted">HR reviews &amp; approves this request before IT provisions it — the standard <b>7-step</b> flow.</span></>}
          </div>
        </div>
      )}

      <div className="card card-pad">
        {/* stepper tabs */}
        <div className="tabstrip" style={{ marginBottom:26 }}>
          {TABS.map(t => {
            const disabled = t.key === 3 && apiOnly;
            return (
              <button key={t.key} disabled={disabled} title={disabled ? 'Not applicable for API-only access' : undefined}
                className={`${tab === t.key ? 'on' : ''} ${maxSeen > t.key && tab !== t.key ? 'done' : ''} ${disabled ? 'tab-disabled' : ''}`}
                onClick={() => !disabled && go(t.key)}>
                <span className="num">{disabled ? <Icon name="close" size={12} /> : (maxSeen > t.key && tab !== t.key ? <Icon name="check" size={13} /> : t.key + 1)}</span>
                {t.label}
              </button>
            );
          })}
        </div>

        <div style={{ minHeight:420 }}>
          {tab === 0 && <BasicTab form={form} set={set} setForm={setForm} errors={errors} apps={apps} me={me} editing={editing} />}
          {tab === 1 && <RuleBuilder tree={tree} setTree={setTree} />}
          {tab === 2 && <ColumnTab cols={cols} setCols={setCols} />}
          {tab === 3 && <MasterTab tables={tables} setTables={setTables} toast={toast} />}
        </div>

        {/* footer nav */}
        <div className="divider"></div>
        <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
          <span className="muted" style={{ fontSize:13 }}>Step {tab + 1} of {lastTab + 1} · {TABS[tab].label}</span>
          <div style={{ display:'flex', gap:12 }}>
            <Btn variant="ghost" icon="chevL" disabled={tab === 0} onClick={() => go(tab - 1)}>Back</Btn>
            {tab < lastTab
              ? <Btn variant="primary" iconRight="chevR" onClick={next}>Continue</Btn>
              : <Btn variant="accent" icon="send" onClick={trySubmit}>{isNewVersion ? `Submit v${nextVersion} for approval` : 'Submit for processing'}</Btn>}
          </div>
        </div>
      </div>

      {confirmOpen && <ConfirmDialog
        title={isNewVersion ? `Submit version v${nextVersion}?` : 'Submit this request?'}
        message={isNewVersion
          ? `This branches a new version v${nextVersion} from v${baseVersion} and sends it through the approval workflow. v${baseVersion} stays active until v${nextVersion} is approved.`
          : `This submits “${form.name}” into the approval workflow and notifies IT. Please confirm the details are correct.`}
        confirmLabel={isNewVersion ? `Submit v${nextVersion}` : 'Submit request'}
        icon="send" variant="accent"
        onClose={() => setConfirmOpen(false)} onConfirm={submit} />}
    </div>
  );
}

/* ---------- Tab 1: Basic ---------- */
function BasicTab({ form, set, setForm, errors, apps = [], me, editing }) {
  const toggleAccess = (a) => set('access', form.access.includes(a) ? form.access.filter(x => x !== a) : [...form.access, a]);
  const apiOnly = form.access.length === 1 && form.access[0] === 'API';
  const nameOptions = availableAppNames(apps, editing?.id);
  const poPerson = form.owner ? { name: form.owner, email: form.ownerEmail, jobTitle: form.ownerTitle } : null;
  const leadPerson = form.lead ? { name: form.lead, email: form.leadEmail, jobTitle: form.leadTitle } : null;

  const pickPO = (p) => setForm(f => ({ ...f, owner:p.name, ownerEmail:p.email, ownerTitle:p.jobTitle, sameAsRequester:false }));
  const clearPO = () => setForm(f => ({ ...f, owner:'', ownerEmail:'', ownerTitle:'', sameAsRequester:false }));
  const pickLead = (p) => setForm(f => ({ ...f, lead:p.name, leadEmail:p.email, leadTitle:p.jobTitle }));
  const clearLead = () => setForm(f => ({ ...f, lead:'', leadEmail:'', leadTitle:'' }));
  const toggleSame = () => {
    if (form.sameAsRequester) { clearPO(); return; }
    const match = AZURE_AD.find(p => p.name.toLowerCase() === (form.requester || '').toLowerCase())
      || (me && AZURE_AD.find(p => p.email === me.email)) || null;
    if (match) setForm(f => ({ ...f, owner:match.name, ownerEmail:match.email, ownerTitle:match.jobTitle, sameAsRequester:true }));
    else if ((form.requester || '').trim()) setForm(f => ({ ...f, owner:form.requester, ownerEmail:'', ownerTitle:'', sameAsRequester:true }));
  };

  return (
    <div>
      <div className="section-title"><Icon name="inbox" size={20} style={{ color:'var(--brand)' }} /> Request source</div>
      <div className="section-desc">You are creating this request. Your name is pre-filled — change it if you are raising it on behalf of someone else.</div>
      <div className="fgrid" style={{ gridTemplateColumns:'1fr 1fr', marginBottom:28 }}>
        <Field label="Requested by" required hint="Pre-filled from your profile — editable">
          <TextInput icon="user" value={form.requester} placeholder="e.g. Naree Suksai" onChange={e => set('requester', e.target.value)} />
        </Field>
      </div>

      <div className="section-title"><Icon name="layers" size={20} style={{ color:'var(--brand)' }} /> Application details</div>
      <div className="section-desc">Start typing the application name — pick from the suggestions. Names already registered are hidden unless the previous request was terminated.</div>
      <div className="fgrid" style={{ gridTemplateColumns:'1fr 1fr', marginBottom:28 }}>
        <Field label="Application name" required error={errors.name} hint="Type to search available applications">
          <Autocomplete value={form.name} onChange={v => set('name', v)} options={nameOptions} icon="layers"
            placeholder="e.g. Talent Mobility Portal" error={errors.name}
            emptyNote="No available application matches — this name may already be registered." />
        </Field>
        <Field label="Client ID" hint="Auto-generated on submit">
          <TextInput value={form.id} placeholder="Assigned automatically" disabled style={{ background:'var(--grey-50)' }} />
        </Field>
      </div>

      <div className="section-title"><Icon name="user" size={20} style={{ color:'var(--brand)' }} /> Contacts</div>
      <div className="section-desc">Product Owner and Tech Lead are resolved from the company <b>Azure AD</b> directory — email and job title fill in automatically. They must be different people.</div>

      <label className="same-check same-check-full">
        <Check on={form.sameAsRequester} onClick={toggleSame} />
        <span onClick={toggleSame} style={{ cursor:'pointer' }}>Product Owner is the <b>same as requester</b> ({form.requester || '—'})</span>
      </label>
      <div className="fgrid" style={{ gridTemplateColumns:'1fr 1fr', marginBottom:24, alignItems:'start' }}>
        <Field label="Product Owner" required error={errors.owner}>
          <AzurePicker value={poPerson} onSelect={pickPO} onClear={clearPO} error={errors.owner}
            exclude={form.leadEmail ? [form.leadEmail] : []}
            placeholder="Search Product Owner in Azure AD…" />
        </Field>
        <Field label="Tech Lead" hint="Optional — leave empty if not assigned yet" error={errors.lead}>
          <AzurePicker value={leadPerson} onSelect={pickLead} onClear={clearLead} error={errors.lead}
            exclude={form.ownerEmail ? [form.ownerEmail] : []}
            placeholder="Search Tech Lead in Azure AD…" />
        </Field>
      </div>

      <div className="section-title"><Icon name="link" size={20} style={{ color:'var(--brand)' }} /> Access</div>
      <div className="section-desc">How the application will consume employee data. Choose one or more delivery methods.</div>
      <Field label="Access models" required error={errors.access}>
        <div style={{ display:'flex', gap:12, flexWrap:'wrap', marginTop:2 }}>
          {[['API','server'],['File Base','download']].map(([a, ic]) => (
            <button key={a} type="button" className={`choice ${form.access.includes(a) ? 'on' : ''}`} onClick={() => toggleAccess(a)}>
              <span className={`cbox ${form.access.includes(a) ? 'on' : ''}`}>{form.access.includes(a) && <Icon name="check" size={14} />}</span>
              <Icon name={ic} size={17} />{a}
            </button>
          ))}
        </div>
      </Field>
      {apiOnly &&
        <div style={{ display:'flex', gap:9, alignItems:'flex-start', marginTop:12, fontSize:12.5, color:'var(--fg-muted)', lineHeight:1.5 }}>
          <Icon name="alert" size={15} style={{ flex:'0 0 auto', marginTop:1 }} />
          <span>API-only access selected — the <b>Master Data</b> step is not applicable and will be skipped.</span>
        </div>}
    </div>
  );
}

/* ---------- Tab 3: Column Selection ---------- */
function ColumnTab({ cols, setCols }) {
  const [q, setQ] = useState('');
  const filtered = COLUMNS.filter(c => c.name.toLowerCase().includes(q.toLowerCase()));
  const toggle = (n) => setCols(s => { const x = new Set(s); x.has(n) ? x.delete(n) : x.add(n); return x; });
  const allOn = COLUMNS.every(c => cols.has(c.name));
  const someOn = cols.size > 0 && !allOn;
  const toggleAll = () => setCols(allOn ? new Set() : new Set(COLUMNS.map(c => c.name)));
  const typeColor = { Number:'chip-info', Text:'chip-active', Calculation:'chip-revise', Date:'chip-pending' };
  return (
    <div>
      <div className="section-title"><Icon name="grid" size={20} style={{ color:'var(--brand)' }} /> Column Selection</div>
      <div className="section-desc">Pick exactly which data fields this application may receive. Sensitive (PII) fields are flagged.</div>
      <div style={{ display:'flex', alignItems:'center', gap:14, marginBottom:14, flexWrap:'wrap' }}>
        <div className="search" style={{ maxWidth:320 }}>
          <Icon name="search" size={18} /><input placeholder="Search columns…" value={q} onChange={e => setQ(e.target.value)} />
        </div>
        <span className="tag"><Icon name="check" size={14} /> {cols.size} of {COLUMNS.length} selected</span>
      </div>
      <div className="tablewrap">
        <table className="tbl">
          <thead><tr>
            <th style={{ width:52 }}><Check on={allOn} indeterminate={someOn} onClick={toggleAll} /></th>
            <th>Field name</th><th>Data type</th><th>Description</th><th>Sensitivity</th>
          </tr></thead>
          <tbody>
            {filtered.map(c => (
              <tr key={c.name} style={{ cursor:'pointer' }} onClick={() => toggle(c.name)}>
                <td><Check on={cols.has(c.name)} onClick={(e) => { e.stopPropagation(); toggle(c.name); }} /></td>
                <td className="cell-strong">{c.name}</td>
                <td><span className={`chip ${typeColor[c.type]}`} style={{ padding:'2px 9px' }}>{c.type}</span></td>
                <td className="muted">{c.remark}</td>
                <td>{c.sensitive
                  ? <span className="chip chip-rejected" style={{ padding:'2px 9px' }}><Icon name="shield" size={12} /> PII</span>
                  : <span className="muted" style={{ fontSize:13 }}>Standard</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ---------- Tab 4: Master Data ---------- */
function MasterTab({ tables, setTables, toast }) {
  const [q, setQ] = useState('');
  const toggle = (n) => setTables(s => { const x = new Set(s); x.has(n) ? x.delete(n) : x.add(n); return x; });
  const filtered = CIF_TABLES.filter(t => t.toLowerCase().includes(q.toLowerCase()));
  const allOn = CIF_TABLES.every(t => tables.has(t));
  const someOn = tables.size > 0 && !allOn;
  const toggleAll = () => setTables(allOn ? new Set() : new Set(CIF_TABLES));
  return (
    <div>
      <div className="section-title"><Icon name="settings" size={20} style={{ color:'var(--brand)' }} /> Master Data Selection</div>
      <div className="section-desc">Choose which master data tables from <b>CIF</b> this application can resolve.</div>

      <div style={{ display:'flex', alignItems:'center', gap:14, margin:'6px 0 14px', flexWrap:'wrap' }}>
        <div className="search" style={{ maxWidth:320 }}><Icon name="search" size={18} /><input placeholder="Search tables…" value={q} onChange={e => setQ(e.target.value)} /></div>
        <span className="tag"><Icon name="check" size={14} /> {tables.size} of {CIF_TABLES.length} selected</span>
      </div>

      <div className="tablewrap">
        <table className="tbl">
          <thead><tr>
            <th style={{ width:52 }}><Check on={allOn} indeterminate={someOn} onClick={toggleAll} /></th>
            <th style={{ width:64 }}>No</th>
            <th>Table name</th>
          </tr></thead>
          <tbody>
            {filtered.map((t) => (
              <tr key={t} style={{ cursor:'pointer' }} onClick={() => toggle(t)}>
                <td><Check on={tables.has(t)} onClick={(e) => { e.stopPropagation(); toggle(t); }} /></td>
                <td className="muted">{CIF_TABLES.indexOf(t) + 1}</td>
                <td className="cell-strong">{t}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

Object.assign(window, { CreateForm });

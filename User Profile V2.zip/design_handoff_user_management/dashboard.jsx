/* ============================================================
   Dashboard / Summary
   ============================================================ */
function Dashboard({ apps = APPS, go, openReview }) {
  const counts = apps.reduce((a, x) => (a[x.status] = (a[x.status] || 0) + 1, a), {});
  const kpis = [
    { lbl:'Total Applications', val:'248', icon:'layers', bg:'var(--purple-100)', fg:'var(--brand)', trend:'+12 this month', up:true },
    { lbl:'In Progress', val: String(counts['In Progress'] || 0), icon:'clock', bg:'var(--info-bg)', fg:'var(--blue-700)', trend:'moving through approval', up:false, action:true },
    { lbl:'Active Integrations', val:'186', icon:'shield', bg:'var(--green-50)', fg:'var(--green-700)', trend:'+4 this week', up:true },
    { lbl:'Avg. Approval Time', val:'1.4d', icon:'trend', bg:'var(--blue-50)', fg:'var(--blue-700)', trend:'-0.3d vs last mo.', up:true },
  ];
  const breakdown = [
    { k:'Active', n:186, c:'var(--green-500)' },
    { k:'In Progress', n:31, c:'var(--blue-500)' },
    { k:'Draft', n:24, c:'var(--grey-300)' },
    { k:'Terminated', n:7, c:'var(--banpu-pink)' },
    { k:'Cancelled', n:4, c:'var(--ink-400)' },
  ];
  const max = Math.max(...breakdown.map(b => b.n));
  const pending = apps.filter(a => a.status === 'In Progress');

  return (
    <div className="content-narrow fade-in">
      <div className="page-head">
        <div>
          <div className="page-title">Welcome back, Moni</div>
          <div className="page-sub">Here's what's happening across project access requests today.</div>
        </div>
      </div>

      <div className="kpi-grid">
        {kpis.map(k => (
          <div className="kpi" key={k.lbl}>
            <div className="ic" style={{ background:k.bg, color:k.fg }}><Icon name={k.icon} size={22} /></div>
            <div className="val">{k.val}</div>
            <div className="lbl">{k.lbl}</div>
            <div className={`trend ${k.up ? 'up' : 'down'}`}>
              <Icon name={k.up ? 'chevU' : 'clock'} size={13} />{k.trend}
            </div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        {/* Pending approvals queue */}
        <div className="card">
          <div className="toolbar" style={{ borderBottom:'1px solid var(--border-subtle)' }}>
            <div className="section-title" style={{ margin:0 }}><Icon name="inbox" size={20} style={{color:'var(--brand)'}} /> Needs your attention</div>
            <div className="spacer" style={{flex:1}}></div>
            <button className="backlink" onClick={() => go('listing')}>View all <Icon name="chevR" size={15} /></button>
          </div>
          <div style={{ padding:'6px 22px 14px' }}>
            <div className="tasklist">
              {pending.map(a => (
                <div className="taskrow" key={a.no}>
                  <div className="avatar" style={{ background:'var(--purple-50)' }}><Icon name="layers" size={18} /></div>
                  <div className="tt">
                    <div className="nm">{a.name}</div>
                    <div className="mt">{stageLabel(a)} · {a.requester} · submitted {a.submitted}</div>
                  </div>
                  <StatusChip status={a.status} />
                  <Btn variant="outline" size="sm" onClick={() => openReview(a)}>Review</Btn>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Status breakdown */}
        <div className="card card-pad">
          <div className="section-title"><Icon name="activity" size={20} style={{color:'var(--brand)'}} /> Status breakdown</div>
          <div className="section-desc">248 applications across the organization</div>
          <div style={{ marginTop:8 }}>
            {breakdown.map(b => (
              <div className="barrow" key={b.k}>
                <span className="name">{b.k}</span>
                <span className="bartrack"><span className="barfill" style={{ width:`${(b.n / max) * 100}%`, background:b.c }}></span></span>
                <span className="n">{b.n}</span>
              </div>
            ))}
          </div>
          <div className="divider"></div>
          <div className="section-title" style={{ fontSize:15 }}><Icon name="flag" size={18} style={{color:'var(--brand)'}} /> By country</div>
          <div className="databar" style={{ marginTop:14 }}>
            <span style={{ width:'34%', background:'var(--purple-600)' }} title="Thailand"></span>
            <span style={{ width:'22%', background:'var(--blue-500)' }} title="Indonesia"></span>
            <span style={{ width:'18%', background:'var(--green-500)' }} title="Australia"></span>
            <span style={{ width:'14%', background:'var(--banpu-plum)' }} title="USA"></span>
            <span style={{ width:'12%', background:'var(--grey-300)' }} title="Other"></span>
          </div>
          <div style={{ display:'flex', flexWrap:'wrap', gap:'8px 16px', marginTop:14, fontSize:12.5, color:'var(--fg-secondary)' }}>
            {[['Thailand','var(--purple-600)'],['Indonesia','var(--blue-500)'],['Australia','var(--green-500)'],['USA','var(--banpu-plum)'],['Other','var(--grey-300)']].map(([n,c]) => (
              <span key={n} style={{ display:'flex', alignItems:'center', gap:6 }}>
                <span style={{ width:9, height:9, borderRadius:3, background:c }}></span>{n}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { Dashboard });

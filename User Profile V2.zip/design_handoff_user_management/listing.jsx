/* ============================================================
   Registration Listing — 3 switchable layout variations
   ============================================================ */
const STATUS_FILTERS = ['All','In Progress','Draft','Active','Terminated','Cancelled'];

function AccessTags({ access }) {
  return (
    <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
      {access.map(a => <span key={a} className="chip chip-info" style={{ padding:'2px 9px', fontSize:11.5 }}>{a}</span>)}
    </div>
  );
}

function VersionBadge({ app }) {
  const n = versionsOf(app).length;
  if (n <= 1) return null;
  return <span className="chip chip-revise" style={{ padding:'1px 7px', fontSize:10.5, marginLeft:6 }}>v{app.version || 1}</span>;
}

// badge shown on the live card when a newer version is being approved
function ReviewBadge({ app, openVersions }) {
  if (!app._reviewVersion) return null;
  return (
    <button className="chip chip-progress reviewbadge" title="A new version is in the approval workflow — click to view versions"
      onClick={(e) => { e.stopPropagation(); openVersions(app); }}>
      <span className="dot"></span>v{app._reviewVersion} in review
    </button>
  );
}

// collapse multiple version-rows of the same Client ID into one representative card
// (the live/Active one), tagging it with the version number that's pending review.
function representativeRows(list) {
  const byId = {};
  list.forEach(a => { (byId[a.id] = byId[a.id] || []).push(a); });
  return Object.values(byId).map(group => {
    if (group.length === 1) return group[0];
    const rep = group.find(a => a.status === 'Active')
      || group.find(a => a.status === 'In Progress')
      || group[0];
    const pending = group.find(a => a.status === 'In Progress' && a !== rep);
    return pending ? { ...rep, _reviewVersion: pending.version || null } : rep;
  });
}

function RowActions({ app, openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role }) {
  const multi = versionsOf(app).length > 1;
  const canCreate = role === 'HR' || role === 'IT' || role === 'PO';
  const versionLocked = hasOpenVersion(app);   // a newer version is already in the workflow

  // Draft: only view, edit, delete — no history / version
  if (app.status === 'Draft') {
    return (
      <div className="rowact">
        <button title="View" onClick={() => openReview(app)}><Icon name="eye" size={18} /></button>
        <button title="Edit" onClick={() => openEdit(app)}><Icon name="edit" size={17} /></button>
        <button title="Delete" onClick={() => openDelete(app)} style={{ color:'var(--danger)' }}><Icon name="trash" size={17} /></button>
      </div>
    );
  }

  const versionsBtn = multi && <button title="Version history" onClick={() => openVersions(app)} style={{color:'var(--banpu-plum)'}}><Icon name="layers" size={17} /></button>;
  const historyBtn = <button title="History log" onClick={() => openHistory(app)}><Icon name="history" size={18} /></button>;

  // In Progress: no edit (cannot be modified while in the workflow)
  if (app.status === 'In Progress') {
    return (
      <div className="rowact">
        <button title="Open task" onClick={() => openReview(app)} style={{color:'var(--brand)'}}><Icon name="filecheck" size={18} /></button>
        {versionsBtn}
        {historyBtn}
      </div>
    );
  }

  // Terminated / Cancelled: no edit — offer Duplicate instead
  if (app.status === 'Terminated' || app.status === 'Cancelled') {
    return (
      <div className="rowact">
        <button title="View" onClick={() => openReview(app)}><Icon name="eye" size={18} /></button>
        {role === 'HR' && <button title="Duplicate" onClick={() => openDuplicate(app)}><Icon name="copy" size={17} /></button>}
        {versionsBtn}
        {historyBtn}
      </div>
    );
  }

  // Active: edit becomes "Create new version" (distinct icon), blocked if one is already open
  return (
    <div className="rowact">
      <button title="View" onClick={() => openReview(app)}><Icon name="eye" size={18} /></button>
      {canCreate && (versionLocked
        ? <button title="A new version is already in progress" disabled style={{ color:'var(--ink-400)', cursor:'not-allowed' }}><Icon name="gitbranch" size={17} /></button>
        : <button title="Create new version" onClick={() => openEdit(app)} style={{ color:'var(--banpu-plum)' }}><Icon name="gitbranch" size={17} /></button>)}
      {role === 'HR' && <button title="Duplicate" onClick={() => openDuplicate(app)}><Icon name="copy" size={17} /></button>}
      {versionsBtn}
      {historyBtn}
    </div>
  );
}

function Listing({ go, apps = APPS, openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role, layout, setLayout }) {
  const [filter, setFilter] = useState('All');
  const [q, setQ] = useState('');
  const deduped = representativeRows(apps);
  const rows = deduped.filter(a =>
    (filter === 'All' || a.status === filter) &&
    (a.name.toLowerCase().includes(q.toLowerCase()) || a.id.toLowerCase().includes(q.toLowerCase()) || a.owner.toLowerCase().includes(q.toLowerCase()))
  );

  const filterCount = (f) => f === 'All' ? deduped.length : deduped.filter(a => a.status === f).length;

  return (
    <div className="content-narrow fade-in">
      <div className="page-head">
        <div>
          <div className="page-title">Registration Listing</div>
          <div className="page-sub">All applications requesting access to the User Management system.</div>
        </div>
        <div style={{ display:'flex', gap:12 }}>
          <Btn variant="ghost" icon="download">Export</Btn>
          {(role === 'HR' || role === 'IT' || role === 'PO') && <Btn variant="accent" icon="plus" onClick={() => go('create')}>Create Request</Btn>}
        </div>
      </div>

      <div className="card">
        <div className="toolbar">
          <div className="search">
            <Icon name="search" size={18} />
            <input placeholder="Search name, client ID or product owner…" value={q} onChange={e => setQ(e.target.value)} />
          </div>
          <div className="spacer" style={{ flex:1 }}></div>
          <span className="muted" style={{ fontSize:13, fontWeight:600 }}>Layout</span>
          <div className="seg">
            {[['table','Table'],['board','Grouped'],['cards','Cards']].map(([k,l]) => (
              <button key={k} className={layout === k ? 'on' : ''} onClick={() => setLayout(k)}>{l}</button>
            ))}
          </div>
        </div>

        {/* status filter chips */}
        <div style={{ display:'flex', gap:8, padding:'14px 22px', flexWrap:'wrap', borderBottom:'1px solid var(--border-subtle)' }}>
          {STATUS_FILTERS.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              style={{
                padding:'7px 14px', borderRadius:'999px', fontSize:13, fontWeight:600,
                border:`1.5px solid ${filter === f ? 'var(--brand)' : 'var(--border)'}`,
                background: filter === f ? 'var(--brand)' : '#fff',
                color: filter === f ? '#fff' : 'var(--fg-secondary)'
              }}>
              {f} <span style={{ opacity:.7, marginLeft:4 }}>{filterCount(f)}</span>
            </button>
          ))}
        </div>

        {rows.length === 0
          ? <div className="empty"><Icon name="search" size={32} style={{opacity:.4}} /><div style={{marginTop:10}}>No applications match your filters.</div></div>
          : layout === 'table' ? <TableView rows={rows} {...{openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role}} />
          : layout === 'board' ? <BoardView rows={rows} {...{openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role}} />
          : <CardsView rows={rows} {...{openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role}} />}

        <div className="pager">
          <span>Showing <b>{rows.length}</b> of <b>2,590</b> applications</span>
          <div style={{ display:'flex', alignItems:'center', gap:14 }}>
            <span className="selectbox">100 / page <Icon name="chevD" size={15} /></span>
            <div className="pages">
              <button className="pg"><Icon name="chevL" size={16} /></button>
              <button className="pg on">1</button><button className="pg">2</button><button className="pg">3</button>
              <span style={{ padding:'0 4px', color:'var(--fg-muted)' }}>…</span><button className="pg">26</button>
              <button className="pg"><Icon name="chevR" size={16} /></button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- Variation A: Table ---------- */
function TableView({ rows, openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role }) {
  return (
    <div className="tablewrap" style={{ border:'none', borderRadius:0 }}>
      <table className="tbl">
        <thead><tr>
          <th>No</th><th>Application</th><th>Client ID</th><th>Requested by</th>
          <th>Product Owner</th><th>Access</th><th>Status</th><th>Updated</th><th style={{textAlign:'right'}}>Action</th>
        </tr></thead>
        <tbody>
          {rows.map(a => (
            <tr key={a.no}>
              <td>{a.no}</td>
              <td><div className="cell-strong">{a.name}</div><ReviewBadge app={a} openVersions={openVersions} /></td>
              <td><span className="cell-id">{a.id}</span><VersionBadge app={a} /></td>
              <td>{a.requester}<div className="muted" style={{fontSize:12}}>via {a.requestedVia}</div></td>
              <td>{a.owner}</td>
              <td><AccessTags access={a.access} /></td>
              <td><StatusChip status={a.status} /></td>
              <td className="muted">{a.updated}</td>
              <td><div style={{display:'flex',justifyContent:'flex-end'}}><RowActions app={a} {...{openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role}} /></div></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---------- Variation B: Grouped by stage ---------- */
function BoardView({ rows, openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role }) {
  const stages = [
    { key:'action', label:'Needs action', icon:'alert', color:'var(--warning)', match:['In Progress'] },
    { key:'draft', label:'Draft', icon:'edit', color:'var(--brand)', match:['Draft'] },
    { key:'closed', label:'Resolved', icon:'check', color:'var(--green-600)', match:['Active','Terminated','Cancelled'] },
  ];
  return (
    <div style={{ padding:'8px 22px 18px' }}>
      {stages.map(s => {
        const items = rows.filter(r => s.match.includes(r.status));
        if (!items.length) return null;
        return (
          <div key={s.key} style={{ marginTop:18 }}>
            <div style={{ display:'flex', alignItems:'center', gap:9, margin:'8px 0 12px' }}>
              <span style={{ color:s.color, display:'flex' }}><Icon name={s.icon} size={18} /></span>
              <span style={{ fontWeight:700, fontFamily:'var(--font-display)', fontSize:15, color:'var(--fg)' }}>{s.label}</span>
              <span className="chip chip-draft" style={{ padding:'2px 9px' }}>{items.length}</span>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
              {items.map(a => (
                <div key={a.no} style={{ display:'flex', alignItems:'center', gap:16, padding:'14px 18px', border:'1px solid var(--border)', borderRadius:'var(--radius-md)', background:'#fff' }}>
                  <div className="avatar" style={{ background:'var(--purple-50)', borderRadius:'var(--radius-sm)' }}><Icon name="layers" size={18} /></div>
                  <div style={{ minWidth:0, flex:1 }}>
                    <div className="cell-strong">{a.name}<ReviewBadge app={a} openVersions={openVersions} /></div>
                    <div className="muted" style={{ fontSize:12.5 }}><span className="cell-id">{a.id}</span><VersionBadge app={a} /> · {a.requester}</div>
                  </div>
                  <AccessTags access={a.access} />
                  <StatusChip status={a.status} />
                  <RowActions app={a} {...{openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role}} />
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------- Variation C: Cards ---------- */
function CardsView({ rows, openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role }) {
  return (
    <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(320px,1fr))', gap:16, padding:'18px 22px' }}>
      {rows.map(a => (
        <div key={a.no} className="card" style={{ boxShadow:'var(--shadow-xs)' }}>
          <div style={{ padding:'16px 18px', borderBottom:'1px solid var(--border-subtle)', display:'flex', alignItems:'flex-start', gap:12 }}>
            <div className="avatar" style={{ background:'var(--gradient-brand)', color:'#fff', borderRadius:'var(--radius-sm)' }}><Icon name="layers" size={18} /></div>
            <div style={{ flex:1, minWidth:0 }}>
              <div className="cell-strong" style={{ fontSize:15 }}>{a.name}</div>
              <div className="cell-id">{a.id}<VersionBadge app={a} /></div>
              <ReviewBadge app={a} openVersions={openVersions} />
            </div>
            <StatusChip status={a.status} dot={false} />
          </div>
          <div style={{ padding:'14px 18px', display:'flex', flexDirection:'column', gap:9, fontSize:13 }}>
            <div style={{ display:'flex', justifyContent:'space-between' }}><span className="muted">Requested by</span><span style={{ fontWeight:600 }}>{a.requester}</span></div>
            <div style={{ display:'flex', justifyContent:'space-between' }}><span className="muted">Product Owner</span><span style={{ fontWeight:600 }}>{a.owner}</span></div>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}><span className="muted">Access</span><AccessTags access={a.access} /></div>
          </div>
          <div style={{ padding:'12px 18px', borderTop:'1px solid var(--border-subtle)', display:'flex', justifyContent:'space-between', alignItems:'center', background:'var(--grey-50)', borderRadius:'0 0 var(--radius-lg) var(--radius-lg)' }}>
            <span className="muted" style={{ fontSize:12 }}>Updated {a.updated}</span>
            <RowActions app={a} {...{openReview, openEdit, openHistory, openVersions, openDuplicate, openDelete, role}} />
          </div>
        </div>
      ))}
    </div>
  );
}

Object.assign(window, { Listing, AccessTags, RowActions, VersionBadge });
